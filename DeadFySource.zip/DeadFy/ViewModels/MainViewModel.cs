using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using DeadFy.Models;
using DeadFy.Services;

namespace DeadFy.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        // ── Singleton-style instance (set in constructor for view code-behind) ─
        public static MainViewModel? Instance { get; private set; }

        // ── Service shortcuts ─────────────────────────────────────────────────
        public AudioPlayerService Player  => AudioPlayerService.Instance;
        public LibraryService     Library => LibraryService.Instance;

        // ── Backing fields ────────────────────────────────────────────────────
        private string    _currentView   = "Library";
        private Song?     _selectedSong;
        private Playlist? _selectedPlaylist;
        private string    _searchQuery   = string.Empty;
        private bool      _isSearching;
        private string    _searchError   = string.Empty;
        private string    _downloadFilter = string.Empty;
        private bool      _isOfflineMode;
        private bool      _showLyrics;
        private bool      _showQueue;
        private bool      _isBulkMode;
        private bool      _isLoadingLyrics;
        private string    _sortBy;
        private bool      _sortDesc;

        // ── Lyrics ────────────────────────────────────────────────────────────
        private LyricsResult _currentLyricsResult = new();

        // ── Scrobble tracking ─────────────────────────────────────────────────
        private DateTime _songStartTime;
        private bool     _scrobbled;

        // ── Queue ─────────────────────────────────────────────────────────────
        private ObservableCollection<Song> _currentQueue = new();
        private int _currentQueueIndex = -1;

        // ── Cancellation tokens ───────────────────────────────────────────────
        private CancellationTokenSource? _searchCts;
        private CancellationTokenSource? _lyricsCts;
        private CancellationTokenSource? _suggestCts;

        // ── Timers ────────────────────────────────────────────────────────────
        private readonly DispatcherTimer _lyricsTimer;

        // ── Collections ───────────────────────────────────────────────────────
        public ObservableCollection<YouTubeSearchResult>  YouTubeResults    { get; } = new();
        public ObservableCollection<SpotifyTrackResult>   SpotifyResults    { get; } = new();
        public ObservableCollection<Song>                 FilteredLibrary   { get; } = new();
        public ObservableCollection<Song>                 DownloadedSongs   { get; } = new();
        public ObservableCollection<Song>                 UpNextQueue       { get; } = new();
        public ObservableCollection<Song>                 RecentlyPlayed    { get; } = new();
        public ObservableCollection<string>               SearchSuggestions { get; } = new();

        // ── Events ────────────────────────────────────────────────────────────
        public event EventHandler<TimeSpan>? LyricsPositionTick;

        // ── Constructor ───────────────────────────────────────────────────────
        public MainViewModel()
        {
            Instance = this;

            _isOfflineMode = SettingsService.Instance.Settings.OfflineMode;
            _sortBy        = SettingsService.Instance.Settings.LibrarySortBy;
            _sortDesc      = SettingsService.Instance.Settings.LibrarySortDesc;

            Player.PlaybackEnded += OnPlaybackEnded;
            Player.SongChanged   += OnSongChanged;

            // Lyrics sync timer — 4 × per second for smooth karaoke
            _lyricsTimer = new DispatcherTimer(DispatcherPriority.Render)
            {
                Interval = TimeSpan.FromMilliseconds(250)
            };
            _lyricsTimer.Tick += (_, _) =>
            {
                if (Player.IsPlaying && _currentLyricsResult.HasSync)
                    LyricsPositionTick?.Invoke(this, Player.Position);
            };
            _lyricsTimer.Start();

            // Wire up library change notifications
            Library.Songs.CollectionChanged += (_, _) =>
            {
                RefreshFilteredLibrary();
                RefreshDownloads();
                OnPropertyChanged(nameof(DownloadedSongsCount));
                OnPropertyChanged(nameof(LocalSongsCount));
            };

            YouTubeResults.CollectionChanged += (_, _) => OnPropertyChanged(nameof(IsYouTubeEmpty));
            SpotifyResults.CollectionChanged += (_, _) => OnPropertyChanged(nameof(IsSpotifyEmpty));

            RefreshFilteredLibrary();
            RefreshDownloads();
            RestoreRecentlyPlayed();

            // Restore Last.fm session
            var sk = SettingsService.Instance.Settings.LastFmSessionKey;
            if (!string.IsNullOrWhiteSpace(sk))
                LastFmService.Instance.Configure(sk);
        }

        // ── View / navigation ─────────────────────────────────────────────────

        public string CurrentView
        {
            get => _currentView;
            set
            {
                _currentView = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(IsLibraryView));
                OnPropertyChanged(nameof(IsSearchView));
                OnPropertyChanged(nameof(IsDownloadsView));
                OnPropertyChanged(nameof(IsPlaylistsView));
            }
        }

        public bool IsLibraryView   => CurrentView == "Library";
        public bool IsSearchView    => CurrentView == "Search";
        public bool IsDownloadsView => CurrentView == "Downloads";
        public bool IsPlaylistsView => CurrentView == "Playlists";

        // ── Panels ────────────────────────────────────────────────────────────

        public bool ShowLyrics
        {
            get => _showLyrics;
            set { _showLyrics = value; OnPropertyChanged(); if (value) ShowQueue = false; }
        }

        public bool ShowQueue
        {
            get => _showQueue;
            set { _showQueue = value; OnPropertyChanged(); if (value) ShowLyrics = false; }
        }

        // ── Offline mode ──────────────────────────────────────────────────────

        public bool IsOfflineMode
        {
            get => _isOfflineMode;
            set
            {
                _isOfflineMode = value;
                SettingsService.Instance.Settings.OfflineMode = value;
                SettingsService.Instance.Save();
                OnPropertyChanged();
                OnPropertyChanged(nameof(OfflineModeLabel));
            }
        }

        public string OfflineModeLabel => IsOfflineMode ? "🔴 Offline" : "🟢 Online";

        // ── Library sort ──────────────────────────────────────────────────────

        public string SortBy
        {
            get => _sortBy;
            set
            {
                // Tapping the same column header flips direction; new column resets to desc.
                if (_sortBy == value) { SortDesc = !_sortDesc; return; }
                _sortBy = value;
                OnPropertyChanged();
                SettingsService.Instance.Settings.LibrarySortBy = value;
                RefreshFilteredLibrary();
            }
        }

        public bool SortDesc
        {
            get => _sortDesc;
            set
            {
                _sortDesc = value;
                OnPropertyChanged();
                SettingsService.Instance.Settings.LibrarySortDesc = value;
                RefreshFilteredLibrary();
            }
        }

        // ── Bulk selection ────────────────────────────────────────────────────

        public bool IsBulkMode
        {
            get => _isBulkMode;
            set
            {
                _isBulkMode = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(BulkSelectedCount));
                if (!value) ClearBulkSelection();
            }
        }

        public int BulkSelectedCount => Library.Songs.Count(s => s.IsBulkSelected);

        public void ToggleBulkSelection(Song song)
        {
            song.IsBulkSelected = !song.IsBulkSelected;
            OnPropertyChanged(nameof(BulkSelectedCount));
        }

        public void SelectAllSongs()
        {
            foreach (var s in FilteredLibrary) s.IsBulkSelected = true;
            OnPropertyChanged(nameof(BulkSelectedCount));
        }

        public void DeselectAllSongs() => ClearBulkSelection();

        public List<Song> GetBulkSelected()
            => Library.Songs.Where(s => s.IsBulkSelected).ToList();

        private void ClearBulkSelection()
        {
            foreach (var s in Library.Songs) s.IsBulkSelected = false;
            OnPropertyChanged(nameof(BulkSelectedCount));
        }

        // ── Selection ─────────────────────────────────────────────────────────

        public Song? SelectedSong
        {
            get => _selectedSong;
            set { _selectedSong = value; OnPropertyChanged(); }
        }

        public Playlist? SelectedPlaylist
        {
            get => _selectedPlaylist;
            set
            {
                _selectedPlaylist = value;
                OnPropertyChanged();
                if (value != null) CurrentView = "PlaylistDetail";
            }
        }

        // ── Search ────────────────────────────────────────────────────────────

        public string SearchQuery
        {
            get => _searchQuery;
            set
            {
                _searchQuery = value;
                OnPropertyChanged();
                RefreshFilteredLibrary();
                if (!string.IsNullOrWhiteSpace(value)) _ = FetchSuggestionsAsync(value);
                else SearchSuggestions.Clear();
            }
        }

        public bool IsSearching
        {
            get => _isSearching;
            set { _isSearching = value; OnPropertyChanged(); }
        }

        public bool IsYouTubeEmpty => YouTubeResults.Count == 0 && !IsSearching;
        public bool IsSpotifyEmpty => SpotifyResults.Count == 0 && !IsSearching;

        public string SearchError
        {
            get => _searchError;
            set { _searchError = value; OnPropertyChanged(); }
        }

        public string DownloadFilter
        {
            get => _downloadFilter;
            set { _downloadFilter = value; OnPropertyChanged(); }
        }

        // ── Statistics ────────────────────────────────────────────────────────

        public int DownloadedSongsCount => Library.Songs.Count(s => s.Source == SongSource.YouTube);
        public int LocalSongsCount      => Library.Songs.Count(s => s.Source == SongSource.Local);

        // ── Lyrics ────────────────────────────────────────────────────────────

        public LyricsResult CurrentLyricsResult
        {
            get => _currentLyricsResult;
            private set
            {
                _currentLyricsResult = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(HasSyncedLyrics));
                OnPropertyChanged(nameof(HasLyrics));
                OnPropertyChanged(nameof(CurrentLyrics));
            }
        }

        /// <summary>Plain-text alias for XAML bindings that use the old property name.</summary>
        public string CurrentLyrics  => _currentLyricsResult.PlainLyrics;
        public bool   HasSyncedLyrics => _currentLyricsResult.HasSync;
        public bool   HasLyrics       => !string.IsNullOrWhiteSpace(_currentLyricsResult.PlainLyrics);

        public bool IsLoadingLyrics
        {
            get => _isLoadingLyrics;
            set { _isLoadingLyrics = value; OnPropertyChanged(); }
        }

        // ── Song changed ──────────────────────────────────────────────────────

        private void OnSongChanged(object? sender, Song? song)
        {
            UpdateQueue(song);
            _scrobbled = false;

            if (song == null) return;

            _songStartTime = DateTime.Now;

            Application.Current.Dispatcher.Invoke(() =>
            {
                // Maintain recently-played list (max 50, most-recent first)
                if (RecentlyPlayed.FirstOrDefault() != song)
                {
                    RecentlyPlayed.Remove(song);
                    RecentlyPlayed.Insert(0, song);
                    while (RecentlyPlayed.Count > 50)
                        RecentlyPlayed.RemoveAt(RecentlyPlayed.Count - 1);
                }
                SaveRecentlyPlayed();

                song.PlayCount++;
                song.LastPlayed = DateTime.Now;
                _ = Library.SaveLibraryAsync();
            });

            if (SettingsService.Instance.Settings.LastFmEnabled)
                _ = LastFmService.Instance.UpdateNowPlayingAsync(song);

            if (ShowLyrics)
                _ = LoadLyricsAsync(song);
        }

        // ── Scrobble ──────────────────────────────────────────────────────────

        /// <summary>
        /// Call this from the progress timer tick.
        /// Scrobbles once when 50 % of the track (or 4 min) has elapsed.
        /// </summary>
        public void CheckScrobble()
        {
            var song = Player.CurrentSong;
            if (song == null || _scrobbled) return;

            double elapsed  = (DateTime.Now - _songStartTime).TotalSeconds;
            double duration = Player.Duration.TotalSeconds;

            if (duration < 30) return; // skip very short tracks

            if (elapsed >= duration * 0.5 || elapsed >= 240)
            {
                _scrobbled = true;
                if (SettingsService.Instance.Settings.LastFmEnabled)
                    _ = LastFmService.Instance.ScrobbleAsync(song, _songStartTime);
            }
        }

        // ── Lyrics loading ────────────────────────────────────────────────────

        public async Task LoadLyricsAsync(Song song)
        {
            _lyricsCts?.Cancel();
            _lyricsCts = new CancellationTokenSource();
            var ct = _lyricsCts.Token;

            IsLoadingLyrics = true;
            CurrentLyricsResult = new LyricsResult();

            try
            {
                var result = await LyricsService.Instance.GetFullAsync(
                    song.DisplayTitle, song.DisplayArtist, null, ct);

                if (ct.IsCancellationRequested) return;

                if (string.IsNullOrWhiteSpace(result.PlainLyrics))
                    result.PlainLyrics = "No lyrics found for this song.";

                CurrentLyricsResult = result;
            }
            catch (OperationCanceledException) { }
            catch (Exception ex)
            {
                if (!ct.IsCancellationRequested)
                    CurrentLyricsResult = new LyricsResult { PlainLyrics = $"Could not load lyrics: {ex.Message}" };
            }
            finally
            {
                if (!ct.IsCancellationRequested)
                    IsLoadingLyrics = false;
            }
        }

        // ── Auto-suggest (debounced) ───────────────────────────────────────────

        private async Task FetchSuggestionsAsync(string query)
        {
            _suggestCts?.Cancel();
            _suggestCts = new CancellationTokenSource();
            var ct = _suggestCts.Token;

            try
            {
                await Task.Delay(300, ct); // debounce
                if (ct.IsCancellationRequested) return;

                var matches = Library.Songs
                    .Where(s => s.DisplayTitle.Contains(query,  StringComparison.OrdinalIgnoreCase)
                             || s.DisplayArtist.Contains(query, StringComparison.OrdinalIgnoreCase))
                    .Select(s => $"{s.DisplayTitle} – {s.DisplayArtist}")
                    .Take(5)
                    .ToList();

                Application.Current.Dispatcher.Invoke(() =>
                {
                    SearchSuggestions.Clear();
                    foreach (var s in matches) SearchSuggestions.Add(s);
                });
            }
            catch (OperationCanceledException) { }
        }

        // ── Refresh helpers ───────────────────────────────────────────────────

        public void RefreshFilteredLibrary()
        {
            FilteredLibrary.Clear();
            var sorted = Library.GetSorted(_sortBy, _sortDesc);

            if (string.IsNullOrWhiteSpace(_searchQuery))
            {
                foreach (var s in sorted) FilteredLibrary.Add(s);
                return;
            }

            // Delegate to LibraryService.Search for consistent logic
            var queryLower = _searchQuery.ToLowerInvariant();
            foreach (var s in sorted)
            {
                if (s.Title.Contains(queryLower,  StringComparison.OrdinalIgnoreCase) ||
                    s.Artist.Contains(queryLower, StringComparison.OrdinalIgnoreCase) ||
                    s.Album.Contains(queryLower,  StringComparison.OrdinalIgnoreCase))
                    FilteredLibrary.Add(s);
            }
        }

        public void RefreshDownloads()
        {
            DownloadedSongs.Clear();
            var query = _downloadFilter.Trim();
            foreach (var song in Library.Songs)
            {
                if (string.IsNullOrEmpty(query) ||
                    (song.DisplayTitle  != null && song.DisplayTitle.Contains(query,  StringComparison.OrdinalIgnoreCase)) ||
                    (song.DisplayArtist != null && song.DisplayArtist.Contains(query, StringComparison.OrdinalIgnoreCase)))
                    DownloadedSongs.Add(song);
            }
            OnPropertyChanged(nameof(DownloadedSongsCount));
        }

        // ── Online search ─────────────────────────────────────────────────────

        public void TriggerSearch()
        {
            if (IsOfflineMode)
            {
                SearchError = "🔴 Offline mode — online search is disabled.";
                return;
            }
            if (!string.IsNullOrWhiteSpace(SearchQuery))
                _ = PerformOnlineSearchAsync();
        }

        private async Task PerformOnlineSearchAsync()
        {
            _searchCts?.Cancel();
            _searchCts = new CancellationTokenSource();
            var ct = _searchCts.Token;

            IsSearching = true;
            SearchError = string.Empty;

            Application.Current.Dispatcher.Invoke(() =>
            {
                YouTubeResults.Clear();
                SpotifyResults.Clear();
                OnPropertyChanged(nameof(IsYouTubeEmpty));
                OnPropertyChanged(nameof(IsSpotifyEmpty));
            });

            try
            {
                var ytTask = YouTubeService.Instance.SearchStreamingAsync(
                    SearchQuery, 20,
                    result =>
                    {
                        ct.ThrowIfCancellationRequested();
                        Application.Current.Dispatcher.Invoke(() =>
                        {
                            YouTubeResults.Add(result);
                            OnPropertyChanged(nameof(IsYouTubeEmpty));
                        });
                    },
                    ct);

                var spTask = SpotifyService.Instance.SearchTracksAsync(SearchQuery, 20, ct);
                await Task.WhenAll(ytTask, spTask);

                if (!ct.IsCancellationRequested && spTask.IsCompletedSuccessfully)
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        foreach (var r in spTask.Result) SpotifyResults.Add(r);
                        OnPropertyChanged(nameof(IsSpotifyEmpty));
                    });
                }

                if (!ct.IsCancellationRequested && YouTubeResults.Count == 0)
                    SearchError = "No results found. Try a different search.";
            }
            catch (OperationCanceledException) { }
            catch (Exception ex)
            {
                if (!ct.IsCancellationRequested)
                    SearchError = $"Search failed: {ex.Message}";
            }
            finally
            {
                if (!ct.IsCancellationRequested)
                {
                    IsSearching = false;
                    OnPropertyChanged(nameof(IsYouTubeEmpty));
                    OnPropertyChanged(nameof(IsSpotifyEmpty));
                }
            }
        }

        // ── Streaming ─────────────────────────────────────────────────────────

        public Task StreamYouTubeTrack(YouTubeSearchResult result)
        {
            if (IsOfflineMode) return Task.CompletedTask;

            var song = new Song
            {
                Id           = result.VideoId,
                Title        = result.Title,
                Artist       = result.Author,
                Duration     = result.Duration ?? TimeSpan.Zero,
                ThumbnailUrl = result.ThumbnailUrl,
                CoverPath    = result.LocalThumbnailPath,
                Source       = SongSource.Stream,
                IsStreaming  = true,
                StreamUrl    = result.Url,
                FilePath     = string.Empty
            };

            EnsureQueue();
            int insertAt = Math.Min(_currentQueueIndex + 1, _currentQueue.Count);
            _currentQueue.Insert(insertAt, song);
            _currentQueueIndex = insertAt;
            Player.Play(song);
            RefreshUpNextQueue();
            return Task.CompletedTask;
        }

        // ── Playback ──────────────────────────────────────────────────────────

        public void PlaySong(Song song, ObservableCollection<Song>? queue = null)
        {
            _currentQueue = new ObservableCollection<Song>(queue ?? Library.Songs);
            _currentQueueIndex = _currentQueue.IndexOf(song);

            if (_currentQueueIndex < 0)
            {
                _currentQueue.Add(song);
                _currentQueueIndex = _currentQueue.Count - 1;
            }

            Player.Play(song);
            RefreshUpNextQueue();
        }

        public void PlayNext()
        {
            EnsureQueue();
            if (_currentQueue.Count == 0) return;

            if (Player.RepeatMode == RepeatMode.One)
            {
                Player.Play(_currentQueue[_currentQueueIndex]);
                return;
            }

            int next = Player.IsShuffle
                ? new Random().Next(0, _currentQueue.Count)
                : (_currentQueueIndex + 1) % _currentQueue.Count;

            // End of queue with no repeat — stop
            if (next == 0 && Player.RepeatMode == RepeatMode.None
                          && _currentQueueIndex == _currentQueue.Count - 1)
            {
                Player.Stop();
                return;
            }

            _currentQueueIndex = next;
            Player.Play(_currentQueue[_currentQueueIndex]);
            RefreshUpNextQueue();
        }

        public void PlayPrevious()
        {
            EnsureQueue();
            if (_currentQueue.Count == 0) return;

            // If more than 3 seconds in, restart the current track
            if (Player.Position.TotalSeconds > 3)
            {
                Player.PositionSeconds = 0;
                return;
            }

            _currentQueueIndex = (_currentQueueIndex - 1 + _currentQueue.Count) % _currentQueue.Count;
            Player.Play(_currentQueue[_currentQueueIndex]);
            RefreshUpNextQueue();
        }

        public void AddSongToQueue(Song song)
        {
            EnsureQueue();
            _currentQueue.Add(song);
            RefreshUpNextQueue();
        }

        public void PlayNextSong(Song song)
        {
            EnsureQueue();
            _currentQueue.Insert(Math.Min(_currentQueueIndex + 1, _currentQueue.Count), song);
            RefreshUpNextQueue();
        }

        public void RemoveFromQueue(Song song)
        {
            // Only remove entries after the current position (don't touch history)
            for (int i = _currentQueue.Count - 1; i > _currentQueueIndex; i--)
            {
                if (_currentQueue[i] == song)
                {
                    _currentQueue.RemoveAt(i);
                    break;
                }
            }
            UpNextQueue.Remove(song);
        }

        public void PlayFromQueue(Song song)
        {
            int idx = _currentQueue.IndexOf(song);
            if (idx >= 0)
            {
                _currentQueueIndex = idx;
                Player.Play(song);
                RefreshUpNextQueue();
            }
            else
            {
                PlaySong(song);
            }
        }

        // ── Downloads ─────────────────────────────────────────────────────────

        public Task<Song?> DownloadYouTubeTrack(
            YouTubeSearchResult result,
            Action<double>? onProgress = null,
            Action<string>? onStatus = null)
            => YouTubeService.Instance.DownloadAudioAsync(result, onProgress, onStatus);

        // ── Spotify playlist import ───────────────────────────────────────────

        /// <summary>
        /// Fetches a Spotify playlist, searches each track on YouTube, and
        /// creates a DeadFy playlist with streamed songs.
        /// Returns (added, failed) counts.
        /// </summary>
        public async Task<(int Added, int Failed)> ImportSpotifyPlaylistAsync(
            string spotifyUrlOrId,
            Action<string>? onStatus = null,
            CancellationToken ct = default)
        {
            onStatus?.Invoke("Fetching playlist from Spotify...");
            var (playlistName, spotifyTracks) =
                await SpotifyService.Instance.FetchPlaylistTracksAsync(spotifyUrlOrId, ct);

            if (spotifyTracks.Count == 0)
                throw new InvalidOperationException("Playlist is empty or could not be read.");

            onStatus?.Invoke($"Creating playlist \"{playlistName}\"...");
            var playlist = Library.CreatePlaylist(playlistName);

            int added = 0, failed = 0;

            for (int i = 0; i < spotifyTracks.Count; i++)
            {
                if (ct.IsCancellationRequested) break;

                var sp = spotifyTracks[i];
                onStatus?.Invoke($"[{i + 1}/{spotifyTracks.Count}] Searching: {sp.Artist} — {sp.Title}");

                try
                {
                    YouTubeSearchResult? match = null;
                    var query = string.IsNullOrWhiteSpace(sp.Artist)
                        ? sp.Title
                        : $"{sp.Artist} {sp.Title}";

                    await YouTubeService.Instance.SearchStreamingAsync(
                        query, maxResults: 1,
                        onResult: r => { if (match is null) match = r; },
                        ct: ct);

                    if (match is null) { failed++; continue; }

                    var song = new Song
                    {
                        Id           = match.VideoId,
                        Title        = sp.Title,
                        Artist       = sp.Artist,
                        Duration     = sp.DurationMs > 0
                                         ? TimeSpan.FromMilliseconds(sp.DurationMs)
                                         : match.Duration ?? TimeSpan.Zero,
                        ThumbnailUrl = match.ThumbnailUrl,
                        CoverPath    = match.LocalThumbnailPath,
                        Source       = SongSource.Stream,
                        IsStreaming  = true,
                        StreamUrl    = match.Url,
                        FilePath     = string.Empty
                    };

                    Library.AddSongToPlaylist(playlist, song);
                    added++;
                }
                catch { failed++; }
            }

            onStatus?.Invoke($"Done — {added} added, {failed} not found.");
            RefreshFilteredLibrary();
            return (added, failed);
        }

        // ── Recently played ───────────────────────────────────────────────────

        private void RestoreRecentlyPlayed()
        {
            foreach (var id in SettingsService.Instance.Settings.RecentlyPlayedIds)
            {
                var song = Library.Songs.FirstOrDefault(s => s.Id == id);
                if (song != null) RecentlyPlayed.Add(song);
            }
        }

        public void SaveRecentlyPlayed()
        {
            SettingsService.Instance.Settings.RecentlyPlayedIds =
                RecentlyPlayed.Select(s => s.Id).ToList();
            SettingsService.Instance.Save();
        }

        public void RemoveFromRecentlyPlayed(Song song)
        {
            RecentlyPlayed.Remove(song);
            SaveRecentlyPlayed();
        }

        // ── Internal helpers ──────────────────────────────────────────────────

        private void RefreshUpNextQueue()
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                UpNextQueue.Clear();
                if (_currentQueue.Count == 0) return;

                int start = (_currentQueueIndex + 1) % _currentQueue.Count;
                for (int i = 0; i < Math.Min(20, _currentQueue.Count - 1); i++)
                    UpNextQueue.Add(_currentQueue[(start + i) % _currentQueue.Count]);
            });
        }

        private void EnsureQueue()
        {
            if (_currentQueue.Count > 0) return;
            _currentQueue = new ObservableCollection<Song>(Library.Songs);
            var cur = Player.CurrentSong;
            _currentQueueIndex = cur != null ? Math.Max(0, _currentQueue.IndexOf(cur)) : 0;
        }

        private void UpdateQueue(Song? song)
        {
            if (song != null && _currentQueue.Count == 0)
            {
                _currentQueue = new ObservableCollection<Song>(Library.Songs);
                _currentQueueIndex = _currentQueue.IndexOf(song);
            }
        }

        private void OnPlaybackEnded(object? sender, EventArgs e)
            => Application.Current.Dispatcher.Invoke(PlayNext);

        // ── INotifyPropertyChanged ────────────────────────────────────────────
        public event PropertyChangedEventHandler? PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
