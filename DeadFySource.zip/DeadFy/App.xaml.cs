using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using DeadFy.Services;

namespace DeadFy
{
    public partial class App : Application
    {
        // Fallback crash log written before Logger is ready.
        private static readonly string CrashLog = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
            "DeadFy_CrashLog.txt");

        protected override void OnStartup(StartupEventArgs e)
        {
            // ── 0. Update check — runs before anything opens ──────────────────
            // Silently checks GitHub. If no update: continues immediately.
            // If update found: shows "Please wait", downloads, swaps exe, exits.
            UpdaterService.Instance.CheckAndApplyOnStartup();

            // ── 1. Performance optimisations — must run first ─────────────────
            AppOptimizer.Apply();
            MemoryManager.Start();
            CpuThrottleManager.Instance.Start();

            // ── 2. Logger ─────────────────────────────────────────────────────
            _ = Logger.Instance;
            Logger.Instance.Info("DeadFy starting up");
            Logger.Instance.Info($"Runtime: {System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription}");
            Logger.Instance.Info($"OS: {System.Runtime.InteropServices.RuntimeInformation.OSDescription}");

            // ── 3. Suppress accidental Enter/Space button activation ──────────
            RegisterButtonKeyFilter();

            // ── 4. Global exception hooks ─────────────────────────────────────
            RegisterExceptionHandlers();

            try
            {
                base.OnStartup(e);

                SettingsService.Instance.Load();
                Logger.Instance.Info("Settings loaded");

                LibraryService.Instance.EnsureDirectories();
                LibraryService.Instance.LoadLibrary();
                Logger.Instance.Info($"Library loaded — {LibraryService.Instance.Songs.Count} songs");

                ThemeService.Apply(SettingsService.Instance.Settings.Theme);
                Logger.Instance.Info($"Theme applied: {SettingsService.Instance.Settings.Theme}");

                var player = AudioPlayerService.Instance;
                player.Volume = SettingsService.Instance.Settings.Volume;

                var savedBands = SettingsService.Instance.Settings.EqBands;
                for (int i = 0; i < savedBands.Length && i < player.EqBands.Length; i++)
                    player.EqBands[i] = savedBands[i];

                if (SettingsService.Instance.Settings.DiscordRpc)
                {
                    DiscordRpcService.Instance.EnsureInitialized();
                    Logger.Instance.Info("Discord RPC initialized");
                }

                PluginLoaderService.Instance.Initialize(Services.PluginHost.Instance);
                Logger.Instance.Info("Plugin system initialized");

                Activated += OnFirstActivated;
                Logger.Instance.Info("Startup complete — main window loading");
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Fatal error during startup", ex);
                WriteCrash("OnStartup", ex);
                MessageBox.Show(
                    $"Startup failed:\n\n{ex.Message}\n\nSee log: {Logger.Instance.CurrentLogPath}",
                    "DeadFy — Startup Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                Shutdown();
            }
        }

        // ── Last-song restore ─────────────────────────────────────────────────

        private bool _restored;
        private void OnFirstActivated(object? sender, EventArgs e)
        {
            if (_restored) return;
            _restored = true;
            Activated -= OnFirstActivated;

            var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(500) };
            timer.Tick += (_, _) => { timer.Stop(); RestoreLastSong(); };
            timer.Start();
        }

        private static void RestoreLastSong()
        {
            try
            {
                var settings = SettingsService.Instance.Settings;
                var player   = AudioPlayerService.Instance;

                if (string.IsNullOrEmpty(settings.LastSongId))
                {
                    Logger.Instance.Debug("RestoreLastSong: no saved song ID");
                    return;
                }

                var song = LibraryService.Instance.Songs
                    .FirstOrDefault(x => x.Id == settings.LastSongId);

                if (song == null)
                {
                    Logger.Instance.Warning($"RestoreLastSong: song '{settings.LastSongId}' not in library");
                    return;
                }

                if (!File.Exists(song.FilePath))
                {
                    Logger.Instance.Warning($"RestoreLastSong: file missing — {song.FilePath}");
                    return;
                }

                Logger.Instance.Info($"Restoring '{song.Title}' at {settings.LastSongPosition:F1}s");
                double savedPos = settings.LastSongPosition;
                player.Play(song);

                var seekTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(400) };
                seekTimer.Tick += (_, _) =>
                {
                    seekTimer.Stop();
                    try
                    {
                        if (savedPos > 1 && savedPos < player.Duration.TotalSeconds - 1)
                            player.PositionSeconds = savedPos;
                        player.Pause();
                        Logger.Instance.Debug($"RestoreSeek complete at {savedPos:F1}s");
                    }
                    catch (Exception ex) { Logger.Instance.Error("RestoreSeek failed", ex); }
                };
                seekTimer.Start();
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("RestoreLastSong threw", ex);
            }
        }

        // ── Shutdown ──────────────────────────────────────────────────────────

        protected override void OnExit(ExitEventArgs e)
        {
            Logger.Instance.Info("DeadFy shutting down");

            var settings = SettingsService.Instance.Settings;
            var player   = AudioPlayerService.Instance;

            settings.Volume = player.Volume;
            for (int i = 0; i < player.EqBands.Length; i++)
                settings.EqBands[i] = player.EqBands[i];

            if (player.CurrentSong != null)
            {
                settings.LastSongId       = player.CurrentSong.Id;
                settings.LastSongPosition = player.PositionSeconds;
            }

            SettingsService.Instance.Save();
            Logger.Instance.Info("Settings saved");

            CpuThrottleManager.Instance.Dispose();
            MemoryManager.Stop();
            DiscordRpcService.Instance.Dispose();
            player.Dispose();

            Logger.Instance.Info("Shutdown complete");
            base.OnExit(e);
        }

        // ── Helpers ───────────────────────────────────────────────────────────

        private static void RegisterButtonKeyFilter()
        {
            EventManager.RegisterClassHandler(
                typeof(Button), UIElement.KeyDownEvent,
                new KeyEventHandler((_, e) =>
                {
                    if (e.Key is Key.Enter or Key.Space) e.Handled = true;
                }),
                handledEventsToo: true);

            EventManager.RegisterClassHandler(
                typeof(Button), UIElement.KeyUpEvent,
                new KeyEventHandler((_, e) =>
                {
                    if (e.Key is Key.Enter or Key.Space) e.Handled = true;
                }),
                handledEventsToo: true);
        }

        private void RegisterExceptionHandlers()
        {
            AppDomain.CurrentDomain.UnhandledException += (_, ex) =>
            {
                var exception = ex.ExceptionObject as Exception;
                Logger.Instance.Error("UnhandledException (fatal)", exception);
                WriteCrash("UnhandledException", exception);
            };

            DispatcherUnhandledException += (_, ex) =>
            {
                Logger.Instance.Error("DispatcherUnhandledException", ex.Exception);
                WriteCrash("DispatcherUnhandledException", ex.Exception);
                ex.Handled = true;
                MessageBox.Show(
                    $"An unexpected error occurred:\n\n{ex.Exception.Message}\n\nSee log: {Logger.Instance.CurrentLogPath}",
                    "DeadFy — Unexpected Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            };

            TaskScheduler.UnobservedTaskException += (_, ex) =>
            {
                Logger.Instance.Error("UnobservedTaskException", ex.Exception);
                WriteCrash("TaskException", ex.Exception);
            };
        }

        private static void WriteCrash(string source, Exception? ex)
        {
            try
            {
                File.AppendAllText(CrashLog,
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {source}\n{ex}\n\n");
            }
            catch { }
        }
    }
}
