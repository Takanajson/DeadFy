using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using NAudio.Wave;
using Newtonsoft.Json;

namespace DeadFy.Services
{
    public enum AppTheme
    {
        GreenDark, GreenAmoled, GreenLight, GreenPurple,
        PurpleDark, PurpleAmoled, PurpleLight, PurplePurple
    }

    public class AppSettings
    {
        // ── Appearance ────────────────────────────────────────────────────────
        public AppTheme Theme { get; set; } = AppTheme.GreenDark;

        // ── Audio device ──────────────────────────────────────────────────────
        public int    AudioDeviceIndex { get; set; } = 0;
        public string AudioDeviceName  { get; set; } = "Default";
        public float  Volume           { get; set; } = 0.8f;
        public float[] EqBands         { get; set; } = new float[10];

        // ── Playback behaviour ────────────────────────────────────────────────
        public int  CrossfadeSeconds  { get; set; } = 0;
        public bool VolumeNormalize   { get; set; } = false;
        public int  SleepTimerMinutes { get; set; } = 30;

        // ── Window / tray ─────────────────────────────────────────────────────
        public bool StartWithWindows { get; set; } = false;
        public bool StartMinimized   { get; set; } = false;
        public bool MinimizeToTray   { get; set; } = true;
        public bool ShowQueuePanel   { get; set; } = false;

        // ── Integrations ──────────────────────────────────────────────────────
        public bool   DiscordRpc           { get; set; } = true;
        public string SpotifyClientId      { get; set; } = string.Empty;
        public string SpotifyClientSecret  { get; set; } = string.Empty;
        public string SpotifyRefreshToken  { get; set; } = string.Empty;
        public string YouTubeApiKey        { get; set; } = string.Empty;

        // ── Last.fm ───────────────────────────────────────────────────────────
        public string LastFmApiKey    { get; set; } = string.Empty;
        public string LastFmApiSecret { get; set; } = string.Empty;
        public string LastFmSessionKey{ get; set; } = string.Empty;
        public bool   LastFmEnabled   { get; set; } = false;

        // ── Library ───────────────────────────────────────────────────────────
        public string LibrarySortBy   { get; set; } = "DateAdded";
        public bool   LibrarySortDesc { get; set; } = true;

        // ── Streaming / cache ─────────────────────────────────────────────────
        public bool OfflineMode              { get; set; } = false;
        public bool ClearStreamCacheOnExit   { get; set; } = true;

        // ── Session restore ───────────────────────────────────────────────────
        public string          LastSongId          { get; set; } = string.Empty;
        public double          LastSongPosition    { get; set; } = 0.0;
        public List<string>    RecentlyPlayedIds   { get; set; } = new();
    }

    public class SettingsService : INotifyPropertyChanged
    {
        private static SettingsService? _instance;
        public static SettingsService Instance => _instance ??= new SettingsService();

        private static readonly string SettingsPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "DeadFy", "settings.json");

        private AppSettings _settings = new();
        public  AppSettings Settings  => _settings;

        // ── Audio devices ─────────────────────────────────────────────────────

        public List<AudioDeviceInfo> GetOutputDevices()
        {
            var devices = new List<AudioDeviceInfo>
            {
                new() { Index = 0, Name = "Default System Device" }
            };
            for (int i = 0; i < WaveOut.DeviceCount; i++)
            {
                var caps = WaveOut.GetCapabilities(i);
                devices.Add(new AudioDeviceInfo { Index = i + 1, Name = caps.ProductName });
            }
            return devices;
        }

        // ── Startup registry ──────────────────────────────────────────────────

        public void SetStartWithWindows(bool enable)
        {
            const string regKey  = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run";
            const string appName = "DeadFy";
            try
            {
                using var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(regKey, writable: true);
                if (key == null) return;

                if (enable)
                {
                    var exe = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName ?? string.Empty;
                    key.SetValue(appName, $"\"{exe}\"");
                }
                else
                {
                    key.DeleteValue(appName, throwOnMissingValue: false);
                }

                _settings.StartWithWindows = enable;
                Save();
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("SetStartWithWindows failed", ex);
            }
        }

        public bool IsStartWithWindowsEnabled()
        {
            const string regKey  = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run";
            const string appName = "DeadFy";
            try
            {
                using var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(regKey, writable: false);
                return key?.GetValue(appName) != null;
            }
            catch { return false; }
        }

        // ── Persist ───────────────────────────────────────────────────────────

        public void Load()
        {
            try
            {
                if (File.Exists(SettingsPath))
                {
                    _settings = JsonConvert.DeserializeObject<AppSettings>(File.ReadAllText(SettingsPath))
                                ?? new AppSettings();

                    // Guard against corrupt or missing sub-fields
                    if (_settings.EqBands == null || _settings.EqBands.Length != 10)
                        _settings.EqBands = new float[10];

                    _settings.RecentlyPlayedIds ??= new List<string>();
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("SettingsService.Load failed — using defaults", ex);
                _settings = new AppSettings();
            }
            OnPropertyChanged(nameof(Settings));
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(SettingsPath)!);
                File.WriteAllText(SettingsPath,
                    JsonConvert.SerializeObject(_settings, Formatting.Indented));
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("SettingsService.Save failed", ex);
            }
        }

        // ── INotifyPropertyChanged ────────────────────────────────────────────
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? n = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
    }

    public class AudioDeviceInfo
    {
        public int    Index { get; set; }
        public string Name  { get; set; } = string.Empty;
        public override string ToString() => Name;
    }
}
