using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using NAudio.Wave;
using Newtonsoft.Json;
using System.Linq;
namespace DeadFy.Services
{
    public enum AppTheme
    {
        GreenDark, GreenAmoled, GreenLight, GreenPurple,
        PurpleDark, PurpleAmoled, PurpleLight, PurplePurple
    }

    public class AppSettings
    {
        // ── Appearance ─────────────────────────────────────────────────────────
        public AppTheme Theme { get; set; } = AppTheme.GreenDark;

        // ── Audio device ────────────────────────────────────────────────────────
        public int    AudioDeviceIndex { get; set; } = 0;
        public string AudioDeviceName  { get; set; } = "Default";
        public float  Volume           { get; set; } = 0.8f;
        public float[] EqBands         { get; set; } = new float[10];

        // ── Playback behaviour ──────────────────────────────────────────────────
        public int  CrossfadeSeconds  { get; set; } = 0;
        public bool VolumeNormalize   { get; set; } = false;
        public int  SleepTimerMinutes { get; set; } = 30;

        /// <summary>
        /// Speed multiplier for playback (0.5 = half speed, 2.0 = double speed).
        /// Values outside 0.5–2.0 are clamped by the audio service.
        /// </summary>
        public float PlaybackSpeed { get; set; } = 1.0f;

        // ── Window / tray ───────────────────────────────────────────────────────
        public bool StartWithWindows { get; set; } = false;
        public bool StartMinimized   { get; set; } = false;
        public bool MinimizeToTray   { get; set; } = true;
        public bool ShowQueuePanel   { get; set; } = false;

        // ── Column visibility (main library table) ──────────────────────────────
        public bool ShowColumnAlbum     { get; set; } = true;
        public bool ShowColumnGenre     { get; set; } = false;
        public bool ShowColumnYear      { get; set; } = false;
        public bool ShowColumnBpm       { get; set; } = false;
        public bool ShowColumnBitrate   { get; set; } = false;
        public bool ShowColumnRating    { get; set; } = true;
        public bool ShowColumnPlayCount { get; set; } = true;
        public bool ShowColumnLastPlayed{ get; set; } = false;

        // ── Integrations ────────────────────────────────────────────────────────
        public bool   DiscordRpc           { get; set; } = true;
        public string SpotifyClientId      { get; set; } = string.Empty;
        public string SpotifyClientSecret  { get; set; } = string.Empty;
        public string SpotifyRefreshToken  { get; set; } = string.Empty;
        public string YouTubeApiKey        { get; set; } = string.Empty;

        // ── Last.fm ─────────────────────────────────────────────────────────────
        public string LastFmApiKey     { get; set; } = string.Empty;
        public string LastFmApiSecret  { get; set; } = string.Empty;
        public string LastFmSessionKey { get; set; } = string.Empty;
        public bool   LastFmEnabled    { get; set; } = false;

        // ── Library ─────────────────────────────────────────────────────────────
        public string LibrarySortBy   { get; set; } = "DateAdded";
        public bool   LibrarySortDesc { get; set; } = true;

        /// <summary>Library root folders to watch for auto-rescan.</summary>
        public List<string> WatchedFolders { get; set; } = new();

        // ── Streaming / cache ────────────────────────────────────────────────────
        public bool OfflineMode              { get; set; } = false;
        public bool ClearStreamCacheOnExit   { get; set; } = true;

        /// <summary>Maximum stream cache size in MB (0 = unlimited).</summary>
        public int MaxStreamCacheMb { get; set; } = 512;

        // ── Session restore ──────────────────────────────────────────────────────
        public string       LastSongId        { get; set; } = string.Empty;
        public double       LastSongPosition  { get; set; } = 0.0;
        public List<string> RecentlyPlayedIds { get; set; } = new();

        // ── Notifications ────────────────────────────────────────────────────────
        /// <summary>Show a toast notification when a new track starts.</summary>
        public bool ShowTrackChangeNotification { get; set; } = true;

        // ── Accessibility ────────────────────────────────────────────────────────
        /// <summary>Font size scale factor (0.8–1.5). Applied to the app resource dictionary.</summary>
        public float FontScale { get; set; } = 1.0f;
    }

    public class SettingsService : INotifyPropertyChanged
    {
        private static SettingsService? _instance;
        public static SettingsService Instance => _instance ??= new SettingsService();

        private static readonly string SettingsPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "DeadFy", "settings.json");

        // Backup written before every save so corruption doesn't wipe settings.
        private static string BackupPath => SettingsPath + ".bak";

        private AppSettings _settings = new();
        public  AppSettings Settings  => _settings;

        // ── Audio devices ──────────────────────────────────────────────────────

        public List<AudioDeviceInfo> GetOutputDevices()
        {
            var devices = new List<AudioDeviceInfo>
            {
                new() { Index = 0, Name = "Default System Device" }
            };
            for (int i = 0; i < WaveOut.DeviceCount; i++)
            {
                var caps = WaveOut.GetCapabilities(i);
                devices.Add(new AudioDeviceInfo { Index = i + 1, Name = caps.ProductName });
            }
            return devices;
        }

        // ── Startup registry ────────────────────────────────────────────────────

        public void SetStartWithWindows(bool enable)
        {
            const string regKey  = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run";
            const string appName = "DeadFy";
            try
            {
                using var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(regKey, writable: true);
                if (key == null) return;

                if (enable)
                {
                    var exe = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName ?? string.Empty;
                    key.SetValue(appName, $"\"{exe}\"");
                }
                else
                {
                    key.DeleteValue(appName, throwOnMissingValue: false);
                }

                _settings.StartWithWindows = enable;
                Save();
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("SetStartWithWindows failed", ex);
            }
        }

        public bool IsStartWithWindowsEnabled()
        {
            const string regKey  = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run";
            const string appName = "DeadFy";
            try
            {
                using var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(regKey, writable: false);
                return key?.GetValue(appName) != null;
            }
            catch { return false; }
        }

        // ── Persist ────────────────────────────────────────────────────────────

        public void Load()
        {
            try
            {
                string? pathToRead = null;

                if (File.Exists(SettingsPath))
                    pathToRead = SettingsPath;
                else if (File.Exists(BackupPath))
                {
                    Logger.Instance.Warning("SettingsService: settings.json missing — restoring from backup");
                    pathToRead = BackupPath;
                }

                if (pathToRead != null)
                {
                    _settings = JsonConvert.DeserializeObject<AppSettings>(File.ReadAllText(pathToRead))
                                ?? new AppSettings();

                    // Guard against corrupt or missing sub-fields.
                    if (_settings.EqBands == null || _settings.EqBands.Length != 10)
                        _settings.EqBands = new float[10];

                    _settings.RecentlyPlayedIds ??= new List<string>();
                    _settings.WatchedFolders    ??= new List<string>();

                    // Clamp values that could be out of range after a manual edit.
                    _settings.Volume        = Math.Clamp(_settings.Volume,        0f, 1f);
                    _settings.PlaybackSpeed = Math.Clamp(_settings.PlaybackSpeed, 0.5f, 2.0f);
                    _settings.FontScale     = Math.Clamp(_settings.FontScale,     0.8f, 1.5f);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("SettingsService.Load failed — using defaults", ex);
                _settings = new AppSettings();
            }
            OnPropertyChanged(nameof(Settings));
        }

        /// <summary>
        /// Atomically saves settings: writes to a temp file first, then
        /// replaces settings.json.  The previous settings.json is kept as .bak.
        /// This prevents partial writes from corrupting the only settings file.
        /// </summary>
        public void Save()
        {
            try
            {
                var dir = Path.GetDirectoryName(SettingsPath)!;
                Directory.CreateDirectory(dir);

                var json    = JsonConvert.SerializeObject(_settings, Formatting.Indented);
                var tmpPath = SettingsPath + ".tmp";

                File.WriteAllText(tmpPath, json);

                // Rotate: settings → .bak, tmp → settings
                if (File.Exists(SettingsPath))
                    File.Copy(SettingsPath, BackupPath, overwrite: true);

                File.Move(tmpPath, SettingsPath, overwrite: true);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("SettingsService.Save failed", ex);
            }
        }

        // ── Convenience helpers ────────────────────────────────────────────────

        /// <summary>
        /// Add a folder to the watched list if not already present, then save.
        /// </summary>
        public void AddWatchedFolder(string path)
        {
            if (_settings.WatchedFolders.Any(f => f.Equals(path, StringComparison.OrdinalIgnoreCase))) return;
            _settings.WatchedFolders.Add(path);
            Save();
        }

        public void RemoveWatchedFolder(string path)
        {
            _settings.WatchedFolders.RemoveAll(p => p.Equals(path, StringComparison.OrdinalIgnoreCase));
            Save();
        }

        // ── INotifyPropertyChanged ─────────────────────────────────────────────
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? n = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
    }

    public class AudioDeviceInfo
    {
        public int    Index { get; set; }
        public string Name  { get; set; } = string.Empty;
        public override string ToString() => Name;
    }
}
