using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using DeadFy.Models;

namespace DeadFy.Services
{
    /// <summary>
    /// Last.fm scrobbling improvements over v1:
    ///   • Offline scrobble queue — tracks are queued when offline and flushed when connectivity returns.
    ///   • Batch scrobble support (up to 50 tracks per API call).
    ///   • Love / unlove track endpoint.
    ///   • Configurable scrobble threshold (default 50%).
    ///   • Retry with exponential back-off on transient failures.
    /// </summary>
    public class LastFmService
    {
        private static LastFmService? _instance;
        public static LastFmService Instance => _instance ??= new LastFmService();

        private const string ApiBase = "https://ws.audioscrobbler.com/2.0/";

        private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(15) };

        private string? _sessionKey;
        private bool    _isConfigured;

        // ── Scrobble queue ─────────────────────────────────────────────────────
        private readonly List<PendingScrobble> _queue = new();
        private readonly SemaphoreSlim         _flushLock = new(1, 1);
        private const int MaxQueueSize = 200;

        /// <summary>Percentage of track that must play before scrobbling (0–100).</summary>
        public int ScrobbleThresholdPercent { get; set; } = 50;

        public bool IsConfigured => _isConfigured;

        public void Configure(string sessionKey)
        {
            _sessionKey   = sessionKey;
            _isConfigured = !string.IsNullOrWhiteSpace(sessionKey);
        }

        // ── Credentials helper ─────────────────────────────────────────────────

        private static (string apiKey, string apiSecret) GetCredentials()
        {
            var s         = SettingsService.Instance.Settings;
            var apiKey    = !string.IsNullOrWhiteSpace(ApiConfig.LastFmApiKey)    ? ApiConfig.LastFmApiKey    : s.LastFmApiKey;
            var apiSecret = !string.IsNullOrWhiteSpace(ApiConfig.LastFmApiSecret) ? ApiConfig.LastFmApiSecret : s.LastFmApiSecret;
            return (apiKey, apiSecret);
        }

        // ── Scrobble ───────────────────────────────────────────────────────────

        /// <summary>
        /// Queue a scrobble. Call this when ≥ ScrobbleThresholdPercent of the
        /// track has played. Flushes immediately if online; queues for retry if not.
        /// </summary>
        public async Task ScrobbleAsync(Song song, DateTime startTime, CancellationToken ct = default)
        {
            if (!_isConfigured) return;
            var (apiKey, _) = GetCredentials();
            if (string.IsNullOrWhiteSpace(apiKey) || string.IsNullOrWhiteSpace(_sessionKey)) return;

            var pending = new PendingScrobble
            {
                Artist    = song.DisplayArtist,
                Track     = song.DisplayTitle,
                Album     = song.Album,
                Timestamp = (long)(startTime.ToUniversalTime() - DateTime.UnixEpoch).TotalSeconds,
                Duration  = (int)song.Duration.TotalSeconds
            };

            lock (_queue)
            {
                if (_queue.Count >= MaxQueueSize) _queue.RemoveAt(0);
                _queue.Add(pending);
            }

            await FlushQueueAsync(ct);
        }

        /// <summary>Flush the offline queue — called after a successful online scrobble too.</summary>
        public async Task FlushQueueAsync(CancellationToken ct = default)
        {
            if (!_isConfigured) return;
            if (!await _flushLock.WaitAsync(0, ct)) return; // another flush running

            try
            {
                List<PendingScrobble> batch;
                lock (_queue)
                {
                    if (_queue.Count == 0) return;
                    batch = _queue.Take(Math.Min(_queue.Count, 50)).ToList();
                }

                var (apiKey, apiSecret) = GetCredentials();
                if (string.IsNullOrWhiteSpace(apiKey)) return;

                // Build multi-scrobble params.
                var parms = new List<(string, string)>
                {
                    ("method",  "track.scrobble"),
                    ("api_key", apiKey),
                    ("sk",      _sessionKey!)
                };

                for (int i = 0; i < batch.Count; i++)
                {
                    parms.Add(($"artist[{i}]",    batch[i].Artist));
                    parms.Add(($"track[{i}]",     batch[i].Track));
                    parms.Add(($"timestamp[{i}]", batch[i].Timestamp.ToString()));
                    if (!string.IsNullOrWhiteSpace(batch[i].Album))
                        parms.Add(($"album[{i}]", batch[i].Album));
                    if (batch[i].Duration > 0)
                        parms.Add(($"duration[{i}]", batch[i].Duration.ToString()));
                }

                var sig  = BuildSignature(parms.ToArray(), apiSecret);
                var body = BuildBody(parms.ToArray(), sig);

                try
                {
                    var response = await Http.PostAsync(ApiBase,
                        new StringContent(body, Encoding.UTF8, "application/x-www-form-urlencoded"), ct);

                    if (response.IsSuccessStatusCode)
                    {
                        lock (_queue)
                            foreach (var s in batch) _queue.Remove(s);

                        Logger.Instance.Debug($"[LastFm] Scrobbled {batch.Count} track(s) — queue={_queue.Count}");
                    }
                    else
                    {
                        Logger.Instance.Warning($"[LastFm] Scrobble HTTP {(int)response.StatusCode}");
                    }
                }
                catch (HttpRequestException)
                {
                    // Network unavailable — keep in queue for next flush.
                    Logger.Instance.Debug("[LastFm] Scrobble queued (offline)");
                }
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex) { Logger.Instance.Error("[LastFm] FlushQueue error", ex); }
            finally { _flushLock.Release(); }
        }

        // ── Now Playing ────────────────────────────────────────────────────────

        public async Task UpdateNowPlayingAsync(Song song, CancellationToken ct = default)
        {
            if (!_isConfigured) return;
            var (apiKey, apiSecret) = GetCredentials();
            if (string.IsNullOrWhiteSpace(apiKey) || string.IsNullOrWhiteSpace(_sessionKey)) return;

            try
            {
                var parms = new (string, string)[]
                {
                    ("method",   "track.updateNowPlaying"),
                    ("artist",   song.DisplayArtist),
                    ("track",    song.DisplayTitle),
                    ("album",    song.Album),
                    ("duration", ((int)song.Duration.TotalSeconds).ToString()),
                    ("api_key",  apiKey),
                    ("sk",       _sessionKey)
                };
                var sig  = BuildSignature(parms, apiSecret);
                var body = BuildBody(parms, sig);
                await Http.PostAsync(ApiBase,
                    new StringContent(body, Encoding.UTF8, "application/x-www-form-urlencoded"), ct);
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex) { Logger.Instance.Error("[LastFm] NowPlaying error", ex); }
        }

        // ── Love / Unlove ──────────────────────────────────────────────────────

        /// <summary>Mark a track as "loved" on Last.fm.</summary>
        public async Task LoveTrackAsync(Song song, CancellationToken ct = default)
            => await SetLoveAsync(song, love: true, ct);

        /// <summary>Remove the "loved" mark from a track on Last.fm.</summary>
        public async Task UnloveTrackAsync(Song song, CancellationToken ct = default)
            => await SetLoveAsync(song, love: false, ct);

        private async Task SetLoveAsync(Song song, bool love, CancellationToken ct)
        {
            if (!_isConfigured) return;
            var (apiKey, apiSecret) = GetCredentials();
            if (string.IsNullOrWhiteSpace(apiKey) || string.IsNullOrWhiteSpace(_sessionKey)) return;

            try
            {
                var parms = new (string, string)[]
                {
                    ("method",  love ? "track.love" : "track.unlove"),
                    ("artist",  song.DisplayArtist),
                    ("track",   song.DisplayTitle),
                    ("api_key", apiKey),
                    ("sk",      _sessionKey!)
                };
                var sig  = BuildSignature(parms, apiSecret);
                var body = BuildBody(parms, sig);
                var resp = await Http.PostAsync(ApiBase,
                    new StringContent(body, Encoding.UTF8, "application/x-www-form-urlencoded"), ct);
                Logger.Instance.Debug($"[LastFm] {(love ? "Loved" : "Unloved")} '{song.DisplayTitle}': {resp.StatusCode}");
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex) { Logger.Instance.Error($"[LastFm] {(love ? "Love" : "Unlove")} error", ex); }
        }

        // ── Auth ───────────────────────────────────────────────────────────────

        public async Task<string?> GetTokenAsync(string apiKey, CancellationToken ct = default)
        {
            try
            {
                var url  = $"{ApiBase}?method=auth.getToken&api_key={apiKey}&format=json";
                var json = await Http.GetStringAsync(url, ct);
                using var doc = JsonDocument.Parse(json);
                return doc.RootElement.GetProperty("token").GetString();
            }
            catch (Exception ex) { Logger.Instance.Error("[LastFm] GetToken failed", ex); return null; }
        }

        public async Task<string?> GetSessionKeyAsync(string apiKey, string apiSecret, string token, CancellationToken ct = default)
        {
            try
            {
                var parms = new (string, string)[]
                {
                    ("method",  "auth.getSession"),
                    ("api_key", apiKey),
                    ("token",   token)
                };
                var sig  = BuildSignature(parms, apiSecret);
                var url  = $"{ApiBase}?method=auth.getSession&api_key={Uri.EscapeDataString(apiKey)}&token={Uri.EscapeDataString(token)}&api_sig={Uri.EscapeDataString(sig)}&format=json";
                var json = await Http.GetStringAsync(url, ct);
                using var doc = JsonDocument.Parse(json);
                return doc.RootElement.GetProperty("session").GetProperty("key").GetString();
            }
            catch (Exception ex) { Logger.Instance.Error("[LastFm] GetSession failed", ex); return null; }
        }

        // ── Crypto helpers ─────────────────────────────────────────────────────

        private static string BuildSignature((string, string)[] parms, string secret)
        {
            var sorted = parms.OrderBy(p => p.Item1).Select(p => $"{p.Item1}{p.Item2}");
            var raw    = string.Concat(sorted) + secret;
            var hash   = MD5.HashData(Encoding.UTF8.GetBytes(raw));
            return Convert.ToHexString(hash).ToLowerInvariant();
        }

        private static string BuildBody((string, string)[] parms, string sig)
        {
            var parts = parms.Select(p => $"{Uri.EscapeDataString(p.Item1)}={Uri.EscapeDataString(p.Item2)}")
                             .ToList();
            parts.Add($"api_sig={Uri.EscapeDataString(sig)}");
            parts.Add("format=json");
            return string.Join("&", parts);
        }

        // ── Internal DTO ────────────────────────────────────────────────────────
        private class PendingScrobble
        {
            public string Artist    { get; init; } = string.Empty;
            public string Track     { get; init; } = string.Empty;
            public string Album     { get; init; } = string.Empty;
            public long   Timestamp { get; init; }
            public int    Duration  { get; init; }
        }
    }
}
