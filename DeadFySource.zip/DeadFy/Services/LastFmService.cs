using System;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using DeadFy.Models;

namespace DeadFy.Services
{
    /// <summary>Last.fm scrobbling — records what you listen to on your Last.fm profile.</summary>
    public class LastFmService
    {
        private static LastFmService? _instance;
        public static LastFmService Instance => _instance ??= new LastFmService();

        private const string ApiBase   = "https://ws.audioscrobbler.com/2.0/";
        private const string ApiKey    = "";   // filled from settings at runtime
        private const string ApiSecret = "";

        private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(10) };

        private string? _sessionKey;
        private bool    _isConfigured;

        public bool IsConfigured => _isConfigured;

        public void Configure(string sessionKey)
        {
            _sessionKey   = sessionKey;
            _isConfigured = !string.IsNullOrWhiteSpace(sessionKey);
        }

        /// <summary>Scrobble a song (called when ≥50% of track has been played).</summary>
        public async Task ScrobbleAsync(Song song, DateTime startTime, CancellationToken ct = default)
        {
            if (!_isConfigured) return;
            // ApiConfig keys take priority over settings
            var apiKey    = !string.IsNullOrWhiteSpace(ApiConfig.LastFmApiKey)    ? ApiConfig.LastFmApiKey    : SettingsService.Instance.Settings.LastFmApiKey;
            var apiSecret = !string.IsNullOrWhiteSpace(ApiConfig.LastFmApiSecret) ? ApiConfig.LastFmApiSecret : SettingsService.Instance.Settings.LastFmApiSecret;
            if (string.IsNullOrWhiteSpace(apiKey) || string.IsNullOrWhiteSpace(_sessionKey)) return;

            try
            {
                var ts = (long)(startTime.ToUniversalTime() - DateTime.UnixEpoch).TotalSeconds;
                var parms = new (string, string)[]
                {
                    ("method",    "track.scrobble"),
                    ("artist",    song.DisplayArtist),
                    ("track",     song.DisplayTitle),
                    ("timestamp", ts.ToString()),
                    ("api_key",   apiKey),
                    ("sk",        _sessionKey)
                };

                var sig  = BuildSignature(parms, apiSecret);
                var body = BuildBody(parms, sig);

                var response = await Http.PostAsync(ApiBase,
                    new StringContent(body, Encoding.UTF8, "application/x-www-form-urlencoded"), ct);
                Logger.Instance.Debug($"[LastFm] Scrobble {response.StatusCode}: {song.DisplayTitle}");
            }
            catch (Exception ex) { Logger.Instance.Error("[LastFm] Scrobble error", ex); }
        }

        /// <summary>Update Now Playing (called immediately when a song starts).</summary>
        public async Task UpdateNowPlayingAsync(Song song, CancellationToken ct = default)
        {
            if (!_isConfigured) return;
            var apiKey    = !string.IsNullOrWhiteSpace(ApiConfig.LastFmApiKey)    ? ApiConfig.LastFmApiKey    : SettingsService.Instance.Settings.LastFmApiKey;
            var apiSecret = !string.IsNullOrWhiteSpace(ApiConfig.LastFmApiSecret) ? ApiConfig.LastFmApiSecret : SettingsService.Instance.Settings.LastFmApiSecret;
            if (string.IsNullOrWhiteSpace(apiKey) || string.IsNullOrWhiteSpace(_sessionKey)) return;

            try
            {
                var parms = new (string, string)[]
                {
                    ("method",   "track.updateNowPlaying"),
                    ("artist",   song.DisplayArtist),
                    ("track",    song.DisplayTitle),
                    ("duration", ((int)song.Duration.TotalSeconds).ToString()),
                    ("api_key",  apiKey),
                    ("sk",       _sessionKey)
                };
                var sig  = BuildSignature(parms, apiSecret);
                var body = BuildBody(parms, sig);
                await Http.PostAsync(ApiBase,
                    new StringContent(body, Encoding.UTF8, "application/x-www-form-urlencoded"), ct);
            }
            catch (Exception ex) { Logger.Instance.Error("[LastFm] NowPlaying error", ex); }
        }

        /// <summary>Auth step 1: get a token (user must then authorize at last.fm/api/auth/?token=)</summary>
        public async Task<string?> GetTokenAsync(string apiKey, CancellationToken ct = default)
        {
            try
            {
                var url  = $"{ApiBase}?method=auth.getToken&api_key={apiKey}&format=json";
                var json = await Http.GetStringAsync(url, ct);
                var doc  = JsonDocument.Parse(json);
                return doc.RootElement.GetProperty("token").GetString();
            }
            catch (Exception ex) { Logger.Instance.Error("[LastFm] GetToken error", ex); return null; }
        }

        /// <summary>Auth step 2: exchange token for session key after user authorized.</summary>
        public async Task<string?> GetSessionAsync(string token, string apiKey, string apiSecret, CancellationToken ct = default)
        {
            try
            {
                var parms = new (string, string)[]
                {
                    ("method",  "auth.getSession"),
                    ("api_key", apiKey),
                    ("token",   token)
                };
                var sig  = BuildSignature(parms, apiSecret);
                var body = BuildBody(parms, sig) + "&format=json";
                var json = await Http.GetStringAsync($"{ApiBase}?{body}", ct);
                var doc  = JsonDocument.Parse(json);
                return doc.RootElement.GetProperty("session").GetProperty("key").GetString();
            }
            catch (Exception ex) { Logger.Instance.Error("[LastFm] GetSession error", ex); return null; }
        }

        // ── Helpers ────────────────────────────────────────────────────
        private static string BuildSignature((string, string)[] parms, string secret)
        {
            // Sort alphabetically, concat key+value, append secret, MD5
            var sorted = new System.Collections.Generic.List<(string, string)>(parms);
            sorted.Sort((a, b) => string.Compare(a.Item1, b.Item1, StringComparison.Ordinal));
            var sb = new StringBuilder();
            foreach (var (k, v) in sorted) sb.Append(k).Append(v);
            sb.Append(secret);
            using var md5 = MD5.Create();
            var hash = md5.ComputeHash(Encoding.UTF8.GetBytes(sb.ToString()));
            return Convert.ToHexString(hash).ToLower();
        }

        private static string BuildBody((string, string)[] parms, string sig)
        {
            var sb = new StringBuilder();
            foreach (var (k, v) in parms)
                sb.Append(Uri.EscapeDataString(k)).Append('=')
                  .Append(Uri.EscapeDataString(v)).Append('&');
            sb.Append("api_sig=").Append(sig);
            return sb.ToString();
        }
    }
}
