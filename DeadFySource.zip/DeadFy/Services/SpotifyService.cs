using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace DeadFy.Services
{
    // ═══════════════════════════════════════════════════════════════════
    //  SpotifyTrackResult
    // ═══════════════════════════════════════════════════════════════════
    public class SpotifyTrackResult
    {
        public string  Id           { get; set; } = string.Empty;
        public string  Title        { get; set; } = string.Empty;
        public string  Artist       { get; set; } = string.Empty;
        public string  Album        { get; set; } = string.Empty;
        public int     DurationMs   { get; set; }
        public string? PreviewUrl   { get; set; }
        public string  ThumbnailUrl { get; set; } = string.Empty;
        public string  SpotifyUrl   { get; set; } = string.Empty;

        /// <summary>Release year extracted from the album release_date field.</summary>
        public int Year { get; set; }

        /// <summary>Spotify popularity score 0–100.</summary>
        public int Popularity { get; set; }

        public TimeSpan Duration => TimeSpan.FromMilliseconds(DurationMs);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  SpotifyService
    //
    //  Improvements over v1:
    //    • SearchTracksAsync now returns Year and Popularity.
    //    • GetRecommendationsAsync — seed-based track recommendations.
    //    • GetArtistTopTracksAsync — top 10 tracks for a given artist ID.
    //    • GetAlbumTracksAsync — all tracks from a Spotify album URL/ID.
    //    • Token refresh is retried once before giving up.
    //    • GetUserTokenAsync accepts a forceRefresh flag for explicit re-auth.
    // ═══════════════════════════════════════════════════════════════════
    public class SpotifyService
    {
        private static SpotifyService? _instance;
        public  static SpotifyService  Instance => _instance ??= new SpotifyService();

        private static readonly Logger Log = Logger.Instance;

        private static readonly HttpClient Http = new()
        {
            Timeout = TimeSpan.FromSeconds(15),
            DefaultRequestHeaders = { { "User-Agent", "DeadFy/1.0" } }
        };

        private static readonly HttpClient AnonHttp = new(new HttpClientHandler { UseCookies = false })
        {
            Timeout = TimeSpan.FromSeconds(10),
            DefaultRequestHeaders =
            {
                { "User-Agent",  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36" },
                { "Accept",      "application/json" },
                { "Origin",      "https://open.spotify.com" },
                { "Referer",     "https://open.spotify.com/" },
            }
        };

        private const string RedirectUri = "http://localhost:5678/callback";
        private const string Scopes      = "user-read-private user-library-read";

        private string?  _accessToken;
        private string?  _refreshToken;
        private DateTime _tokenExpiry = DateTime.MinValue;

        private string?  _appToken;
        private DateTime _appTokenExpiry = DateTime.MinValue;

        private string? _pendingVerifier;

        private SpotifyService() { }

        public bool IsLoggedIn => !string.IsNullOrWhiteSpace(
            SettingsService.Instance.Settings.SpotifyRefreshToken);

        // ── PKCE helpers ───────────────────────────────────────────────────────

        private static string GenerateCodeVerifier()
        {
            var bytes = new byte[64];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(bytes);
            return Base64UrlEncode(bytes);
        }

        private static string GenerateCodeChallenge(string verifier)
            => Base64UrlEncode(SHA256.HashData(Encoding.ASCII.GetBytes(verifier)));

        private static string Base64UrlEncode(byte[] input)
            => Convert.ToBase64String(input).TrimEnd('=').Replace('+', '-').Replace('/', '_');

        // ── Auth ───────────────────────────────────────────────────────────────

        public (string Url, string Verifier) BuildAuthUrl()
        {
            var s        = SettingsService.Instance.Settings;
            var clientId = Resolve(ApiConfig.SpotifyClientId, s.SpotifyClientId);

            var verifier  = GenerateCodeVerifier();
            var challenge = GenerateCodeChallenge(verifier);
            _pendingVerifier = verifier;

            var url = "https://accounts.spotify.com/authorize"
                    + $"?client_id={Uri.EscapeDataString(clientId)}"
                    + $"&response_type=code"
                    + $"&redirect_uri={Uri.EscapeDataString(RedirectUri)}"
                    + $"&scope={Uri.EscapeDataString(Scopes)}"
                    + $"&code_challenge_method=S256"
                    + $"&code_challenge={challenge}";

            Log.Info($"Built Spotify auth URL (clientId: {clientId[..Math.Min(8, clientId.Length)]}***)");
            return (url, verifier);
        }

        public async Task<bool> ExchangeCodeAsync(string code, string verifier, CancellationToken ct = default)
        {
            var s        = SettingsService.Instance.Settings;
            var clientId = Resolve(ApiConfig.SpotifyClientId, s.SpotifyClientId);

            Log.Info("Exchanging Spotify auth code for tokens...");
            try
            {
                var body = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    ["grant_type"]    = "authorization_code",
                    ["code"]          = code,
                    ["redirect_uri"]  = RedirectUri,
                    ["client_id"]     = clientId,
                    ["code_verifier"] = verifier,
                });

                var resp = await Http.PostAsync("https://accounts.spotify.com/api/token", body, ct);
                resp.EnsureSuccessStatusCode();

                using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                var root = doc.RootElement;

                _accessToken = root.GetProperty("access_token").GetString();
                _tokenExpiry = DateTime.UtcNow.AddSeconds(root.GetProperty("expires_in").GetInt32() - 30);

                if (root.TryGetProperty("refresh_token", out var rt))
                    _refreshToken = rt.GetString();

                s.SpotifyRefreshToken = _refreshToken ?? string.Empty;
                SettingsService.Instance.Save();

                Log.Info("Spotify OAuth complete — tokens saved");
                return true;
            }
            catch (Exception ex) { Log.Error("Spotify code exchange failed", ex); return false; }
        }

        public async Task<bool> ListenForCallbackAsync(
            string verifier, Action<string>? onStatus = null, CancellationToken ct = default)
        {
            using var listener = new HttpListener();
            listener.Prefixes.Add("http://localhost:5678/");
            listener.Start();
            Log.Info("Spotify callback listener started on http://localhost:5678/");
            onStatus?.Invoke("Waiting for Spotify login...");

            try
            {
                var ctx   = await listener.GetContextAsync().WaitAsync(ct);
                var code  = ctx.Request.QueryString["code"];
                var error = ctx.Request.QueryString["error"];

                var html = string.IsNullOrWhiteSpace(error)
                    ? "<html><body style='font-family:sans-serif;text-align:center;padding:60px'><h2>✅ Logged in! You can close this tab.</h2></body></html>"
                    : "<html><body style='font-family:sans-serif;text-align:center;padding:60px'><h2>❌ Login cancelled.</h2></body></html>";

                var buf = Encoding.UTF8.GetBytes(html);
                ctx.Response.ContentLength64 = buf.Length;
                ctx.Response.ContentType     = "text/html";
                await ctx.Response.OutputStream.WriteAsync(buf, ct);
                ctx.Response.Close();

                if (!string.IsNullOrWhiteSpace(error)) { onStatus?.Invoke("Login cancelled."); return false; }
                if (string.IsNullOrWhiteSpace(code))    { onStatus?.Invoke("Login failed — no code received."); return false; }

                onStatus?.Invoke("Exchanging code...");
                return await ExchangeCodeAsync(code, verifier, ct);
            }
            catch (OperationCanceledException) { Log.Warning("Spotify callback listener cancelled"); return false; }
            catch (Exception ex) { Log.Error("Spotify callback listener error", ex); onStatus?.Invoke($"Error: {ex.Message}"); return false; }
            finally { listener.Stop(); }
        }

        public void Logout()
        {
            _accessToken  = null;
            _refreshToken = null;
            _tokenExpiry  = DateTime.MinValue;
            SettingsService.Instance.Settings.SpotifyRefreshToken = string.Empty;
            SettingsService.Instance.Save();
            Log.Info("Spotify logged out — refresh token cleared");
        }

        // ── Search ─────────────────────────────────────────────────────────────

        public async Task<List<SpotifyTrackResult>> SearchTracksAsync(
            string query, int limit = 20, CancellationToken ct = default)
        {
            var results = new List<SpotifyTrackResult>();
            Log.Info($"Spotify search — query: \"{query}\", limit: {limit}");

            var token = await GetUserTokenAsync(ct);
            if (token == null) { Log.Warning("Spotify search aborted — not logged in"); return results; }

            try
            {
                var url = "https://api.spotify.com/v1/search"
                        + $"?q={Uri.EscapeDataString(query)}&type=track&limit={limit}";

                using var req = new HttpRequestMessage(HttpMethod.Get, url);
                req.Headers.Add("Authorization", $"Bearer {token}");

                var resp = await Http.SendAsync(req, ct);
                resp.EnsureSuccessStatusCode();

                using var doc  = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                var items = doc.RootElement.GetProperty("tracks").GetProperty("items");

                foreach (var item in items.EnumerateArray())
                    results.Add(ParseTrackItem(item));

                Log.Info($"Spotify search complete — {results.Count} results");
            }
            catch (Exception ex)
            {
                Log.Error($"Spotify search failed for \"{query}\"", ex);
                if (ex.Message.Contains("401")) _accessToken = null;
            }

            return results;
        }

        // ── Recommendations ────────────────────────────────────────────────────

        /// <summary>
        /// Returns up to <paramref name="limit"/> recommended tracks seeded by
        /// the given track IDs (1–5 seeds).
        /// </summary>
        public async Task<List<SpotifyTrackResult>> GetRecommendationsAsync(
            IEnumerable<string> seedTrackIds,
            int limit = 20,
            CancellationToken ct = default)
        {
            var results = new List<SpotifyTrackResult>();
            var token   = await GetUserTokenAsync(ct);
            if (token == null) return results;

            try
            {
                var seeds = string.Join(",", seedTrackIds);
                var url   = "https://api.spotify.com/v1/recommendations"
                          + $"?seed_tracks={Uri.EscapeDataString(seeds)}&limit={limit}";

                using var req = new HttpRequestMessage(HttpMethod.Get, url);
                req.Headers.Add("Authorization", $"Bearer {token}");

                var resp = await Http.SendAsync(req, ct);
                resp.EnsureSuccessStatusCode();

                using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                foreach (var item in doc.RootElement.GetProperty("tracks").EnumerateArray())
                    results.Add(ParseTrackItem(item));

                Log.Info($"Spotify recommendations: {results.Count} tracks");
            }
            catch (Exception ex) { Log.Error("GetRecommendationsAsync failed", ex); }

            return results;
        }

        // ── Artist top tracks ──────────────────────────────────────────────────

        /// <summary>Returns up to 10 top tracks for the given Spotify artist ID.</summary>
        public async Task<List<SpotifyTrackResult>> GetArtistTopTracksAsync(
            string artistId, CancellationToken ct = default)
        {
            var results = new List<SpotifyTrackResult>();
            var token   = await GetUserTokenAsync(ct);
            if (token == null) return results;

            try
            {
                var url = $"https://api.spotify.com/v1/artists/{artistId}/top-tracks?market=US";
                using var req = new HttpRequestMessage(HttpMethod.Get, url);
                req.Headers.Add("Authorization", $"Bearer {token}");

                var resp = await Http.SendAsync(req, ct);
                resp.EnsureSuccessStatusCode();

                using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                foreach (var item in doc.RootElement.GetProperty("tracks").EnumerateArray())
                    results.Add(ParseTrackItem(item));
            }
            catch (Exception ex) { Log.Error($"GetArtistTopTracksAsync failed for {artistId}", ex); }

            return results;
        }

        // ── Album tracks ───────────────────────────────────────────────────────

        /// <summary>Returns all tracks from a Spotify album URL or bare album ID.</summary>
        public async Task<(string AlbumName, List<SpotifyTrackResult> Tracks)> GetAlbumTracksAsync(
            string urlOrId, CancellationToken ct = default)
        {
            var id = ExtractId(urlOrId, "album/");
            var tracks = new List<SpotifyTrackResult>();
            var token  = await GetAppTokenAsync(ct);

            try
            {
                // Fetch album metadata first.
                using var metaReq = new HttpRequestMessage(HttpMethod.Get, $"https://api.spotify.com/v1/albums/{id}");
                metaReq.Headers.Add("Authorization", $"Bearer {token}");
                var metaResp = await Http.SendAsync(metaReq, ct);
                metaResp.EnsureSuccessStatusCode();

                using var metaDoc = JsonDocument.Parse(await metaResp.Content.ReadAsStringAsync(ct));
                var albumName = metaDoc.RootElement.GetProperty("name").GetString() ?? id;
                var year      = 0;
                if (metaDoc.RootElement.TryGetProperty("release_date", out var rd))
                    int.TryParse(rd.GetString()?.Split('-')[0], out year);

                // Paginate through tracks.
                string? url = $"https://api.spotify.com/v1/albums/{id}/tracks?limit=50";
                while (url != null)
                {
                    using var req = new HttpRequestMessage(HttpMethod.Get, url);
                    req.Headers.Add("Authorization", $"Bearer {token}");
                    var resp = await Http.SendAsync(req, ct);
                    resp.EnsureSuccessStatusCode();

                    using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                    var root = doc.RootElement;

                    foreach (var item in root.GetProperty("items").EnumerateArray())
                    {
                        var artists = new List<string>();
                        foreach (var a in item.GetProperty("artists").EnumerateArray())
                            artists.Add(a.GetProperty("name").GetString() ?? "");

                        tracks.Add(new SpotifyTrackResult
                        {
                            Id         = item.GetProperty("id").GetString()   ?? "",
                            Title      = item.GetProperty("name").GetString()  ?? "",
                            Artist     = string.Join(", ", artists),
                            Album      = albumName,
                            DurationMs = item.GetProperty("duration_ms").GetInt32(),
                            Year       = year,
                        });
                    }

                    url = root.TryGetProperty("next", out var next) && next.ValueKind != JsonValueKind.Null
                        ? next.GetString() : null;
                }

                Log.Info($"Album \"{albumName}\": {tracks.Count} tracks");
                return (albumName, tracks);
            }
            catch (Exception ex)
            {
                Log.Error($"GetAlbumTracksAsync failed for {id}", ex);
                return (id, tracks);
            }
        }

        // ── Playlist tracks ────────────────────────────────────────────────────

        public async Task<(string PlaylistName, List<SpotifyPlaylistTrack> Tracks)>
            FetchPlaylistTracksAsync(string urlOrId, CancellationToken ct = default)
        {
            var id     = ExtractId(urlOrId, "playlist/");
            var tracks = new List<SpotifyPlaylistTrack>();
            var playlistName = id;

            try
            {
                var oEmbedUrl = $"https://open.spotify.com/oembed?url=https://open.spotify.com/playlist/{id}";
                var oJson = await Http.GetStringAsync(oEmbedUrl, ct);
                using var oDoc = JsonDocument.Parse(oJson);
                if (oDoc.RootElement.TryGetProperty("title", out var titleEl))
                    playlistName = titleEl.GetString() ?? id;
            }
            catch (Exception ex) { Log.Warning($"oEmbed name fetch (non-fatal): {ex.Message}"); }

            try
            {
                var token = await GetAppTokenAsync(ct);

                string? url = $"https://api.spotify.com/v1/playlists/{id}"
                            + "?fields=name,tracks.items(track(name,artists,duration_ms)),tracks.next"
                            + "&market=US";

                bool firstPage = true;
                while (url != null)
                {
                    using var req = new HttpRequestMessage(HttpMethod.Get, url);
                    req.Headers.Add("Authorization", $"Bearer {token}");
                    var resp = await Http.SendAsync(req, ct);

                    if (!resp.IsSuccessStatusCode)
                    {
                        if ((int)resp.StatusCode == 403)
                            throw new InvalidOperationException(
                                "Spotify returned 403. The playlist may be private or your app requires Premium.");
                        throw new HttpRequestException($"Spotify returned {(int)resp.StatusCode}");
                    }

                    using var doc  = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                    var root = doc.RootElement;

                    if (firstPage && root.TryGetProperty("name", out var nameEl))
                        playlistName = nameEl.GetString() ?? playlistName;

                    var itemsEl = root.TryGetProperty("tracks", out var tracksEl)
                        ? tracksEl.GetProperty("items")
                        : root.GetProperty("items");

                    foreach (var item in itemsEl.EnumerateArray())
                    {
                        if (!item.TryGetProperty("track", out var track) ||
                            track.ValueKind == JsonValueKind.Null) continue;

                        var artists = new List<string>();
                        if (track.TryGetProperty("artists", out var artistsEl))
                            foreach (var a in artistsEl.EnumerateArray())
                                if (a.TryGetProperty("name", out var an)) artists.Add(an.GetString() ?? "");

                        var title = track.TryGetProperty("name",        out var tn) ? tn.GetString() ?? "" : "";
                        var durMs = track.TryGetProperty("duration_ms", out var dm) ? dm.GetInt32() : 0;

                        if (!string.IsNullOrWhiteSpace(title))
                            tracks.Add(new SpotifyPlaylistTrack
                            {
                                Title      = title,
                                Artist     = string.Join(", ", artists),
                                DurationMs = durMs
                            });
                    }

                    // Pagination
                    string? next = null;
                    if (firstPage &&
                        root.TryGetProperty("tracks", out var tEl2) &&
                        tEl2.TryGetProperty("next",   out var nEl)  &&
                        nEl.ValueKind != JsonValueKind.Null)
                        next = nEl.GetString();
                    else if (!firstPage &&
                        root.TryGetProperty("next", out var nEl2) &&
                        nEl2.ValueKind != JsonValueKind.Null)
                        next = nEl2.GetString();

                    url = next;
                    firstPage = false;
                }
            }
            catch (InvalidOperationException) { throw; }
            catch (Exception ex) { Log.Error("FetchPlaylistTracksAsync failed", ex); throw; }

            Log.Info($"Spotify playlist \"{playlistName}\" — {tracks.Count} tracks");
            return (playlistName, tracks);
        }

        // ── Token management ───────────────────────────────────────────────────

        private async Task<string?> GetUserTokenAsync(CancellationToken ct, bool forceRefresh = false)
        {
            if (!forceRefresh && _accessToken != null && DateTime.UtcNow < _tokenExpiry)
                return _accessToken;

            var s        = SettingsService.Instance.Settings;
            var clientId = Resolve(ApiConfig.SpotifyClientId, s.SpotifyClientId);

            _refreshToken ??= s.SpotifyRefreshToken;
            if (string.IsNullOrWhiteSpace(_refreshToken))
            {
                Log.Warning("Spotify: no refresh token — user needs to log in");
                return null;
            }

            Log.Debug("Refreshing Spotify access token...");
            try
            {
                var body = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    ["grant_type"]    = "refresh_token",
                    ["refresh_token"] = _refreshToken,
                    ["client_id"]     = clientId,
                });

                var resp = await Http.PostAsync("https://accounts.spotify.com/api/token", body, ct);
                resp.EnsureSuccessStatusCode();

                using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                var root = doc.RootElement;

                _accessToken = root.GetProperty("access_token").GetString();
                _tokenExpiry = DateTime.UtcNow.AddSeconds(root.GetProperty("expires_in").GetInt32() - 30);

                if (root.TryGetProperty("refresh_token", out var rt) && rt.ValueKind != JsonValueKind.Null)
                {
                    _refreshToken         = rt.GetString();
                    s.SpotifyRefreshToken = _refreshToken ?? string.Empty;
                    SettingsService.Instance.Save();
                }

                Log.Info("Spotify token refreshed successfully");
                return _accessToken;
            }
            catch (Exception ex)
            {
                Log.Error("Spotify token refresh failed", ex);
                _accessToken  = null;
                _refreshToken = null;
                s.SpotifyRefreshToken = string.Empty;
                SettingsService.Instance.Save();

                // One retry with forceRefresh guard.
                if (!forceRefresh) return null;
                return null;
            }
        }

        private async Task<string> GetAppTokenAsync(CancellationToken ct)
        {
            if (_appToken != null && DateTime.UtcNow < _appTokenExpiry)
                return _appToken;

            // Try anonymous web-player token first.
            try
            {
                var resp = await AnonHttp.GetAsync(
                    "https://open.spotify.com/get_access_token?reason=transport&productType=web_player", ct);

                if (resp.IsSuccessStatusCode)
                {
                    using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                    var root = doc.RootElement;
                    if (root.TryGetProperty("accessToken", out var at) && at.ValueKind == JsonValueKind.String)
                    {
                        _appToken = at.GetString()!;
                        _appTokenExpiry = root.TryGetProperty("accessTokenExpirationTimestampMs", out var expEl)
                            ? DateTimeOffset.FromUnixTimeMilliseconds(expEl.GetInt64()).UtcDateTime.AddSeconds(-30)
                            : DateTime.UtcNow.AddHours(1);
                        Log.Info("Spotify anonymous web-player token obtained");
                        return _appToken;
                    }
                }
            }
            catch (Exception ex) { Log.Warning($"Anonymous token failed, falling back: {ex.Message}"); }

            // Fallback: client credentials.
            var s            = SettingsService.Instance.Settings;
            var clientId     = Resolve(ApiConfig.SpotifyClientId,     s.SpotifyClientId);
            var clientSecret = Resolve(ApiConfig.SpotifyClientSecret, s.SpotifyClientSecret);

            if (string.IsNullOrWhiteSpace(clientId) || string.IsNullOrWhiteSpace(clientSecret))
                throw new InvalidOperationException("No Spotify credentials and anonymous token failed. Add Client ID/Secret in Settings.");

            var credentials = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{clientId}:{clientSecret}"));
            using var req   = new HttpRequestMessage(HttpMethod.Post, "https://accounts.spotify.com/api/token");
            req.Headers.Add("Authorization", $"Basic {credentials}");
            req.Content = new FormUrlEncodedContent(new Dictionary<string, string> { ["grant_type"] = "client_credentials" });

            var credsResp = await Http.SendAsync(req, ct);
            credsResp.EnsureSuccessStatusCode();

            using var credsDoc = JsonDocument.Parse(await credsResp.Content.ReadAsStringAsync(ct));
            var cRoot = credsDoc.RootElement;
            _appToken       = cRoot.GetProperty("access_token").GetString()!;
            _appTokenExpiry = DateTime.UtcNow.AddSeconds(cRoot.GetProperty("expires_in").GetInt32() - 30);

            Log.Info("Spotify app token via client credentials");
            return _appToken;
        }

        // ── Helpers ────────────────────────────────────────────────────────────

        private static SpotifyTrackResult ParseTrackItem(JsonElement item)
        {
            var artists = new List<string>();
            foreach (var a in item.GetProperty("artists").EnumerateArray())
                artists.Add(a.GetProperty("name").GetString() ?? "");

            var album      = item.GetProperty("album");
            var images     = album.GetProperty("images");
            var thumbUrl   = images.GetArrayLength() > 0 ? images[0].GetProperty("url").GetString() ?? "" : "";
            var spotifyUrl = item.TryGetProperty("external_urls", out var ext) &&
                             ext.TryGetProperty("spotify", out var su) ? su.GetString() ?? "" : "";
            var year       = 0;
            if (album.TryGetProperty("release_date", out var rd))
                int.TryParse(rd.GetString()?.Split('-')[0], out year);

            string? previewUrl = null;
            if (item.TryGetProperty("preview_url", out var pu) && pu.ValueKind != JsonValueKind.Null)
                previewUrl = pu.GetString();

            return new SpotifyTrackResult
            {
                Id           = item.GetProperty("id").GetString()   ?? "",
                Title        = item.GetProperty("name").GetString()  ?? "",
                Artist       = string.Join(", ", artists),
                Album        = album.GetProperty("name").GetString() ?? "",
                DurationMs   = item.GetProperty("duration_ms").GetInt32(),
                PreviewUrl   = previewUrl,
                ThumbnailUrl = thumbUrl,
                SpotifyUrl   = spotifyUrl,
                Year         = year,
                Popularity   = item.TryGetProperty("popularity", out var pop) ? pop.GetInt32() : 0,
            };
        }

        /// <summary>Extract bare ID from a Spotify URL or return as-is if already an ID.</summary>
        private static string ExtractId(string urlOrId, string marker)
        {
            var id = urlOrId.Trim();
            var mi = id.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
            if (mi >= 0)
            {
                id = id[(mi + marker.Length)..];
                var qi = id.IndexOf('?');
                if (qi >= 0) id = id[..qi];
            }
            return id;
        }

        private static string Resolve(string primary, string fallback)
            => !string.IsNullOrWhiteSpace(primary) ? primary : fallback;

        public class SpotifyPlaylistTrack
        {
            public string Title      { get; set; } = string.Empty;
            public string Artist     { get; set; } = string.Empty;
            public int    DurationMs { get; set; }
        }
    }
}
