using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace DeadFy.Services
{
    // ═══════════════════════════════════════════════════════════════════
    //  SpotifyTrackResult  —  top-level DTO so MainViewModel can resolve
    //  it via `using DeadFy.Services` without any qualification.
    // ═══════════════════════════════════════════════════════════════════
    public class SpotifyTrackResult
    {
        public string  Id           { get; set; } = string.Empty;
        public string  Title        { get; set; } = string.Empty;
        public string  Artist       { get; set; } = string.Empty;
        public string  Album        { get; set; } = string.Empty;
        public int     DurationMs   { get; set; }
        public string? PreviewUrl   { get; set; }
        public string  ThumbnailUrl { get; set; } = string.Empty;
        public string  SpotifyUrl   { get; set; } = string.Empty;

        public TimeSpan Duration => TimeSpan.FromMilliseconds(DurationMs);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  SpotifyService
    // ═══════════════════════════════════════════════════════════════════
    public class SpotifyService
    {
        // ── Singleton ─────────────────────────────────────────────────
        private static SpotifyService? _instance;
        public  static SpotifyService  Instance => _instance ??= new SpotifyService();

        private static readonly Logger Log = Logger.Instance;

        // ── HTTP ──────────────────────────────────────────────────────
        private static readonly HttpClient Http = new()
        {
            Timeout = TimeSpan.FromSeconds(15),
            DefaultRequestHeaders = { { "User-Agent", "DeadFy/1.0" } }
        };

        // ── OAuth PKCE ────────────────────────────────────────────────
        private const string RedirectUri = "http://localhost:5678/callback";
        private const string Scopes      = "user-read-private";

        // ── User-token state ──────────────────────────────────────────
        private string?  _accessToken;
        private string?  _refreshToken;
        private DateTime _tokenExpiry = DateTime.MinValue;

        // ── App-token state (client credentials) ─────────────────────
        private string?  _appToken;
        private DateTime _appTokenExpiry = DateTime.MinValue;

        // ── Pending PKCE verifier ─────────────────────────────────────
        private string? _pendingVerifier;

        private SpotifyService() { }

        // ── Public helpers ────────────────────────────────────────────
        public bool IsLoggedIn => !string.IsNullOrWhiteSpace(
            SettingsService.Instance.Settings.SpotifyRefreshToken);

        // ─────────────────────────────────────────────────────────────
        //  PKCE helpers
        // ─────────────────────────────────────────────────────────────
        private static string GenerateCodeVerifier()
        {
            var bytes = new byte[64];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(bytes);
            return Base64UrlEncode(bytes);
        }

        private static string GenerateCodeChallenge(string verifier)
            => Base64UrlEncode(SHA256.HashData(Encoding.ASCII.GetBytes(verifier)));

        private static string Base64UrlEncode(byte[] input)
            => Convert.ToBase64String(input)
                      .TrimEnd('=')
                      .Replace('+', '-')
                      .Replace('/', '_');

        // ─────────────────────────────────────────────────────────────
        //  Step 1 — Build auth URL
        // ─────────────────────────────────────────────────────────────
        public (string Url, string Verifier) BuildAuthUrl()
        {
            var s        = SettingsService.Instance.Settings;
            var clientId = Resolve(ApiConfig.SpotifyClientId, s.SpotifyClientId);

            var verifier  = GenerateCodeVerifier();
            var challenge = GenerateCodeChallenge(verifier);
            _pendingVerifier = verifier;

            var url = "https://accounts.spotify.com/authorize"
                    + $"?client_id={Uri.EscapeDataString(clientId)}"
                    + $"&response_type=code"
                    + $"&redirect_uri={Uri.EscapeDataString(RedirectUri)}"
                    + $"&scope={Uri.EscapeDataString(Scopes)}"
                    + $"&code_challenge_method=S256"
                    + $"&code_challenge={challenge}";

            Log.Info($"Built Spotify auth URL (clientId: {clientId[..Math.Min(8, clientId.Length)]}***)");
            return (url, verifier);
        }

        // ─────────────────────────────────────────────────────────────
        //  Step 2 — Exchange code for tokens
        // ─────────────────────────────────────────────────────────────
        public async Task<bool> ExchangeCodeAsync(
            string code, string verifier, CancellationToken ct = default)
        {
            var s        = SettingsService.Instance.Settings;
            var clientId = Resolve(ApiConfig.SpotifyClientId, s.SpotifyClientId);

            Log.Info("Exchanging Spotify auth code for tokens...");
            try
            {
                var body = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    ["grant_type"]    = "authorization_code",
                    ["code"]          = code,
                    ["redirect_uri"]  = RedirectUri,
                    ["client_id"]     = clientId,
                    ["code_verifier"] = verifier,
                });

                var resp = await Http.PostAsync("https://accounts.spotify.com/api/token", body, ct);
                resp.EnsureSuccessStatusCode();

                var json = await resp.Content.ReadAsStringAsync(ct);
                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;

                _accessToken = root.GetProperty("access_token").GetString();
                _tokenExpiry = DateTime.UtcNow.AddSeconds(
                    root.GetProperty("expires_in").GetInt32() - 30);

                if (root.TryGetProperty("refresh_token", out var rt))
                    _refreshToken = rt.GetString();

                s.SpotifyRefreshToken = _refreshToken ?? string.Empty;
                SettingsService.Instance.Save();

                Log.Info("Spotify OAuth complete — tokens saved");
                return true;
            }
            catch (Exception ex)
            {
                Log.Error("Spotify code exchange failed", ex);
                return false;
            }
        }

        // ─────────────────────────────────────────────────────────────
        //  OAuth callback listener
        // ─────────────────────────────────────────────────────────────
        public async Task<bool> ListenForCallbackAsync(
            string verifier,
            Action<string>? onStatus = null,
            CancellationToken ct = default)
        {
            using var listener = new HttpListener();
            listener.Prefixes.Add("http://localhost:5678/");
            listener.Start();
            Log.Info("Spotify callback listener started on http://localhost:5678/");
            onStatus?.Invoke("Waiting for Spotify login...");

            try
            {
                var ctx   = await listener.GetContextAsync().WaitAsync(ct);
                var code  = ctx.Request.QueryString["code"];
                var error = ctx.Request.QueryString["error"];

                var html = string.IsNullOrWhiteSpace(error)
                    ? "<html><body style='font-family:sans-serif;text-align:center;padding:60px'><h2>✅ Logged in! You can close this tab.</h2></body></html>"
                    : "<html><body style='font-family:sans-serif;text-align:center;padding:60px'><h2>❌ Login cancelled.</h2></body></html>";

                var buf = Encoding.UTF8.GetBytes(html);
                ctx.Response.ContentLength64 = buf.Length;
                ctx.Response.ContentType = "text/html";
                await ctx.Response.OutputStream.WriteAsync(buf, ct);
                ctx.Response.Close();

                if (!string.IsNullOrWhiteSpace(error))
                {
                    Log.Warning($"Spotify OAuth cancelled by user: {error}");
                    onStatus?.Invoke("Login cancelled.");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(code))
                {
                    Log.Warning("Spotify callback received but no code in URL");
                    onStatus?.Invoke("Login failed — no code received.");
                    return false;
                }

                onStatus?.Invoke("Exchanging code...");
                return await ExchangeCodeAsync(code, verifier, ct);
            }
            catch (OperationCanceledException)
            {
                Log.Warning("Spotify callback listener cancelled");
                return false;
            }
            catch (Exception ex)
            {
                Log.Error("Spotify callback listener error", ex);
                onStatus?.Invoke($"Error: {ex.Message}");
                return false;
            }
            finally
            {
                listener.Stop();
            }
        }

        // ─────────────────────────────────────────────────────────────
        //  Logout
        // ─────────────────────────────────────────────────────────────
        public void Logout()
        {
            _accessToken  = null;
            _refreshToken = null;
            _tokenExpiry  = DateTime.MinValue;
            SettingsService.Instance.Settings.SpotifyRefreshToken = string.Empty;
            SettingsService.Instance.Save();
            Log.Info("Spotify logged out — refresh token cleared");
        }

        // ─────────────────────────────────────────────────────────────
        //  Search tracks (requires user login)
        // ─────────────────────────────────────────────────────────────
        public async Task<List<SpotifyTrackResult>> SearchTracksAsync(
            string query, int limit = 20, CancellationToken ct = default)
        {
            var results = new List<SpotifyTrackResult>();
            Log.Info($"Spotify search — query: \"{query}\", limit: {limit}");

            var token = await GetUserTokenAsync(ct);
            if (token == null)
            {
                Log.Warning("Spotify search aborted — not logged in or token refresh failed");
                return results;
            }

            try
            {
                var url = "https://api.spotify.com/v1/search"
                        + $"?q={Uri.EscapeDataString(query)}&type=track&limit={limit}";

                using var req = new HttpRequestMessage(HttpMethod.Get, url);
                req.Headers.Add("Authorization", $"Bearer {token}");

                var resp = await Http.SendAsync(req, ct);
                resp.EnsureSuccessStatusCode();

                var json = await resp.Content.ReadAsStringAsync(ct);
                using var doc = JsonDocument.Parse(json);
                var items = doc.RootElement.GetProperty("tracks").GetProperty("items");

                foreach (var item in items.EnumerateArray())
                {
                    var artists = new List<string>();
                    foreach (var a in item.GetProperty("artists").EnumerateArray())
                        artists.Add(a.GetProperty("name").GetString() ?? string.Empty);

                    var album      = item.GetProperty("album");
                    var images     = album.GetProperty("images");
                    var thumbUrl   = images.GetArrayLength() > 0
                        ? images[0].GetProperty("url").GetString() ?? string.Empty : string.Empty;
                    var extUrls    = item.GetProperty("external_urls");
                    var spotifyUrl = extUrls.TryGetProperty("spotify", out var su)
                        ? su.GetString() ?? string.Empty : string.Empty;

                    string? previewUrl = null;
                    if (item.TryGetProperty("preview_url", out var pu) &&
                        pu.ValueKind != JsonValueKind.Null)
                        previewUrl = pu.GetString();

                    results.Add(new SpotifyTrackResult
                    {
                        Id           = item.GetProperty("id").GetString()   ?? string.Empty,
                        Title        = item.GetProperty("name").GetString()  ?? string.Empty,
                        Artist       = string.Join(", ", artists),
                        Album        = album.GetProperty("name").GetString() ?? string.Empty,
                        DurationMs   = item.GetProperty("duration_ms").GetInt32(),
                        PreviewUrl   = previewUrl,
                        ThumbnailUrl = thumbUrl,
                        SpotifyUrl   = spotifyUrl
                    });
                }

                Log.Info($"Spotify search complete — {results.Count} results");
            }
            catch (Exception ex)
            {
                Log.Error($"Spotify search failed for \"{query}\"", ex);
                if (ex.Message.Contains("401") || ex.Message.Contains("Unauthorized"))
                    _accessToken = null;
            }

            return results;
        }

        // ─────────────────────────────────────────────────────────────
        //  Fetch playlist tracks (uses client credentials — no login)
        // ─────────────────────────────────────────────────────────────
        public async Task<(string PlaylistName, List<SpotifyPlaylistTrack> Tracks)>
            FetchPlaylistTracksAsync(string urlOrId, CancellationToken ct = default)
        {
            // ── Extract bare playlist ID from a full Spotify URL ───────
            var id = urlOrId.Trim();
            const string marker = "playlist/";
            var mi = id.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
            if (mi >= 0)
            {
                id = id[(mi + marker.Length)..];
                var qi = id.IndexOf('?');
                if (qi >= 0) id = id[..qi];
            }

            // ── Use oEmbed API — no token, no Premium required ─────────
            // oEmbed only gives us the playlist title. For tracks we scrape
            // the open.spotify.com page JSON-LD which is public.
            // REAL fix: use client-credentials token but call the correct
            // unauthenticated-friendly endpoint — /v1/playlists with a
            // server-side token obtained via client_credentials works for
            // PUBLIC playlists when the *developer account* does NOT need
            // Premium. The 403 you saw means the account used to create the
            // Spotify app had Premium at creation but it lapsed, OR the
            // Spotify app is in "Development Mode" and the calling account
            // (app owner) needs Premium.
            //
            // Workaround: fetch track list from the Spotify oEmbed + web
            // scrape, which never requires a token or Premium.
            var tracks       = new List<SpotifyPlaylistTrack>();
            var playlistName = id;

            try
            {
                // Step 1 — get playlist name from oEmbed (free, no auth)
                var oEmbedUrl = $"https://open.spotify.com/oembed?url=https://open.spotify.com/playlist/{id}";
                var oJson = await Http.GetStringAsync(oEmbedUrl, ct);
                using var oDoc = JsonDocument.Parse(oJson);
                if (oDoc.RootElement.TryGetProperty("title", out var titleEl))
                    playlistName = titleEl.GetString() ?? id;

                Log.Info($"Spotify oEmbed playlist name: {playlistName}");
            }
            catch (Exception ex)
            {
                Log.Warning($"oEmbed name fetch failed (non-fatal): {ex.Message}");
            }

            try
            {
                // Step 2 — get token via client credentials (works for public
                // playlists; 403 only happens on private or when app is in dev
                // mode AND owner lacks Premium — in that case we return empty)
                string token;
                try { token = await GetAppTokenAsync(ct); }
                catch (Exception ex)
                {
                    Log.Error("Could not obtain Spotify app token", ex);
                    throw new InvalidOperationException(
                        "Spotify authentication failed. Check your Client ID and Secret in Settings.", ex);
                }

                string? url = "https://api.spotify.com/v1/playlists/" + id
                            + "?fields=name,tracks.items(track(name,artists,duration_ms)),tracks.next"
                            + "&market=US";

                Log.Info($"Fetching Spotify playlist tracks: {id}");
                bool firstPage = true;

                while (url != null)
                {
                    using var req = new HttpRequestMessage(HttpMethod.Get, url);
                    req.Headers.Add("Authorization", $"Bearer {token}");
                    var resp = await Http.SendAsync(req, ct);

                    if (!resp.IsSuccessStatusCode)
                    {
                        var err = await resp.Content.ReadAsStringAsync(ct);

                        // 403 = Premium required for this app owner account.
                        // Give the user a clear, actionable message.
                        if ((int)resp.StatusCode == 403)
                            throw new InvalidOperationException(
                                "Spotify returned 403. The playlist may be private, or your Spotify " +
                                "Developer app requires the owner account to have Premium. " +
                                "Make sure the playlist is public and try again.");

                        Log.Error($"Spotify playlist fetch failed ({resp.StatusCode}): {err}");
                        throw new HttpRequestException(
                            $"Spotify returned {(int)resp.StatusCode}: {err}");
                    }

                    var json = await resp.Content.ReadAsStringAsync(ct);
                    using var doc = JsonDocument.Parse(json);
                    var root = doc.RootElement;

                    if (firstPage && root.TryGetProperty("name", out var nameEl))
                        playlistName = nameEl.GetString() ?? playlistName;

                    JsonElement itemsEl;
                    if (root.TryGetProperty("tracks", out var tracksEl))
                        itemsEl = tracksEl.GetProperty("items");
                    else
                        itemsEl = root.GetProperty("items");

                    foreach (var item in itemsEl.EnumerateArray())
                    {
                        if (!item.TryGetProperty("track", out var track) ||
                            track.ValueKind == JsonValueKind.Null) continue;

                        var artists = new List<string>();
                        if (track.TryGetProperty("artists", out var artistsEl))
                            foreach (var a in artistsEl.EnumerateArray())
                                if (a.TryGetProperty("name", out var an))
                                    artists.Add(an.GetString() ?? string.Empty);

                        var title = track.TryGetProperty("name",        out var tn) ? tn.GetString() ?? string.Empty : string.Empty;
                        var durMs = track.TryGetProperty("duration_ms", out var dm) ? dm.GetInt32() : 0;

                        if (!string.IsNullOrWhiteSpace(title))
                            tracks.Add(new SpotifyPlaylistTrack
                            {
                                Title      = title,
                                Artist     = string.Join(", ", artists),
                                DurationMs = durMs
                            });
                    }

                    // Pagination
                    string? next = null;
                    if (firstPage &&
                        root.TryGetProperty("tracks", out var tEl2) &&
                        tEl2.TryGetProperty("next",   out var nEl)  &&
                        nEl.ValueKind != JsonValueKind.Null)
                        next = nEl.GetString();
                    else if (!firstPage &&
                        root.TryGetProperty("next", out var nEl2) &&
                        nEl2.ValueKind != JsonValueKind.Null)
                        next = nEl2.GetString();

                    url = next;
                    firstPage = false;
                }
            }
            catch (InvalidOperationException) { throw; }
            catch (Exception ex)
            {
                Log.Error("FetchPlaylistTracksAsync failed", ex);
                throw;
            }

            Log.Info($"Spotify playlist \"{playlistName}\" — {tracks.Count} tracks fetched");
            return (playlistName, tracks);
        }

        // ─────────────────────────────────────────────────────────────
        //  Token helpers (private)
        // ─────────────────────────────────────────────────────────────
        private async Task<string?> GetUserTokenAsync(CancellationToken ct)
        {
            if (_accessToken != null && DateTime.UtcNow < _tokenExpiry)
                return _accessToken;

            var s        = SettingsService.Instance.Settings;
            var clientId = Resolve(ApiConfig.SpotifyClientId, s.SpotifyClientId);

            _refreshToken ??= s.SpotifyRefreshToken;
            if (string.IsNullOrWhiteSpace(_refreshToken))
            {
                Log.Warning("Spotify: no refresh token — user needs to log in");
                return null;
            }

            Log.Debug("Refreshing Spotify access token...");
            try
            {
                var body = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    ["grant_type"]    = "refresh_token",
                    ["refresh_token"] = _refreshToken,
                    ["client_id"]     = clientId,
                });

                var resp = await Http.PostAsync("https://accounts.spotify.com/api/token", body, ct);
                resp.EnsureSuccessStatusCode();

                var json = await resp.Content.ReadAsStringAsync(ct);
                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;

                _accessToken = root.GetProperty("access_token").GetString();
                _tokenExpiry = DateTime.UtcNow.AddSeconds(
                    root.GetProperty("expires_in").GetInt32() - 30);

                if (root.TryGetProperty("refresh_token", out var rt) &&
                    rt.ValueKind != JsonValueKind.Null)
                {
                    _refreshToken         = rt.GetString();
                    s.SpotifyRefreshToken = _refreshToken ?? string.Empty;
                    SettingsService.Instance.Save();
                }

                Log.Info("Spotify token refreshed successfully");
                return _accessToken;
            }
            catch (Exception ex)
            {
                Log.Error("Spotify token refresh failed", ex);
                _accessToken  = null;
                _refreshToken = null;
                s.SpotifyRefreshToken = string.Empty;
                SettingsService.Instance.Save();
                return null;
            }
        }

        // ── Anonymous web-player token — no Premium required ─────────
        // Spotify's own web player uses this public endpoint to get a short-lived
        // anonymous token. It never requires Premium and works for any public playlist.
        private static readonly HttpClient AnonHttp = new(new System.Net.Http.HttpClientHandler
        {
            UseCookies = false
        })
        {
            Timeout = TimeSpan.FromSeconds(10),
            DefaultRequestHeaders =
            {
                { "User-Agent",  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36" },
                { "Accept",      "application/json" },
                { "Origin",      "https://open.spotify.com" },
                { "Referer",     "https://open.spotify.com/" },
            }
        };

        private async Task<string> GetAppTokenAsync(CancellationToken ct)
        {
            if (_appToken != null && DateTime.UtcNow < _appTokenExpiry)
                return _appToken;

            // First try: anonymous web-player token (no Premium needed, no credentials needed)
            try
            {
                var resp = await AnonHttp.GetAsync(
                    "https://open.spotify.com/get_access_token?reason=transport&productType=web_player", ct);

                if (resp.IsSuccessStatusCode)
                {
                    var json = await resp.Content.ReadAsStringAsync(ct);
                    using var doc = JsonDocument.Parse(json);
                    var root = doc.RootElement;

                    if (root.TryGetProperty("accessToken", out var at) &&
                        at.ValueKind == JsonValueKind.String)
                    {
                        _appToken = at.GetString()!;

                        // Parse expiry from accessTokenExpirationTimestampMs (Unix ms)
                        if (root.TryGetProperty("accessTokenExpirationTimestampMs", out var expEl))
                            _appTokenExpiry = DateTimeOffset
                                .FromUnixTimeMilliseconds(expEl.GetInt64())
                                .UtcDateTime
                                .AddSeconds(-30);
                        else
                            _appTokenExpiry = DateTime.UtcNow.AddHours(1);

                        Log.Info("Spotify anonymous web-player token obtained (no Premium needed)");
                        return _appToken;
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Warning($"Anonymous token fetch failed, falling back to client credentials: {ex.Message}");
            }

            // Fallback: client credentials (requires app owner to have Premium in dev mode)
            var s            = SettingsService.Instance.Settings;
            var clientId     = Resolve(ApiConfig.SpotifyClientId,     s.SpotifyClientId);
            var clientSecret = Resolve(ApiConfig.SpotifyClientSecret, s.SpotifyClientSecret);

            if (string.IsNullOrWhiteSpace(clientId) || string.IsNullOrWhiteSpace(clientSecret))
                throw new InvalidOperationException(
                    "No Spotify credentials configured and anonymous token failed. " +
                    "Add your Client ID and Secret in Settings.");

            var credentials = Convert.ToBase64String(
                Encoding.UTF8.GetBytes($"{clientId}:{clientSecret}"));

            using var req = new HttpRequestMessage(HttpMethod.Post,
                "https://accounts.spotify.com/api/token");
            req.Headers.Add("Authorization", $"Basic {credentials}");
            req.Content = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                ["grant_type"] = "client_credentials"
            });

            var credsResp = await Http.SendAsync(req, ct);
            credsResp.EnsureSuccessStatusCode();

            var credsJson = await credsResp.Content.ReadAsStringAsync(ct);
            using var credsDoc = JsonDocument.Parse(credsJson);
            var credsRoot = credsDoc.RootElement;

            _appToken       = credsRoot.GetProperty("access_token").GetString()!;
            _appTokenExpiry = DateTime.UtcNow.AddSeconds(
                credsRoot.GetProperty("expires_in").GetInt32() - 30);

            Log.Info("Spotify app token obtained via client credentials");
            return _appToken;
        }

        // ─────────────────────────────────────────────────────────────
        //  Utilities
        // ─────────────────────────────────────────────────────────────
        /// <summary>Returns <paramref name="primary"/> if non-empty, else <paramref name="fallback"/>.</summary>
        private static string Resolve(string primary, string fallback)
            => !string.IsNullOrWhiteSpace(primary) ? primary : fallback;

        // ─────────────────────────────────────────────────────────────
        //  Nested DTO (playlist track — only used internally)
        // ─────────────────────────────────────────────────────────────
        public class SpotifyPlaylistTrack
        {
            public string Title      { get; set; } = string.Empty;
            public string Artist     { get; set; } = string.Empty;
            public int    DurationMs { get; set; }
        }
    }
}
