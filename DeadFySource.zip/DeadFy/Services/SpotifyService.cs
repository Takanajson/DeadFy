using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace DeadFy.Services
{
    // ═══════════════════════════════════════════════════════════════════
    //  Data models
    // ═══════════════════════════════════════════════════════════════════

    public class SpotifyTrackResult
    {
        public string  Id           { get; set; } = string.Empty;
        public string  Title        { get; set; } = string.Empty;
        public string  Artist       { get; set; } = string.Empty;
        public string  Album        { get; set; } = string.Empty;
        public int     DurationMs   { get; set; }
        public string? PreviewUrl   { get; set; }
        public string  ThumbnailUrl { get; set; } = string.Empty;
        public string  SpotifyUrl   { get; set; } = string.Empty;
        public int     Year         { get; set; }
        public int     Popularity   { get; set; }
        public TimeSpan Duration => TimeSpan.FromMilliseconds(DurationMs);
    }

    /// <summary>A Spotify playback device (phone, desktop, speaker, etc.).</summary>
    public class SpotifyDevice
    {
        public string  Id            { get; set; } = string.Empty;
        public string  Name          { get; set; } = string.Empty;
        public string  Type          { get; set; } = string.Empty;   // Computer, Smartphone, Speaker …
        public bool    IsActive      { get; set; }
        public bool    IsRestricted  { get; set; }
        public int     VolumePercent { get; set; }
    }

    /// <summary>Snapshot of what is currently playing on the user's Spotify account.</summary>
    public class SpotifyCurrentlyPlaying
    {
        public SpotifyTrackResult? Track        { get; set; }
        public bool                IsPlaying    { get; set; }
        public int                 ProgressMs   { get; set; }
        public string?             DeviceId     { get; set; }
        public string?             DeviceName   { get; set; }
        public int                 DeviceVolume { get; set; }
        public string              RepeatState  { get; set; } = "off";  // off | context | track
        public bool                ShuffleState { get; set; }
        public TimeSpan Progress => TimeSpan.FromMilliseconds(ProgressMs);
    }

    /// <summary>Audio analysis data returned by the Spotify Audio Features endpoint.</summary>
    public class SpotifyAudioFeatures
    {
        public string TrackId           { get; set; } = string.Empty;
        public float  Danceability      { get; set; }   // 0.0–1.0
        public float  Energy            { get; set; }   // 0.0–1.0
        public int    Key               { get; set; }   // Pitch class (0=C … 11=B), -1=unknown
        public float  Loudness          { get; set; }   // dB, typically -60–0
        public int    Mode              { get; set; }   // 0=minor, 1=major
        public float  Speechiness       { get; set; }
        public float  Acousticness      { get; set; }
        public float  Instrumentalness  { get; set; }
        public float  Liveness          { get; set; }
        public float  Valence           { get; set; }   // musical positiveness 0–1
        public float  Tempo             { get; set; }   // BPM
        public int    TimeSignature     { get; set; }

        public string KeyName => Key switch
        {
            0 => "C",  1 => "C#/Db", 2 => "D",  3 => "D#/Eb",
            4 => "E",  5 => "F",     6 => "F#/Gb", 7 => "G",
            8 => "G#/Ab", 9 => "A", 10 => "A#/Bb", 11 => "B",
            _ => "Unknown"
        };
        public string ModeName => Mode == 1 ? "Major" : "Minor";
    }

    // ═══════════════════════════════════════════════════════════════════
    //  SpotifyService  —  Premium-tier features
    //
    //  Premium features:
    //    GetCurrentlyPlayingAsync  — live now-playing snapshot
    //    GetDevicesAsync           — list Spotify Connect devices
    //    TransferPlaybackAsync     — move playback to another device
    //    PlayAsync / PauseAsync    — remote playback control
    //    NextTrackAsync / PreviousTrackAsync
    //    SetVolumeAsync            — device volume (0–100)
    //    SetRepeatAsync            — off | context | track
    //    SetShuffleAsync
    //    SeekAsync                 — jump to position in ms
    //    AddToQueueAsync           — add a track URI to the play queue
    //    GetQueueAsync             — get current play queue
    //    GetSavedTracksAsync       — user's Liked Songs (paginated)
    //    SaveTracksAsync / RemoveSavedTracksAsync
    //    CheckSavedTracksAsync     — are specific tracks in Liked Songs?
    //    GetAudioFeaturesAsync     — danceability, energy, BPM, key …
    //    GetAudioFeaturesBatchAsync
    //    GetRecommendationsAsync   — mood-aware seed-based recommendations
    //    GetArtistTopTracksAsync
    //    GetAlbumTracksAsync
    //    FetchPlaylistTracksAsync
    //
    //  Removed: SearchTracksAsync (use YouTube search instead)
    // ═══════════════════════════════════════════════════════════════════
    public class SpotifyService
    {
        private static SpotifyService? _instance;
        public  static SpotifyService  Instance => _instance ??= new SpotifyService();

        private static readonly Logger Log = Logger.Instance;

        private static readonly HttpClient Http = new()
        {
            Timeout = TimeSpan.FromSeconds(15),
            DefaultRequestHeaders = { { "User-Agent", "DeadFy/1.0" } }
        };

        private static readonly HttpClient AnonHttp = new(new HttpClientHandler { UseCookies = false })
        {
            Timeout = TimeSpan.FromSeconds(10),
            DefaultRequestHeaders =
            {
                { "User-Agent",  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36" },
                { "Accept",      "application/json" },
                { "Origin",      "https://open.spotify.com" },
                { "Referer",     "https://open.spotify.com/" },
            }
        };

        private const string RedirectUri = "http://localhost:5678/callback";

        // Full Premium scope set.
        private const string Scopes =
            "user-read-private " +
            "user-read-email " +
            "user-library-read " +
            "user-library-modify " +
            "user-read-playback-state " +
            "user-modify-playback-state " +
            "user-read-currently-playing " +
            "streaming " +
            "playlist-read-private " +
            "playlist-read-collaborative";

        private string?  _accessToken;
        private string?  _refreshToken;
        private DateTime _tokenExpiry    = DateTime.MinValue;
        private string?  _appToken;
        private DateTime _appTokenExpiry = DateTime.MinValue;

        private SpotifyService() { }

        public bool IsLoggedIn => !string.IsNullOrWhiteSpace(
            SettingsService.Instance.Settings.SpotifyRefreshToken);

        // ── PKCE helpers ───────────────────────────────────────────────────────

        private static string GenerateCodeVerifier()
        {
            var bytes = new byte[64];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(bytes);
            return Base64UrlEncode(bytes);
        }

        private static string GenerateCodeChallenge(string verifier)
            => Base64UrlEncode(SHA256.HashData(Encoding.ASCII.GetBytes(verifier)));

        private static string Base64UrlEncode(byte[] input)
            => Convert.ToBase64String(input).TrimEnd('=').Replace('+', '-').Replace('/', '_');

        // ── Auth ───────────────────────────────────────────────────────────────

        public (string Url, string Verifier) BuildAuthUrl()
        {
            var s        = SettingsService.Instance.Settings;
            var clientId = Resolve(ApiConfig.SpotifyClientId, s.SpotifyClientId);

            var verifier  = GenerateCodeVerifier();
            var challenge = GenerateCodeChallenge(verifier);

            var url = "https://accounts.spotify.com/authorize"
                    + $"?client_id={Uri.EscapeDataString(clientId)}"
                    + $"&response_type=code"
                    + $"&redirect_uri={Uri.EscapeDataString(RedirectUri)}"
                    + $"&scope={Uri.EscapeDataString(Scopes)}"
                    + $"&code_challenge_method=S256"
                    + $"&code_challenge={challenge}";

            Log.Info($"Built Spotify auth URL (Premium scopes, clientId: {clientId[..Math.Min(8, clientId.Length)]}***)");
            return (url, verifier);
        }

        public async Task<bool> ExchangeCodeAsync(string code, string verifier, CancellationToken ct = default)
        {
            var s        = SettingsService.Instance.Settings;
            var clientId = Resolve(ApiConfig.SpotifyClientId, s.SpotifyClientId);
            Log.Info("Exchanging Spotify auth code for tokens...");
            try
            {
                var body = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    ["grant_type"]    = "authorization_code",
                    ["code"]          = code,
                    ["redirect_uri"]  = RedirectUri,
                    ["client_id"]     = clientId,
                    ["code_verifier"] = verifier,
                });
                var resp = await Http.PostAsync("https://accounts.spotify.com/api/token", body, ct);
                resp.EnsureSuccessStatusCode();
                using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                var root = doc.RootElement;
                _accessToken = root.GetProperty("access_token").GetString();
                _tokenExpiry = DateTime.UtcNow.AddSeconds(root.GetProperty("expires_in").GetInt32() - 30);
                if (root.TryGetProperty("refresh_token", out var rt)) _refreshToken = rt.GetString();
                s.SpotifyRefreshToken = _refreshToken ?? string.Empty;
                SettingsService.Instance.Save();
                Log.Info("Spotify OAuth complete — Premium tokens saved");
                return true;
            }
            catch (Exception ex) { Log.Error("Spotify code exchange failed", ex); return false; }
        }

        public async Task<bool> ListenForCallbackAsync(
            string verifier, Action<string>? onStatus = null, CancellationToken ct = default)
        {
            using var listener = new HttpListener();
            listener.Prefixes.Add("http://localhost:5678/");
            listener.Start();
            onStatus?.Invoke("Waiting for Spotify login...");
            try
            {
                var ctx   = await listener.GetContextAsync().WaitAsync(ct);
                var code  = ctx.Request.QueryString["code"];
                var error = ctx.Request.QueryString["error"];
                var html  = string.IsNullOrWhiteSpace(error)
                    ? "<html><body style='font-family:sans-serif;text-align:center;padding:60px'><h2>Logged in! You can close this tab.</h2></body></html>"
                    : "<html><body style='font-family:sans-serif;text-align:center;padding:60px'><h2>Login cancelled.</h2></body></html>";
                var buf = Encoding.UTF8.GetBytes(html);
                ctx.Response.ContentLength64 = buf.Length;
                ctx.Response.ContentType     = "text/html";
                await ctx.Response.OutputStream.WriteAsync(buf, ct);
                ctx.Response.Close();
                if (!string.IsNullOrWhiteSpace(error)) { onStatus?.Invoke("Login cancelled."); return false; }
                if (string.IsNullOrWhiteSpace(code))    { onStatus?.Invoke("No code received."); return false; }
                onStatus?.Invoke("Exchanging code...");
                return await ExchangeCodeAsync(code, verifier, ct);
            }
            catch (OperationCanceledException) { return false; }
            catch (Exception ex) { Log.Error("Spotify callback error", ex); onStatus?.Invoke($"Error: {ex.Message}"); return false; }
            finally { listener.Stop(); }
        }

        public void Logout()
        {
            _accessToken  = null;
            _refreshToken = null;
            _tokenExpiry  = DateTime.MinValue;
            SettingsService.Instance.Settings.SpotifyRefreshToken = string.Empty;
            SettingsService.Instance.Save();
            Log.Info("Spotify logged out");
        }

        // ═══════════════════════════════════════════════════════════════
        //  PREMIUM — Now Playing & Player State
        // ═══════════════════════════════════════════════════════════════

        /// <summary>Live snapshot of what is currently playing. Returns null when nothing is active.</summary>
        public async Task<SpotifyCurrentlyPlaying?> GetCurrentlyPlayingAsync(CancellationToken ct = default)
        {
            var token = await GetUserTokenAsync(ct);
            if (token == null) return null;
            try
            {
                using var req  = BuildGet("https://api.spotify.com/v1/me/player", token);
                var resp = await Http.SendAsync(req, ct);
                if (resp.StatusCode == System.Net.HttpStatusCode.NoContent) return null;
                resp.EnsureSuccessStatusCode();
                using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                var root = doc.RootElement;
                var result = new SpotifyCurrentlyPlaying
                {
                    IsPlaying    = root.TryGetProperty("is_playing",    out var ip) && ip.GetBoolean(),
                    ProgressMs   = root.TryGetProperty("progress_ms",   out var pm) ? pm.GetInt32() : 0,
                    RepeatState  = root.TryGetProperty("repeat_state",  out var rs) ? rs.GetString() ?? "off" : "off",
                    ShuffleState = root.TryGetProperty("shuffle_state", out var ss) && ss.GetBoolean(),
                };
                if (root.TryGetProperty("device", out var dev))
                {
                    result.DeviceId     = dev.TryGetProperty("id",             out var did) ? did.GetString()  : null;
                    result.DeviceName   = dev.TryGetProperty("name",           out var dn)  ? dn.GetString()   : null;
                    result.DeviceVolume = dev.TryGetProperty("volume_percent", out var dv)  ? dv.GetInt32()    : 0;
                }
                if (root.TryGetProperty("item", out var item) && item.ValueKind != JsonValueKind.Null)
                    result.Track = ParseTrackItem(item);
                return result;
            }
            catch (Exception ex) { Log.Error("GetCurrentlyPlayingAsync failed", ex); return null; }
        }

        // ═══════════════════════════════════════════════════════════════
        //  PREMIUM — Spotify Connect Devices
        // ═══════════════════════════════════════════════════════════════

        /// <summary>Returns all active Spotify Connect devices on the account.</summary>
        public async Task<List<SpotifyDevice>> GetDevicesAsync(CancellationToken ct = default)
        {
            var devices = new List<SpotifyDevice>();
            var token   = await GetUserTokenAsync(ct);
            if (token == null) return devices;
            try
            {
                using var req  = BuildGet("https://api.spotify.com/v1/me/player/devices", token);
                var resp = await Http.SendAsync(req, ct);
                resp.EnsureSuccessStatusCode();
                using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                foreach (var d in doc.RootElement.GetProperty("devices").EnumerateArray())
                    devices.Add(new SpotifyDevice
                    {
                        Id            = d.TryGetProperty("id",             out var id)   ? id.GetString()   ?? "" : "",
                        Name          = d.TryGetProperty("name",           out var name) ? name.GetString() ?? "" : "",
                        Type          = d.TryGetProperty("type",           out var type) ? type.GetString() ?? "" : "",
                        IsActive      = d.TryGetProperty("is_active",      out var ia)   && ia.GetBoolean(),
                        IsRestricted  = d.TryGetProperty("is_restricted",  out var ir)   && ir.GetBoolean(),
                        VolumePercent = d.TryGetProperty("volume_percent", out var vol)  ? vol.GetInt32()   : 0,
                    });
                Log.Info($"GetDevicesAsync: {devices.Count} device(s)");
            }
            catch (Exception ex) { Log.Error("GetDevicesAsync failed", ex); }
            return devices;
        }

        /// <summary>
        /// Transfers playback to <paramref name="deviceId"/>.
        /// Pass <paramref name="play"/>=true to start playing immediately.
        /// </summary>
        public async Task<bool> TransferPlaybackAsync(string deviceId, bool play = true, CancellationToken ct = default)
        {
            var token = await GetUserTokenAsync(ct);
            if (token == null) return false;
            try
            {
                var payload = JsonSerializer.Serialize(new { device_ids = new[] { deviceId }, play });
                using var req = new HttpRequestMessage(HttpMethod.Put, "https://api.spotify.com/v1/me/player");
                req.Headers.Add("Authorization", $"Bearer {token}");
                req.Content = new StringContent(payload, Encoding.UTF8, "application/json");
                var resp = await Http.SendAsync(req, ct);
                Log.Info($"TransferPlayback -> {deviceId}: {(int)resp.StatusCode}");
                return resp.IsSuccessStatusCode;
            }
            catch (Exception ex) { Log.Error("TransferPlaybackAsync failed", ex); return false; }
        }

        // ═══════════════════════════════════════════════════════════════
        //  PREMIUM — Playback Control
        // ═══════════════════════════════════════════════════════════════

        /// <summary>
        /// Starts or resumes playback.
        /// Pass a context URI (album/playlist) or a list of track URIs.
        /// Leave both null to simply resume the current track.
        /// </summary>
        public async Task<bool> PlayAsync(
            string?              contextUri  = null,
            IEnumerable<string>? uris        = null,
            int                  offsetIndex = 0,
            int                  positionMs  = 0,
            string?              deviceId    = null,
            CancellationToken    ct          = default)
        {
            var token = await GetUserTokenAsync(ct);
            if (token == null) return false;
            try
            {
                var endpoint = "https://api.spotify.com/v1/me/player/play";
                if (!string.IsNullOrWhiteSpace(deviceId))
                    endpoint += $"?device_id={Uri.EscapeDataString(deviceId)}";

                object body;
                if (uris != null)
                    body = new { uris, position_ms = positionMs };
                else if (!string.IsNullOrWhiteSpace(contextUri))
                    body = new { context_uri = contextUri, offset = new { position = offsetIndex }, position_ms = positionMs };
                else
                    body = new { position_ms = positionMs };

                using var req = new HttpRequestMessage(HttpMethod.Put, endpoint);
                req.Headers.Add("Authorization", $"Bearer {token}");
                req.Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json");
                var resp = await Http.SendAsync(req, ct);
                return resp.IsSuccessStatusCode || resp.StatusCode == System.Net.HttpStatusCode.NoContent;
            }
            catch (Exception ex) { Log.Error("PlayAsync failed", ex); return false; }
        }

        /// <summary>Pauses playback on the active device.</summary>
        public async Task<bool> PauseAsync(string? deviceId = null, CancellationToken ct = default)
            => await SendPlayerCommandAsync("pause", deviceId, ct);

        /// <summary>Skips to the next track.</summary>
        public async Task<bool> NextTrackAsync(string? deviceId = null, CancellationToken ct = default)
            => await SendPlayerCommandAsync("next", deviceId, ct, HttpMethod.Post);

        /// <summary>Skips to the previous track.</summary>
        public async Task<bool> PreviousTrackAsync(string? deviceId = null, CancellationToken ct = default)
            => await SendPlayerCommandAsync("previous", deviceId, ct, HttpMethod.Post);

        /// <summary>Seeks to <paramref name="positionMs"/> in the current track.</summary>
        public async Task<bool> SeekAsync(int positionMs, string? deviceId = null, CancellationToken ct = default)
        {
            var token = await GetUserTokenAsync(ct);
            if (token == null) return false;
            try
            {
                var url = $"https://api.spotify.com/v1/me/player/seek?position_ms={positionMs}";
                if (!string.IsNullOrWhiteSpace(deviceId)) url += $"&device_id={deviceId}";
                using var req = new HttpRequestMessage(HttpMethod.Put, url);
                req.Headers.Add("Authorization", $"Bearer {token}");
                req.Content = new StringContent("{}", Encoding.UTF8, "application/json");
                var resp = await Http.SendAsync(req, ct);
                return resp.IsSuccessStatusCode || resp.StatusCode == System.Net.HttpStatusCode.NoContent;
            }
            catch (Exception ex) { Log.Error("SeekAsync failed", ex); return false; }
        }

        /// <summary>Sets device volume to <paramref name="volumePercent"/> (0–100).</summary>
        public async Task<bool> SetVolumeAsync(int volumePercent, string? deviceId = null, CancellationToken ct = default)
        {
            var token = await GetUserTokenAsync(ct);
            if (token == null) return false;
            try
            {
                var url = $"https://api.spotify.com/v1/me/player/volume?volume_percent={Math.Clamp(volumePercent, 0, 100)}";
                if (!string.IsNullOrWhiteSpace(deviceId)) url += $"&device_id={deviceId}";
                using var req = new HttpRequestMessage(HttpMethod.Put, url);
                req.Headers.Add("Authorization", $"Bearer {token}");
                req.Content = new StringContent("{}", Encoding.UTF8, "application/json");
                var resp = await Http.SendAsync(req, ct);
                return resp.IsSuccessStatusCode || resp.StatusCode == System.Net.HttpStatusCode.NoContent;
            }
            catch (Exception ex) { Log.Error("SetVolumeAsync failed", ex); return false; }
        }

        /// <summary>Sets repeat mode: "off", "context", or "track".</summary>
        public async Task<bool> SetRepeatAsync(string state, string? deviceId = null, CancellationToken ct = default)
        {
            var token = await GetUserTokenAsync(ct);
            if (token == null) return false;
            try
            {
                var url = $"https://api.spotify.com/v1/me/player/repeat?state={state}";
                if (!string.IsNullOrWhiteSpace(deviceId)) url += $"&device_id={deviceId}";
                using var req = new HttpRequestMessage(HttpMethod.Put, url);
                req.Headers.Add("Authorization", $"Bearer {token}");
                req.Content = new StringContent("{}", Encoding.UTF8, "application/json");
                var resp = await Http.SendAsync(req, ct);
                return resp.IsSuccessStatusCode || resp.StatusCode == System.Net.HttpStatusCode.NoContent;
            }
            catch (Exception ex) { Log.Error("SetRepeatAsync failed", ex); return false; }
        }

        /// <summary>Toggles shuffle on/off.</summary>
        public async Task<bool> SetShuffleAsync(bool shuffle, string? deviceId = null, CancellationToken ct = default)
        {
            var token = await GetUserTokenAsync(ct);
            if (token == null) return false;
            try
            {
                var url = $"https://api.spotify.com/v1/me/player/shuffle?state={shuffle.ToString().ToLower()}";
                if (!string.IsNullOrWhiteSpace(deviceId)) url += $"&device_id={deviceId}";
                using var req = new HttpRequestMessage(HttpMethod.Put, url);
                req.Headers.Add("Authorization", $"Bearer {token}");
                req.Content = new StringContent("{}", Encoding.UTF8, "application/json");
                var resp = await Http.SendAsync(req, ct);
                return resp.IsSuccessStatusCode || resp.StatusCode == System.Net.HttpStatusCode.NoContent;
            }
            catch (Exception ex) { Log.Error("SetShuffleAsync failed", ex); return false; }
        }

        // ═══════════════════════════════════════════════════════════════
        //  PREMIUM — Queue
        // ═══════════════════════════════════════════════════════════════

        /// <summary>
        /// Adds a track to the user's playback queue.
        /// <paramref name="trackUri"/> format: "spotify:track:&lt;id&gt;"
        /// </summary>
        public async Task<bool> AddToQueueAsync(string trackUri, string? deviceId = null, CancellationToken ct = default)
        {
            var token = await GetUserTokenAsync(ct);
            if (token == null) return false;
            try
            {
                var url = $"https://api.spotify.com/v1/me/player/queue?uri={Uri.EscapeDataString(trackUri)}";
                if (!string.IsNullOrWhiteSpace(deviceId)) url += $"&device_id={deviceId}";
                using var req = new HttpRequestMessage(HttpMethod.Post, url);
                req.Headers.Add("Authorization", $"Bearer {token}");
                req.Content = new StringContent("{}", Encoding.UTF8, "application/json");
                var resp = await Http.SendAsync(req, ct);
                Log.Info($"AddToQueue {trackUri}: {(int)resp.StatusCode}");
                return resp.IsSuccessStatusCode || resp.StatusCode == System.Net.HttpStatusCode.NoContent;
            }
            catch (Exception ex) { Log.Error("AddToQueueAsync failed", ex); return false; }
        }

        /// <summary>Returns the user's current playback queue (up to 20 upcoming tracks).</summary>
        public async Task<List<SpotifyTrackResult>> GetQueueAsync(CancellationToken ct = default)
        {
            var results = new List<SpotifyTrackResult>();
            var token   = await GetUserTokenAsync(ct);
            if (token == null) return results;
            try
            {
                using var req  = BuildGet("https://api.spotify.com/v1/me/player/queue", token);
                var resp = await Http.SendAsync(req, ct);
                resp.EnsureSuccessStatusCode();
                using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                if (doc.RootElement.TryGetProperty("queue", out var queue))
                    foreach (var item in queue.EnumerateArray())
                        results.Add(ParseTrackItem(item));
                Log.Info($"GetQueueAsync: {results.Count} tracks");
            }
            catch (Exception ex) { Log.Error("GetQueueAsync failed", ex); }
            return results;
        }

        // ═══════════════════════════════════════════════════════════════
        //  PREMIUM — Saved Tracks (Liked Songs)
        // ═══════════════════════════════════════════════════════════════

        /// <summary>Returns a page of the user's saved (liked) tracks.</summary>
        public async Task<(List<SpotifyTrackResult> Tracks, int Total)> GetSavedTracksAsync(
            int limit = 50, int offset = 0, CancellationToken ct = default)
        {
            var results = new List<SpotifyTrackResult>();
            var token   = await GetUserTokenAsync(ct);
            if (token == null) return (results, 0);
            try
            {
                var url = $"https://api.spotify.com/v1/me/tracks?limit={limit}&offset={offset}&market=US";
                using var req  = BuildGet(url, token);
                var resp = await Http.SendAsync(req, ct);
                resp.EnsureSuccessStatusCode();
                using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                var root  = doc.RootElement;
                int total = root.TryGetProperty("total", out var tot) ? tot.GetInt32() : 0;
                foreach (var item in root.GetProperty("items").EnumerateArray())
                    if (item.TryGetProperty("track", out var track) && track.ValueKind != JsonValueKind.Null)
                        results.Add(ParseTrackItem(track));
                Log.Info($"GetSavedTracksAsync: {results.Count}/{total}");
                return (results, total);
            }
            catch (Exception ex) { Log.Error("GetSavedTracksAsync failed", ex); return (results, 0); }
        }

        /// <summary>Saves (likes) tracks by their bare Spotify IDs.</summary>
        public async Task<bool> SaveTracksAsync(IEnumerable<string> trackIds, CancellationToken ct = default)
        {
            var token = await GetUserTokenAsync(ct);
            if (token == null) return false;
            try
            {
                var payload = JsonSerializer.Serialize(new { ids = trackIds });
                using var req = new HttpRequestMessage(HttpMethod.Put, "https://api.spotify.com/v1/me/tracks");
                req.Headers.Add("Authorization", $"Bearer {token}");
                req.Content = new StringContent(payload, Encoding.UTF8, "application/json");
                var resp = await Http.SendAsync(req, ct);
                return resp.IsSuccessStatusCode || resp.StatusCode == System.Net.HttpStatusCode.NoContent;
            }
            catch (Exception ex) { Log.Error("SaveTracksAsync failed", ex); return false; }
        }

        /// <summary>Removes (unlikes) tracks by their bare Spotify IDs.</summary>
        public async Task<bool> RemoveSavedTracksAsync(IEnumerable<string> trackIds, CancellationToken ct = default)
        {
            var token = await GetUserTokenAsync(ct);
            if (token == null) return false;
            try
            {
                var payload = JsonSerializer.Serialize(new { ids = trackIds });
                using var req = new HttpRequestMessage(HttpMethod.Delete, "https://api.spotify.com/v1/me/tracks");
                req.Headers.Add("Authorization", $"Bearer {token}");
                req.Content = new StringContent(payload, Encoding.UTF8, "application/json");
                var resp = await Http.SendAsync(req, ct);
                return resp.IsSuccessStatusCode || resp.StatusCode == System.Net.HttpStatusCode.NoContent;
            }
            catch (Exception ex) { Log.Error("RemoveSavedTracksAsync failed", ex); return false; }
        }

        /// <summary>
        /// Checks whether given tracks are in the user's Liked Songs.
        /// Returns a bool array in the same order as <paramref name="trackIds"/>.
        /// </summary>
        public async Task<bool[]> CheckSavedTracksAsync(IEnumerable<string> trackIds, CancellationToken ct = default)
        {
            var ids   = new List<string>(trackIds);
            var empty = new bool[ids.Count];
            var token = await GetUserTokenAsync(ct);
            if (token == null) return empty;
            try
            {
                var url = $"https://api.spotify.com/v1/me/tracks/contains?ids={string.Join(",", ids)}";
                using var req  = BuildGet(url, token);
                var resp = await Http.SendAsync(req, ct);
                resp.EnsureSuccessStatusCode();
                using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                var arr  = doc.RootElement;
                var out_ = new bool[ids.Count];
                int i = 0;
                foreach (var el in arr.EnumerateArray())
                    if (i < out_.Length) out_[i++] = el.GetBoolean();
                return out_;
            }
            catch (Exception ex) { Log.Error("CheckSavedTracksAsync failed", ex); return empty; }
        }

        // ═══════════════════════════════════════════════════════════════
        //  PREMIUM — Audio Features
        // ═══════════════════════════════════════════════════════════════

        /// <summary>Returns audio features (BPM, key, energy, danceability…) for one track.</summary>
        public async Task<SpotifyAudioFeatures?> GetAudioFeaturesAsync(string trackId, CancellationToken ct = default)
        {
            var token = await GetUserTokenAsync(ct);
            if (token == null) return null;
            try
            {
                using var req  = BuildGet($"https://api.spotify.com/v1/audio-features/{trackId}", token);
                var resp = await Http.SendAsync(req, ct);
                resp.EnsureSuccessStatusCode();
                using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                var r = doc.RootElement;
                return new SpotifyAudioFeatures
                {
                    TrackId          = trackId,
                    Danceability     = GetFloat(r, "danceability"),
                    Energy           = GetFloat(r, "energy"),
                    Key              = GetInt(r,   "key"),
                    Loudness         = GetFloat(r, "loudness"),
                    Mode             = GetInt(r,   "mode"),
                    Speechiness      = GetFloat(r, "speechiness"),
                    Acousticness     = GetFloat(r, "acousticness"),
                    Instrumentalness = GetFloat(r, "instrumentalness"),
                    Liveness         = GetFloat(r, "liveness"),
                    Valence          = GetFloat(r, "valence"),
                    Tempo            = GetFloat(r, "tempo"),
                    TimeSignature    = GetInt(r,   "time_signature"),
                };
            }
            catch (Exception ex) { Log.Error($"GetAudioFeaturesAsync failed for {trackId}", ex); return null; }
        }

        /// <summary>Returns audio features for up to 100 tracks in one API call.</summary>
        public async Task<List<SpotifyAudioFeatures>> GetAudioFeaturesBatchAsync(
            IEnumerable<string> trackIds, CancellationToken ct = default)
        {
            var results = new List<SpotifyAudioFeatures>();
            var token   = await GetUserTokenAsync(ct);
            if (token == null) return results;
            try
            {
                var ids = string.Join(",", trackIds);
                using var req  = BuildGet($"https://api.spotify.com/v1/audio-features?ids={Uri.EscapeDataString(ids)}", token);
                var resp = await Http.SendAsync(req, ct);
                resp.EnsureSuccessStatusCode();
                using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                foreach (var r in doc.RootElement.GetProperty("audio_features").EnumerateArray())
                {
                    if (r.ValueKind == JsonValueKind.Null) continue;
                    results.Add(new SpotifyAudioFeatures
                    {
                        TrackId          = r.TryGetProperty("id", out var idEl) ? idEl.GetString() ?? "" : "",
                        Danceability     = GetFloat(r, "danceability"),
                        Energy           = GetFloat(r, "energy"),
                        Key              = GetInt(r,   "key"),
                        Loudness         = GetFloat(r, "loudness"),
                        Mode             = GetInt(r,   "mode"),
                        Speechiness      = GetFloat(r, "speechiness"),
                        Acousticness     = GetFloat(r, "acousticness"),
                        Instrumentalness = GetFloat(r, "instrumentalness"),
                        Liveness         = GetFloat(r, "liveness"),
                        Valence          = GetFloat(r, "valence"),
                        Tempo            = GetFloat(r, "tempo"),
                        TimeSignature    = GetInt(r,   "time_signature"),
                    });
                }
            }
            catch (Exception ex) { Log.Error("GetAudioFeaturesBatchAsync failed", ex); }
            return results;
        }

        // ═══════════════════════════════════════════════════════════════
        //  Recommendations & Catalogue
        // ═══════════════════════════════════════════════════════════════

        /// <summary>
        /// Returns seed-based track recommendations.
        /// Optionally filter by target energy, valence (mood), and tempo for mood-aware results.
        /// </summary>
        public async Task<List<SpotifyTrackResult>> GetRecommendationsAsync(
            IEnumerable<string> seedTrackIds,
            int    limit         = 20,
            float? targetEnergy  = null,
            float? targetValence = null,
            float? targetTempo   = null,
            CancellationToken ct = default)
        {
            var results = new List<SpotifyTrackResult>();
            var token   = await GetUserTokenAsync(ct);
            if (token == null) return results;
            try
            {
                var seeds = string.Join(",", seedTrackIds);
                var url   = $"https://api.spotify.com/v1/recommendations?seed_tracks={Uri.EscapeDataString(seeds)}&limit={limit}";
                if (targetEnergy  != null) url += $"&target_energy={targetEnergy.Value:F2}";
                if (targetValence != null) url += $"&target_valence={targetValence.Value:F2}";
                if (targetTempo   != null) url += $"&target_tempo={targetTempo.Value:F0}";
                using var req = BuildGet(url, token);
                var resp = await Http.SendAsync(req, ct);
                resp.EnsureSuccessStatusCode();
                using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                foreach (var item in doc.RootElement.GetProperty("tracks").EnumerateArray())
                    results.Add(ParseTrackItem(item));
                Log.Info($"GetRecommendationsAsync: {results.Count} tracks");
            }
            catch (Exception ex) { Log.Error("GetRecommendationsAsync failed", ex); }
            return results;
        }

        /// <summary>Returns up to 10 top tracks for the given Spotify artist ID.</summary>
        public async Task<List<SpotifyTrackResult>> GetArtistTopTracksAsync(
            string artistId, CancellationToken ct = default)
        {
            var results = new List<SpotifyTrackResult>();
            var token   = await GetAppTokenAsync(ct);
            try
            {
                using var req = BuildGet($"https://api.spotify.com/v1/artists/{artistId}/top-tracks?market=US", token);
                var resp = await Http.SendAsync(req, ct);
                resp.EnsureSuccessStatusCode();
                using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                foreach (var item in doc.RootElement.GetProperty("tracks").EnumerateArray())
                    results.Add(ParseTrackItem(item));
            }
            catch (Exception ex) { Log.Error($"GetArtistTopTracksAsync({artistId}) failed", ex); }
            return results;
        }

        /// <summary>Returns all tracks from a Spotify album URL or bare album ID.</summary>
        public async Task<(string AlbumName, List<SpotifyTrackResult> Tracks)> GetAlbumTracksAsync(
            string urlOrId, CancellationToken ct = default)
        {
            var id     = ExtractId(urlOrId, "album/");
            var tracks = new List<SpotifyTrackResult>();
            var token  = await GetAppTokenAsync(ct);
            try
            {
                using var metaReq = BuildGet($"https://api.spotify.com/v1/albums/{id}", token);
                var metaResp = await Http.SendAsync(metaReq, ct);
                metaResp.EnsureSuccessStatusCode();
                using var metaDoc = JsonDocument.Parse(await metaResp.Content.ReadAsStringAsync(ct));
                var albumName = metaDoc.RootElement.GetProperty("name").GetString() ?? id;
                var year = 0;
                if (metaDoc.RootElement.TryGetProperty("release_date", out var rd))
                    int.TryParse(rd.GetString()?.Split('-')[0], out year);

                string? url = $"https://api.spotify.com/v1/albums/{id}/tracks?limit=50";
                while (url != null)
                {
                    using var req = BuildGet(url, token);
                    var resp = await Http.SendAsync(req, ct);
                    resp.EnsureSuccessStatusCode();
                    using var doc  = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                    var root = doc.RootElement;
                    foreach (var item in root.GetProperty("items").EnumerateArray())
                    {
                        var artists = new List<string>();
                        foreach (var a in item.GetProperty("artists").EnumerateArray())
                            artists.Add(a.GetProperty("name").GetString() ?? "");
                        tracks.Add(new SpotifyTrackResult
                        {
                            Id         = item.GetProperty("id").GetString()  ?? "",
                            Title      = item.GetProperty("name").GetString() ?? "",
                            Artist     = string.Join(", ", artists),
                            Album      = albumName,
                            DurationMs = item.GetProperty("duration_ms").GetInt32(),
                            Year       = year,
                        });
                    }
                    url = root.TryGetProperty("next", out var next) && next.ValueKind != JsonValueKind.Null
                        ? next.GetString() : null;
                }
                Log.Info($"GetAlbumTracksAsync: \"{albumName}\" — {tracks.Count} tracks");
                return (albumName, tracks);
            }
            catch (Exception ex) { Log.Error($"GetAlbumTracksAsync({id}) failed", ex); return (id, tracks); }
        }

        /// <summary>Fetches all tracks from a Spotify playlist URL or bare playlist ID.</summary>
        public async Task<(string PlaylistName, List<SpotifyPlaylistTrack> Tracks)>
            FetchPlaylistTracksAsync(string urlOrId, CancellationToken ct = default)
        {
            var id     = ExtractId(urlOrId, "playlist/");
            var tracks = new List<SpotifyPlaylistTrack>();
            var playlistName = id;
            try
            {
                var oJson = await Http.GetStringAsync(
                    $"https://open.spotify.com/oembed?url=https://open.spotify.com/playlist/{id}", ct);
                using var oDoc = JsonDocument.Parse(oJson);
                if (oDoc.RootElement.TryGetProperty("title", out var titleEl))
                    playlistName = titleEl.GetString() ?? id;
            }
            catch (Exception ex) { Log.Warning($"oEmbed name fetch (non-fatal): {ex.Message}"); }

            try
            {
                var token = await GetAppTokenAsync(ct);
                string? url = $"https://api.spotify.com/v1/playlists/{id}"
                            + "?fields=name,tracks.items(track(name,artists,duration_ms)),tracks.next&market=US";
                bool firstPage = true;
                while (url != null)
                {
                    using var req  = BuildGet(url, token);
                    var resp = await Http.SendAsync(req, ct);
                    if (!resp.IsSuccessStatusCode)
                    {
                        if ((int)resp.StatusCode == 403)
                            throw new InvalidOperationException("Spotify returned 403 — playlist may be private.");
                        throw new HttpRequestException($"Spotify returned {(int)resp.StatusCode}");
                    }
                    using var doc  = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                    var root = doc.RootElement;
                    if (firstPage && root.TryGetProperty("name", out var nameEl))
                        playlistName = nameEl.GetString() ?? playlistName;

                    var itemsEl = root.TryGetProperty("tracks", out var tracksEl)
                        ? tracksEl.GetProperty("items")
                        : root.GetProperty("items");

                    foreach (var item in itemsEl.EnumerateArray())
                    {
                        if (!item.TryGetProperty("track", out var track) || track.ValueKind == JsonValueKind.Null)
                            continue;
                        var artists = new List<string>();
                        if (track.TryGetProperty("artists", out var artistsEl))
                            foreach (var a in artistsEl.EnumerateArray())
                                if (a.TryGetProperty("name", out var an)) artists.Add(an.GetString() ?? "");
                        var title = track.TryGetProperty("name",        out var tn) ? tn.GetString() ?? "" : "";
                        var durMs = track.TryGetProperty("duration_ms", out var dm) ? dm.GetInt32() : 0;
                        if (!string.IsNullOrWhiteSpace(title))
                            tracks.Add(new SpotifyPlaylistTrack { Title = title, Artist = string.Join(", ", artists), DurationMs = durMs });
                    }

                    string? next = null;
                    if (firstPage && root.TryGetProperty("tracks", out var tEl2) &&
                        tEl2.TryGetProperty("next", out var nEl) && nEl.ValueKind != JsonValueKind.Null)
                        next = nEl.GetString();
                    else if (!firstPage && root.TryGetProperty("next", out var nEl2) && nEl2.ValueKind != JsonValueKind.Null)
                        next = nEl2.GetString();
                    url = next;
                    firstPage = false;
                }
            }
            catch (InvalidOperationException) { throw; }
            catch (Exception ex) { Log.Error("FetchPlaylistTracksAsync failed", ex); throw; }

            Log.Info($"Spotify playlist \"{playlistName}\" — {tracks.Count} tracks");
            return (playlistName, tracks);
        }

        // ── Token management ───────────────────────────────────────────────────

        private async Task<string?> GetUserTokenAsync(CancellationToken ct, bool forceRefresh = false)
        {
            if (!forceRefresh && _accessToken != null && DateTime.UtcNow < _tokenExpiry) return _accessToken;
            var s        = SettingsService.Instance.Settings;
            var clientId = Resolve(ApiConfig.SpotifyClientId, s.SpotifyClientId);
            _refreshToken ??= s.SpotifyRefreshToken;
            if (string.IsNullOrWhiteSpace(_refreshToken)) { Log.Warning("Spotify: no refresh token"); return null; }
            Log.Debug("Refreshing Spotify access token...");
            try
            {
                var body = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    ["grant_type"]    = "refresh_token",
                    ["refresh_token"] = _refreshToken,
                    ["client_id"]     = clientId,
                });
                var resp = await Http.PostAsync("https://accounts.spotify.com/api/token", body, ct);
                resp.EnsureSuccessStatusCode();
                using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                var root = doc.RootElement;
                _accessToken = root.GetProperty("access_token").GetString();
                _tokenExpiry = DateTime.UtcNow.AddSeconds(root.GetProperty("expires_in").GetInt32() - 30);
                if (root.TryGetProperty("refresh_token", out var rt) && rt.ValueKind != JsonValueKind.Null)
                {
                    _refreshToken         = rt.GetString();
                    s.SpotifyRefreshToken = _refreshToken ?? string.Empty;
                    SettingsService.Instance.Save();
                }
                Log.Info("Spotify token refreshed");
                return _accessToken;
            }
            catch (Exception ex)
            {
                Log.Error("Spotify token refresh failed", ex);
                _accessToken = _refreshToken = null;
                s.SpotifyRefreshToken = string.Empty;
                SettingsService.Instance.Save();
                return null;
            }
        }

        private async Task<string> GetAppTokenAsync(CancellationToken ct)
        {
            var userToken = await GetUserTokenAsync(ct);
            if (userToken != null) return userToken;

            if (_appToken != null && DateTime.UtcNow < _appTokenExpiry) return _appToken;

            try
            {
                var resp = await AnonHttp.GetAsync(
                    "https://open.spotify.com/get_access_token?reason=transport&productType=web_player", ct);
                if (resp.IsSuccessStatusCode)
                {
                    using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
                    var root = doc.RootElement;
                    if (root.TryGetProperty("accessToken", out var at) && at.ValueKind == JsonValueKind.String)
                    {
                        _appToken = at.GetString()!;
                        _appTokenExpiry = root.TryGetProperty("accessTokenExpirationTimestampMs", out var expEl)
                            ? DateTimeOffset.FromUnixTimeMilliseconds(expEl.GetInt64()).UtcDateTime.AddSeconds(-30)
                            : DateTime.UtcNow.AddHours(1);
                        return _appToken;
                    }
                }
            }
            catch (Exception ex) { Log.Warning($"Anonymous token failed: {ex.Message}"); }

            var s            = SettingsService.Instance.Settings;
            var clientId     = Resolve(ApiConfig.SpotifyClientId,     s.SpotifyClientId);
            var clientSecret = Resolve(ApiConfig.SpotifyClientSecret, s.SpotifyClientSecret);
            if (string.IsNullOrWhiteSpace(clientId) || string.IsNullOrWhiteSpace(clientSecret))
                throw new InvalidOperationException("No Spotify credentials. Add Client ID/Secret in Settings.");

            var credentials = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{clientId}:{clientSecret}"));
            using var req = new HttpRequestMessage(HttpMethod.Post, "https://accounts.spotify.com/api/token");
            req.Headers.Add("Authorization", $"Basic {credentials}");
            req.Content = new FormUrlEncodedContent(new Dictionary<string, string> { ["grant_type"] = "client_credentials" });
            var credsResp = await Http.SendAsync(req, ct);
            credsResp.EnsureSuccessStatusCode();
            using var credsDoc = JsonDocument.Parse(await credsResp.Content.ReadAsStringAsync(ct));
            var cRoot = credsDoc.RootElement;
            _appToken       = cRoot.GetProperty("access_token").GetString()!;
            _appTokenExpiry = DateTime.UtcNow.AddSeconds(cRoot.GetProperty("expires_in").GetInt32() - 30);
            return _appToken;
        }

        // ── Helpers ────────────────────────────────────────────────────────────

        private static HttpRequestMessage BuildGet(string url, string token)
        {
            var req = new HttpRequestMessage(HttpMethod.Get, url);
            req.Headers.Add("Authorization", $"Bearer {token}");
            return req;
        }

        private async Task<bool> SendPlayerCommandAsync(
            string command, string? deviceId, CancellationToken ct, HttpMethod? method = null)
        {
            var token = await GetUserTokenAsync(ct);
            if (token == null) return false;
            try
            {
                var url = $"https://api.spotify.com/v1/me/player/{command}";
                if (!string.IsNullOrWhiteSpace(deviceId)) url += $"?device_id={deviceId}";
                var m = method ?? HttpMethod.Put;
                using var req = new HttpRequestMessage(m, url);
                req.Headers.Add("Authorization", $"Bearer {token}");
                if (m == HttpMethod.Put) req.Content = new StringContent("{}", Encoding.UTF8, "application/json");
                var resp = await Http.SendAsync(req, ct);
                return resp.IsSuccessStatusCode || resp.StatusCode == System.Net.HttpStatusCode.NoContent;
            }
            catch (Exception ex) { Log.Error($"PlayerCommand/{command} failed", ex); return false; }
        }

        private static SpotifyTrackResult ParseTrackItem(JsonElement item)
        {
            var artists = new List<string>();
            if (item.TryGetProperty("artists", out var artistsEl))
                foreach (var a in artistsEl.EnumerateArray())
                    artists.Add(a.TryGetProperty("name", out var n) ? n.GetString() ?? "" : "");

            var albumName = "";
            var thumbUrl  = "";
            var year      = 0;
            if (item.TryGetProperty("album", out var album))
            {
                albumName = album.TryGetProperty("name", out var an) ? an.GetString() ?? "" : "";
                if (album.TryGetProperty("images", out var images) && images.GetArrayLength() > 0)
                    thumbUrl = images[0].TryGetProperty("url", out var iu) ? iu.GetString() ?? "" : "";
                if (album.TryGetProperty("release_date", out var rd))
                    int.TryParse(rd.GetString()?.Split('-')[0], out year);
            }

            string? previewUrl = null;
            if (item.TryGetProperty("preview_url", out var pu) && pu.ValueKind != JsonValueKind.Null)
                previewUrl = pu.GetString();

            return new SpotifyTrackResult
            {
                Id           = item.TryGetProperty("id",          out var id)  ? id.GetString()  ?? "" : "",
                Title        = item.TryGetProperty("name",        out var nm)  ? nm.GetString()  ?? "" : "",
                Artist       = string.Join(", ", artists),
                Album        = albumName,
                DurationMs   = item.TryGetProperty("duration_ms", out var dm)  ? dm.GetInt32()   : 0,
                PreviewUrl   = previewUrl,
                ThumbnailUrl = thumbUrl,
                SpotifyUrl   = item.TryGetProperty("external_urls", out var ext) &&
                               ext.TryGetProperty("spotify", out var su) ? su.GetString() ?? "" : "",
                Year         = year,
                Popularity   = item.TryGetProperty("popularity",  out var pop) ? pop.GetInt32()  : 0,
            };
        }

        private static string ExtractId(string urlOrId, string marker)
        {
            var id = urlOrId.Trim();
            var mi = id.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
            if (mi >= 0) { id = id[(mi + marker.Length)..]; var qi = id.IndexOf('?'); if (qi >= 0) id = id[..qi]; }
            return id;
        }

        private static string Resolve(string primary, string fallback)
            => !string.IsNullOrWhiteSpace(primary) ? primary : fallback;

        private static float GetFloat(JsonElement el, string key)
            => el.TryGetProperty(key, out var v) ? v.GetSingle() : 0f;

        private static int GetInt(JsonElement el, string key)
            => el.TryGetProperty(key, out var v) ? v.GetInt32() : 0;

        // ── Public nested types ────────────────────────────────────────────────

        public class SpotifyPlaylistTrack
        {
            public string Title      { get; set; } = string.Empty;
            public string Artist     { get; set; } = string.Empty;
            public int    DurationMs { get; set; }
        }
    }
}
