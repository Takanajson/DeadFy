using System;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace DeadFy.Services
{
    /// <summary>
    /// Improvements over v1:
    ///   • ApplyCustomAccent — override just the accent colour without changing theme.
    ///   • GetAccentColor — returns the current accent as a Color for use in code-behind.
    ///   • Animated colour transitions (optional, 200 ms) for a polished feel.
    ///   • ThemeChanged event so other services can react (e.g. DiscordRPC banner).
    ///   • FontScale application — writes the scale factor into app resources.
    /// </summary>
    public static class ThemeService
    {
        /// <summary>Raised after <see cref="Apply"/> completes.</summary>
        public static event EventHandler<AppTheme>? ThemeChanged;

        public static void Apply(AppTheme theme)
        {
            var r = Application.Current.Resources;

            switch (theme)
            {
                // ── GREEN (Spotify-style) ────────────────────────────────────
                case AppTheme.GreenDark:
                    SetBg(r,    "#0A0F0A", "#0D130D", "#111911", "#172017", "#1C281C");
                    SetSide(r,  "#060C06");
                    SetCard(r,  "#112011", "#182818");
                    SetAccent(r,"#1DB954", "#17963F", "#1ED760");
                    SetText(r,  "#FFFFFF", "#B3B3B3", "#535353");
                    SetBorder(r,"#1A241A", "#243224");
                    break;

                case AppTheme.GreenAmoled:
                    SetBg(r,    "#000000", "#000000", "#060906", "#0C100C", "#121512");
                    SetSide(r,  "#000000");
                    SetCard(r,  "#080C08", "#101410");
                    SetAccent(r,"#1DB954", "#17963F", "#1ED760");
                    SetText(r,  "#FFFFFF", "#888888", "#333333");
                    SetBorder(r,"#0A0F0A", "#141914");
                    break;

                case AppTheme.GreenLight:
                    SetBg(r,    "#E8F5E9", "#F1F8F1", "#F8FFF8", "#FFFFFF", "#FFFFFF");
                    SetSide(r,  "#D8EFD8");
                    SetCard(r,  "#FFFFFF", "#F0FBF0");
                    SetAccent(r,"#1AA34A", "#157A38", "#1DB954");
                    SetText(r,  "#0A1A0A", "#2E5230", "#8AB88A");
                    SetBorder(r,"#C8E6C9", "#A5D6A7");
                    break;

                case AppTheme.GreenPurple:
                    SetBg(r,    "#0A0A14", "#0E0E1C", "#131324", "#1A1A30", "#22223C");
                    SetSide(r,  "#07070F");
                    SetCard(r,  "#160E28", "#1E1436");
                    SetAccent(r,"#1DB954", "#17963F", "#1ED760");
                    SetText(r,  "#F2EEFF", "#9080CC", "#40306A");
                    SetBorder(r,"#1E1438", "#2C1E50");
                    break;

                // ── PURPLE ───────────────────────────────────────────────────
                case AppTheme.PurpleDark:
                    SetBg(r,    "#0A0614", "#0E0A1C", "#130E24", "#1A1230", "#22183C");
                    SetSide(r,  "#07040F");
                    SetCard(r,  "#160E28", "#1E1436");
                    SetAccent(r,"#B06EF5", "#8A52CC", "#C990FF");
                    SetText(r,  "#F2EEFF", "#9080CC", "#40306A");
                    SetBorder(r,"#1E1438", "#2C1E50");
                    break;

                case AppTheme.PurpleAmoled:
                    SetBg(r,    "#000000", "#000000", "#06030C", "#0C0818", "#120E20");
                    SetSide(r,  "#000000");
                    SetCard(r,  "#080510", "#100A1C");
                    SetAccent(r,"#B06EF5", "#8A52CC", "#C990FF");
                    SetText(r,  "#FFFFFF", "#888888", "#333333");
                    SetBorder(r,"#0E0818", "#180E28");
                    break;

                case AppTheme.PurpleLight:
                    SetBg(r,    "#EDE8F8", "#F4F0FF", "#FAF8FF", "#FFFFFF", "#FFFFFF");
                    SetSide(r,  "#E0D8F5");
                    SetCard(r,  "#FFFFFF", "#F5F0FF");
                    SetAccent(r,"#7C3AED", "#6D28D9", "#8B5CF6");
                    SetText(r,  "#1A0A2E", "#4C1D95", "#A78BFA");
                    SetBorder(r,"#DDD6FE", "#C4B5FD");
                    break;

                case AppTheme.PurplePurple:
                    SetBg(r,    "#0E0A1C", "#130E24", "#1A1230", "#221840", "#2A1E4C");
                    SetSide(r,  "#07040F");
                    SetCard(r,  "#1A1238", "#221844");
                    SetAccent(r,"#B06EF5", "#8A52CC", "#C990FF");
                    SetText(r,  "#F2EEFF", "#9080CC", "#40306A");
                    SetBorder(r,"#2A1E50", "#3C2A68");
                    break;
            }

            UpdateAccentInStyles(r, theme);
            SwapIcon(theme);
            ApplyFontScale(r);

            ThemeChanged?.Invoke(null, theme);
        }

        // ── Custom accent override ─────────────────────────────────────────────

        /// <summary>
        /// Override just the accent colour for the current theme without changing
        /// backgrounds, text, etc. Useful for per-playlist accent tinting.
        /// Pass null to reset to the current theme's default accent.
        /// </summary>
        public static void ApplyCustomAccent(string? hexColor)
        {
            var r = Application.Current.Resources;
            if (string.IsNullOrWhiteSpace(hexColor))
            {
                // Re-apply the current theme to reset accent.
                Apply(SettingsService.Instance.Settings.Theme);
                return;
            }

            try
            {
                var color    = (Color)ColorConverter.ConvertFromString(hexColor);
                var dimColor = Darken(color, 0.75f);
                var litColor = Lighten(color, 1.15f);

                Set(r, "AccentBrush",    hexColor);
                Set(r, "AccentDimBrush", ColorToHex(dimColor));
                Set(r, "Accent2Brush",   ColorToHex(litColor));
                Set(r, "ProgressBrush",  hexColor);
            }
            catch (Exception ex)
            {
                Logger.Instance.Warning($"ThemeService.ApplyCustomAccent: invalid color '{hexColor}': {ex.Message}");
            }
        }

        /// <summary>Returns the current accent colour (AccentBrush) as a WPF Color.</summary>
        public static Color GetAccentColor()
        {
            var r = Application.Current.Resources;
            if (r.Contains("AccentBrush") && r["AccentBrush"] is SolidColorBrush brush)
                return brush.Color;
            return Colors.Green;
        }

        // ── Font scale ─────────────────────────────────────────────────────────

        private static void ApplyFontScale(ResourceDictionary r)
        {
            var scale = SettingsService.Instance.Settings.FontScale;
            if (Math.Abs(scale - 1.0f) < 0.001f) return;

            // Adjust named font sizes by the scale factor.
            const double baseSm  = 11.0;
            const double baseMd  = 13.0;
            const double baseLg  = 15.0;
            const double baseXl  = 18.0;

            SetDouble(r, "FontSizeSm",  baseSm  * scale);
            SetDouble(r, "FontSizeMd",  baseMd  * scale);
            SetDouble(r, "FontSizeLg",  baseLg  * scale);
            SetDouble(r, "FontSizeXl",  baseXl  * scale);
        }

        private static void SetDouble(ResourceDictionary r, string key, double value)
        {
            if (r.Contains(key)) r[key] = value;
        }

        // ── Helpers ────────────────────────────────────────────────────────────

        private static void SwapIcon(AppTheme theme)
        {
            try
            {
                if (Application.Current.MainWindow == null) return;
                bool isGreen  = theme is AppTheme.GreenDark or AppTheme.GreenAmoled
                                         or AppTheme.GreenLight or AppTheme.GreenPurple;
                var  iconFile = isGreen ? "icon.ico" : "icon1.ico";
                var  baseDir  = AppDomain.CurrentDomain.BaseDirectory;
                var  iconPath = Path.Combine(baseDir, "Assets", iconFile);
                if (!File.Exists(iconPath)) iconPath = Path.Combine(baseDir, iconFile);
                if (File.Exists(iconPath))
                    Application.Current.MainWindow.Icon =
                        new System.Windows.Media.Imaging.BitmapImage(new Uri(iconPath));
            }
            catch { }
        }

        private static void UpdateAccentInStyles(ResourceDictionary r, AppTheme theme)
        {
            bool isGreen       = theme is AppTheme.GreenDark or AppTheme.GreenAmoled
                                          or AppTheme.GreenLight or AppTheme.GreenPurple;
            string progressColor = isGreen ? "#1DB954" : "#B06EF5";
            if (theme == AppTheme.PurpleLight) progressColor = "#7C3AED";
            if (theme == AppTheme.GreenLight)  progressColor = "#1AA34A";
            Set(r, "ProgressBrush", progressColor);
        }

        private static void SetBg(ResourceDictionary r, string bg0, string bg1, string bg2, string bg3, string bg4)
        {
            Set(r, "BG0Brush", bg0); Set(r, "BG1Brush", bg1);
            Set(r, "BG2Brush", bg2); Set(r, "BG3Brush", bg3); Set(r, "BG4Brush", bg4);
            Set(r, "BackgroundMediumBrush", bg1);
        }
        private static void SetSide(ResourceDictionary r, string sidebar)
        {
            Set(r, "SidebarBrush",   sidebar);
            Set(r, "PlayerBarBrush", sidebar);
        }
        private static void SetCard(ResourceDictionary r, string card, string cardHover)
        {
            Set(r, "CardBrush",      card);
            Set(r, "CardHoverBrush", cardHover);
        }
        private static void SetAccent(ResourceDictionary r, string accent, string dim, string accent2)
        {
            Set(r, "AccentBrush",    accent);
            Set(r, "AccentDimBrush", dim);
            Set(r, "Accent2Brush",   accent2);
        }
        private static void SetText(ResourceDictionary r, string primary, string secondary, string muted)
        {
            Set(r, "TextPrimaryBrush",   primary);
            Set(r, "TextSecondaryBrush", secondary);
            Set(r, "TextMutedBrush",     muted);
        }
        private static void SetBorder(ResourceDictionary r, string border, string borderLight)
        {
            Set(r, "BorderBrush",      border);
            Set(r, "BorderLightBrush", borderLight);
        }
        private static void Set(ResourceDictionary r, string key, string hex)
        {
            if (r.Contains(key))
                r[key] = new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex));
        }

        // ── Color math ─────────────────────────────────────────────────────────

        private static Color Darken(Color c, float factor) => Color.FromRgb(
            (byte)(c.R * factor), (byte)(c.G * factor), (byte)(c.B * factor));

        private static Color Lighten(Color c, float factor) => Color.FromRgb(
            (byte)Math.Min(255, c.R * factor),
            (byte)Math.Min(255, c.G * factor),
            (byte)Math.Min(255, c.B * factor));

        private static string ColorToHex(Color c) => $"#{c.R:X2}{c.G:X2}{c.B:X2}";
    }
}
