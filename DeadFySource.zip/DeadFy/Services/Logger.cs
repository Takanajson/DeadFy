using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows;
using System.Windows.Threading;

namespace DeadFy.Services
{
    public enum AppLogLevel { Debug, Info, Warning, Error }

    public class LogEntry
    {
        public DateTime     Time    { get; init; }
        public AppLogLevel  Level   { get; init; }
        public string       Message { get; init; } = string.Empty;
        public string       Member  { get; init; } = string.Empty;
        public string       File    { get; init; } = string.Empty;

        public override string ToString()
            => $"[{Time:HH:mm:ss.fff}] [{Level,-7}] {Message}";
    }

    /// <summary>
    /// Thread-safe logger. Writes to %AppData%\DeadFy\Logs\deadfy_YYYY-MM-DD.log
    /// and exposes an in-memory ObservableCollection for the UI log viewer.
    ///
    /// Improvements over v1:
    ///   • MinLevel filter — Debug entries are suppressed in Release builds by default.
    ///   • Size-based rotation: if today's log exceeds 10 MB, a new file is opened.
    ///   • Async background write queue — the calling thread is never blocked by I/O.
    ///   • Structured LogEntry exposes all fields for the UI log panel.
    ///   • CurrentLogPath property for the crash handler.
    /// </summary>
    public sealed class Logger
    {
        // ── Singleton ──────────────────────────────────────────────────────────
        private static Logger? _instance;
        public  static Logger Instance => _instance ??= new Logger();

        // ── Configuration ──────────────────────────────────────────────────────

        /// <summary>
        /// Minimum level that will be written to disk and shown in the UI.
        /// Default: Debug in debug builds, Info in release builds.
        /// </summary>
#if DEBUG
        public AppLogLevel MinLevel { get; set; } = AppLogLevel.Debug;
#else
        public AppLogLevel MinLevel { get; set; } = AppLogLevel.Info;
#endif

        // ── Paths ──────────────────────────────────────────────────────────────
        private static readonly string LogDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "DeadFy", "Logs");

        private const long MaxFileSizeBytes = 10 * 1024 * 1024; // 10 MB
        private const int  MaxLogAgeDays    = 14;

        private string _logFilePath = string.Empty;

        public string CurrentLogPath
        {
            get
            {
                var today    = DateTime.Now.ToString("yyyy-MM-dd");
                var expected = Path.Combine(LogDir, $"deadfy_{today}.log");

                // Rotate if the file has grown too large.
                if (_logFilePath == expected
                    && File.Exists(expected)
                    && new FileInfo(expected).Length >= MaxFileSizeBytes)
                {
                    var stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                    var rotated = Path.Combine(LogDir, $"deadfy_{today}_{stamp}.log");
                    try { File.Move(expected, rotated); } catch { }
                }

                if (_logFilePath != expected) _logFilePath = expected;
                return _logFilePath;
            }
        }

        // ── In-memory collection (UI thread only) ──────────────────────────────
        public ObservableCollection<LogEntry> Entries { get; } = new();
        private const int MaxEntries = 1000;

        // ── Background write queue ─────────────────────────────────────────────
        private readonly System.Collections.Concurrent.BlockingCollection<string> _writeQueue
            = new(boundedCapacity: 2000);
        private readonly System.Threading.Thread _writerThread;

        private readonly object _uiLock = new();

        // ── Constructor ────────────────────────────────────────────────────────
        private Logger()
        {
            try
            {
                Directory.CreateDirectory(LogDir);
                RotateOldLogs();
            }
            catch { }

            // Background writer thread — drains _writeQueue to disk.
            _writerThread = new System.Threading.Thread(WriterLoop)
            {
                IsBackground = true,
                Name         = "LogWriter"
            };
            _writerThread.Start();

            WriteRaw($"{"=",-60}\n  DeadFy  —  session started  {DateTime.Now:yyyy-MM-dd HH:mm:ss}\n{"=",-60}");
        }

        // ── Public API ─────────────────────────────────────────────────────────

        public void Debug(string message,
            [CallerMemberName] string member = "",
            [CallerFilePath]   string file   = "")
            => Write(AppLogLevel.Debug, message, member, file);

        public void Info(string message,
            [CallerMemberName] string member = "",
            [CallerFilePath]   string file   = "")
            => Write(AppLogLevel.Info, message, member, file);

        public void Warning(string message,
            [CallerMemberName] string member = "",
            [CallerFilePath]   string file   = "")
            => Write(AppLogLevel.Warning, message, member, file);

        public void Error(string message, Exception? ex = null,
            [CallerMemberName] string member = "",
            [CallerFilePath]   string file   = "")
        {
            var full = ex == null ? message : $"{message}\n  {ex.GetType().Name}: {ex.Message}";
            if (ex?.InnerException != null)
                full += $"\n  Inner: {ex.InnerException.Message}";
            Write(AppLogLevel.Error, full, member, file);
        }

        public void Write(AppLogLevel level, string message,
            [CallerMemberName] string member = "",
            [CallerFilePath]   string file   = "")
        {
            if (level < MinLevel) return;

            var entry = new LogEntry
            {
                Time    = DateTime.Now,
                Level   = level,
                Message = message,
                Member  = member,
                File    = Path.GetFileNameWithoutExtension(file)
            };

            // Queue for disk write (non-blocking).
            var line = $"{entry.Time:yyyy-MM-dd HH:mm:ss.fff} [{level,-7}] [{entry.File}.{member}] {message}";
            _writeQueue.TryAdd(line);

            // Update UI collection on the UI thread.
            AddToUiCollection(entry);
        }

        // ── UI collection helper ───────────────────────────────────────────────

        private void AddToUiCollection(LogEntry entry)
        {
            void AddEntry()
            {
                lock (_uiLock)
                {
                    Entries.Add(entry);
                    while (Entries.Count > MaxEntries)
                        Entries.RemoveAt(0);
                }
            }

            if (Application.Current == null) return;
            if (Application.Current.Dispatcher.CheckAccess())
                AddEntry();
            else
                Application.Current.Dispatcher.BeginInvoke(AddEntry, DispatcherPriority.Background);
        }

        // ── Background writer loop ─────────────────────────────────────────────

        private void WriterLoop()
        {
            foreach (var line in _writeQueue.GetConsumingEnumerable())
            {
                try { File.AppendAllText(CurrentLogPath, line + Environment.NewLine); }
                catch { /* never let the logger crash the app */ }
            }
        }

        // ── Raw write (for session header) ─────────────────────────────────────
        private void WriteRaw(string text)
        {
            _writeQueue.TryAdd(text);
        }

        // ── Log rotation ───────────────────────────────────────────────────────

        private static void RotateOldLogs()
        {
            try
            {
                var cutoff = DateTime.Now.AddDays(-MaxLogAgeDays);
                foreach (var file in Directory.GetFiles(LogDir, "deadfy_*.log"))
                {
                    if (File.GetLastWriteTime(file) < cutoff)
                        File.Delete(file);
                }
            }
            catch { }
        }
    }
}
