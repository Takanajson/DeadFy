using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows;
using System.Windows.Threading;

namespace DeadFy.Services
{
    public enum AppLogLevel { Debug, Info, Warning, Error }

    /// <summary>
    /// Thread-safe logger. Writes to %AppData%\DeadFy\Logs\deadfy_YYYY-MM-DD.log
    /// and exposes an in-memory ObservableCollection for the UI log viewer.
    /// The logger never throws — all errors are silently swallowed.
    /// </summary>
    public sealed class Logger
    {
        // ── Singleton ─────────────────────────────────────────────────────────
        private static Logger? _instance;
        public  static Logger Instance => _instance ??= new Logger();

        // ── Paths ─────────────────────────────────────────────────────────────
        private static readonly string LogDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "DeadFy", "Logs");

        // Cached so the property getter doesn't call DateTime.Now on every log line
        private string _logFilePath = string.Empty;
        private string LogFile
        {
            get
            {
                var today = DateTime.Now.ToString("yyyy-MM-dd");
                var expected = Path.Combine(LogDir, $"deadfy_{today}.log");
                if (_logFilePath != expected) _logFilePath = expected;
                return _logFilePath;
            }
        }

        // ── In-memory collection (UI thread only) ─────────────────────────────
        public ObservableCollection<LogEntry> Entries { get; } = new();
        private const int MaxEntries = 500;

        private readonly object _fileLock = new();

        // ── Constructor ───────────────────────────────────────────────────────
        private Logger()
        {
            try
            {
                Directory.CreateDirectory(LogDir);
                RotateOldLogs();
                WriteRaw($"{"=",-60}\n  DeadFy  —  session started  {DateTime.Now:yyyy-MM-dd HH:mm:ss}\n{"=",-60}");
            }
            catch { }
        }

        // ── Public API ────────────────────────────────────────────────────────

        public void Debug(string message,
            [CallerMemberName] string member = "",
            [CallerFilePath]   string file   = "")
            => Write(AppLogLevel.Debug, message, member, file);

        public void Info(string message,
            [CallerMemberName] string member = "",
            [CallerFilePath]   string file   = "")
            => Write(AppLogLevel.Info, message, member, file);

        public void Warning(string message,
            [CallerMemberName] string member = "",
            [CallerFilePath]   string file   = "")
            => Write(AppLogLevel.Warning, message, member, file);

        public void Error(string message, Exception? ex = null,
            [CallerMemberName] string member = "",
            [CallerFilePath]   string file   = "")
        {
            var full = ex == null
                ? message
                : $"{message}\n  {ex.GetType().Name}: {ex.Message}\n  Stack: {ex.StackTrace}";
            Write(AppLogLevel.Error, full, member, file);
        }

        /// <summary>Opens the log folder in Windows Explorer.</summary>
        public void OpenLogFolder()
        {
            try { System.Diagnostics.Process.Start("explorer.exe", LogDir); } catch { }
        }

        /// <summary>Full path to today's log file.</summary>
        public string CurrentLogPath => LogFile;

        // ── Core write ────────────────────────────────────────────────────────
        public void Write(AppLogLevel level, string message, string member = "", string file = "")
        {
            try
            {
                var tag   = Path.GetFileNameWithoutExtension(file);
                var entry = new LogEntry(level, tag, member, message);
                var line  = entry.ToLogLine();

                lock (_fileLock)
                    File.AppendAllText(LogFile, line + Environment.NewLine, Encoding.UTF8);

                // Push to UI on the dispatcher — fail silently if app is shutting down
                var app = Application.Current;
                if (app == null) return;
                app.Dispatcher.InvokeAsync(() =>
                {
                    Entries.Add(entry);
                    // Trim oldest entries to keep memory bounded
                    while (Entries.Count > MaxEntries)
                        Entries.RemoveAt(0);
                }, DispatcherPriority.Background);
            }
            catch { /* logger must never throw */ }
        }

        private void WriteRaw(string text)
        {
            lock (_fileLock)
                File.AppendAllText(LogFile, text + Environment.NewLine, Encoding.UTF8);
        }

        // ── Log rotation — keep last 7 days ───────────────────────────────────
        private void RotateOldLogs()
        {
            try
            {
                foreach (var f in Directory.GetFiles(LogDir, "deadfy_*.log"))
                {
                    var name = Path.GetFileNameWithoutExtension(f); // deadfy_2025-01-01
                    if (name.Length < 17) continue;
                    if (DateTime.TryParse(name[7..], out var d) && (DateTime.Now - d).TotalDays > 7)
                        File.Delete(f);
                }
            }
            catch { }
        }
    }

    // ── Log entry model ───────────────────────────────────────────────────────
    public sealed class LogEntry
    {
        public DateTime    Timestamp { get; }
        public AppLogLevel Level     { get; }
        public string      Tag       { get; }    // source file name
        public string      Member    { get; }    // method name
        public string      Message   { get; }

        public LogEntry(AppLogLevel level, string tag, string member, string message)
        {
            Timestamp = DateTime.Now;
            Level     = level;
            Tag       = tag;
            Member    = member;
            Message   = message;
        }

        public string ToLogLine()
            => $"[{Timestamp:HH:mm:ss.fff}] [{Level,-7}] [{Tag}.{Member}] {Message}";

        /// <summary>Alias for UI binding.</summary>
        public string Display => ToLogLine();

        public string LevelColor => Level switch
        {
            AppLogLevel.Error   => "#FF6B6B",
            AppLogLevel.Warning => "#FFD93D",
            AppLogLevel.Info    => "#A8D8A8",
            AppLogLevel.Debug   => "#888888",
            _                   => "#CCCCCC"
        };
    }
}
