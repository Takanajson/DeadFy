using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using DeadFy.Models;
using DeadFy.Plugins;

namespace DeadFy.Services
{
    /// <summary>
    /// Implements IPluginHost by wiring up to the real app services.
    /// Passed to every plugin on Initialize().
    /// </summary>
    public class PluginHost : IPluginHost
    {
        private static PluginHost? _instance;
        public static PluginHost Instance => _instance ??= new PluginHost();

        private readonly AudioPlayerService _player = AudioPlayerService.Instance;
        private readonly LibraryService _library = LibraryService.Instance;

        // ── IPluginHost events ─────────────────────────────────────────
        public event EventHandler<Song?> SongChanged = delegate { };
        public event EventHandler<bool> PlaybackStateChanged = delegate { };
        public event EventHandler<double> PositionChanged = delegate { };
        public event EventHandler<double> VolumeChanged = delegate { };

        // Settings panel registry (pluginName → UIElement)
        private readonly Dictionary<string, UIElement> _settingsPanels = new();
        public IReadOnlyDictionary<string, UIElement> SettingsPanels => _settingsPanels;

        // Notification relay — MainWindow subscribes to this
        public event EventHandler<(string Message, NotificationKind Kind)>? NotificationRequested;

        private PluginHost()
        {
            _player.PropertyChanged += (_, e) =>
            {
                switch (e.PropertyName)
                {
                    case nameof(AudioPlayerService.CurrentSong):
                        SongChanged?.Invoke(this, _player.CurrentSong);
                        break;
                    case nameof(AudioPlayerService.IsPlaying):
                        PlaybackStateChanged?.Invoke(this, _player.IsPlaying);
                        break;
                    case nameof(AudioPlayerService.PositionSeconds):
                        PositionChanged?.Invoke(this, _player.PositionSeconds);
                        break;
                    case nameof(AudioPlayerService.Volume):
                        VolumeChanged?.Invoke(this, _player.Volume);
                        break;
                }
            };
        }

        // ── Playback ───────────────────────────────────────────────────
        public Song? CurrentSong => _player.CurrentSong;
        public bool IsPlaying => _player.IsPlaying;
        public double PositionSeconds
        {
            get => _player.PositionSeconds;
            set => _player.PositionSeconds = value;
        }
        public double Volume
        {
            get => _player.Volume;
            set => _player.Volume = (float)value;
        }
        public void Play() => _player.Resume();
        public void Pause() => _player.Pause();
        public void Next() => ViewModels.MainViewModel.Instance?.PlayNext();
        public void Previous() => ViewModels.MainViewModel.Instance?.PlayPrevious();

        // ── Library ────────────────────────────────────────────────────
        public IReadOnlyList<Song> Library => _library.Songs;
        public IReadOnlyList<Playlist> Playlists => _library.Playlists;

        public void AddSongToLibrary(Song song)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                _library.Songs.Add(song);
                ViewModels.MainViewModel.Instance?.RefreshFilteredLibrary();
            });
        }

        // ── UI helpers ─────────────────────────────────────────────────
        public void ShowNotification(string message, NotificationKind kind = NotificationKind.Info)
        {
            Application.Current.Dispatcher.Invoke(() =>
                NotificationRequested?.Invoke(this, (message, kind)));
        }

        public void RegisterSettingsPanel(string pluginName, UIElement panel)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                _settingsPanels[pluginName] = panel;
            });
        }

        // ── Logging ────────────────────────────────────────────────────
        // IPluginHost.Log uses Plugins.LogLevel (defined in IDeadPlugin.cs).
        // Map it to the app AppLogLevel so plugin messages appear in the log file.
        public void Log(string message, Plugins.LogLevel level = Plugins.LogLevel.Info)
        {
            var appLevel = level switch
            {
                Plugins.LogLevel.Debug => AppLogLevel.Debug,
                Plugins.LogLevel.Warning => AppLogLevel.Warning,
                Plugins.LogLevel.Error => AppLogLevel.Error,
                _ => AppLogLevel.Info,
            };
            Logger.Instance.Write(appLevel, $"[Plugin] {message}");
            PluginLoaderService.Instance.Log(message, level);
        }
    }
}