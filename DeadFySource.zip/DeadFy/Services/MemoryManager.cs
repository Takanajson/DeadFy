using System;
using System.Diagnostics;
using System.Runtime;
using System.Threading;

namespace DeadFy.Services
{
    /// <summary>
    /// Schedules periodic memory cleanup so DeadFy's working set stays trim
    /// across long listening sessions.
    ///
    /// Call <see cref="Start"/> from App.OnStartup and <see cref="Stop"/> from
    /// App.OnExit (or just let the process exit normally — the timer is background).
    /// </summary>
    public static class MemoryManager
    {
        // ── Configuration ─────────────────────────────────────────────────────

        /// <summary>How often to run a routine cleanup, in minutes (default 5).</summary>
        public static int CleanupIntervalMinutes { get; set; } = 5;

        /// <summary>
        /// Managed heap threshold in MB.  When exceeded, a full collection runs
        /// immediately instead of waiting for the next interval (default 300 MB).
        /// </summary>
        public static long PressureThresholdMb { get; set; } = 300;

        // ── State ─────────────────────────────────────────────────────────────
        private static Timer? _timer;
        private static bool   _running;

        // ── Lifecycle ─────────────────────────────────────────────────────────
        public static void Start()
        {
            if (_running) return;
            _running = true;
            int ms = CleanupIntervalMinutes * 60_000;
            _timer = new Timer(OnTick, null, ms, ms);
            Logger.Instance.Info("MemoryManager started");
        }

        public static void Stop()
        {
            _running = false;
            _timer?.Dispose();
            _timer = null;
        }

        // ── Timer callback ────────────────────────────────────────────────────
        private static void OnTick(object? _)
        {
            if (!_running) return;

            long managedMb = GC.GetTotalMemory(forceFullCollection: false) / (1024 * 1024);
            if (managedMb >= PressureThresholdMb)
            {
                Logger.Instance.Warning($"MemoryManager: high pressure ({managedMb} MB) — running full cleanup");
                PerformFullCleanup();
            }
            else
            {
                PerformRoutineCleanup();
            }
        }

        // ── Cleanup levels ────────────────────────────────────────────────────

        /// <summary>Fast Gen0/1 collect (≈ &lt;1 ms). Safe to call from the audio thread.</summary>
        public static void PerformRoutineCleanup()
        {
            GC.Collect(1, GCCollectionMode.Optimized, blocking: false);
        }

        /// <summary>
        /// Full collect + LOH compaction.  Blocking — do NOT call on the UI or
        /// audio thread.  Called automatically when memory pressure is high.
        /// </summary>
        public static void PerformFullCleanup()
        {
            GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced, blocking: true);
            GC.WaitForPendingFinalizers();
            GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced, blocking: true);

            // Compact the LOH once — prevents fragmentation from large album-art
            // bitmaps and stream buffers that get allocated and freed over time.
            try
            {
                GCSettings.LargeObjectHeapCompactionMode =
                    GCLargeObjectHeapCompactionMode.CompactOnce;
            }
            catch { /* not available on all runtimes */ }
        }

        // ── Diagnostics ───────────────────────────────────────────────────────

        /// <summary>
        /// Human-readable snapshot for the status bar or settings dialog.
        /// Example: "Memory: 47 MB managed / 134 MB process"
        /// </summary>
        public static string GetSnapshot()
        {
            long managedMb = GC.GetTotalMemory(false) / (1024 * 1024);
            long processMb = Process.GetCurrentProcess().WorkingSet64 / (1024 * 1024);
            return $"Memory: {managedMb} MB managed / {processMb} MB process";
        }
    }
}
