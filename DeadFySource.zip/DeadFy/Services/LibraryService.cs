using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using DeadFy.Models;

namespace DeadFy.Services
{
    public class LibraryService
    {
        private static LibraryService? _instance;
        public static LibraryService Instance => _instance ??= new LibraryService();

        public string RootFolder   { get; private set; }
        public string MusicFolder  { get; private set; }
        public string CoversFolder { get; private set; }
        public string DataFolder   { get; private set; }

        private const string SongsFile     = "songs.json";
        private const string PlaylistsFile  = "playlists.json";

        private readonly object _saveLock = new();

        public ObservableCollection<Song>     Songs     { get; } = new();
        public ObservableCollection<Playlist> Playlists { get; } = new();

        // ── Progress reporting for UI during async imports ─────────────────────
        public event EventHandler<int>? ImportProgressChanged;

        private LibraryService()
        {
            RootFolder   = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyMusic), "DeadFy");
            MusicFolder  = Path.Combine(RootFolder, "Music");
            CoversFolder = Path.Combine(RootFolder, "Covers");
            DataFolder   = Path.Combine(RootFolder, "Data");
        }

        // ── Initialise ─────────────────────────────────────────────────────────

        public void EnsureDirectories()
        {
            Directory.CreateDirectory(RootFolder);
            Directory.CreateDirectory(MusicFolder);
            Directory.CreateDirectory(CoversFolder);
            Directory.CreateDirectory(DataFolder);
            LoadLibrary();
        }

        // ── Load ───────────────────────────────────────────────────────────────

        public void LoadLibrary()
        {
            Songs.Clear();
            Playlists.Clear();

            var songsPath = Path.Combine(DataFolder, SongsFile);
            if (File.Exists(songsPath))
            {
                try
                {
                    var songs = JsonConvert.DeserializeObject<List<Song>>(File.ReadAllText(songsPath));
                    if (songs != null)
                        foreach (var s in songs.Where(s => s.IsStreaming || File.Exists(s.FilePath)))
                            Songs.Add(s);
                }
                catch (Exception ex)
                {
                    Logger.Instance.Error("LibraryService: failed to load songs.json", ex);
                }
            }

            var playlistsPath = Path.Combine(DataFolder, PlaylistsFile);
            if (File.Exists(playlistsPath))
            {
                try
                {
                    var pls = JsonConvert.DeserializeObject<List<Playlist>>(File.ReadAllText(playlistsPath));
                    if (pls != null)
                        foreach (var pl in pls)
                            Playlists.Add(pl);
                }
                catch (Exception ex)
                {
                    Logger.Instance.Error("LibraryService: failed to load playlists.json", ex);
                }
            }
        }

        // ── Save (sync + async) ────────────────────────────────────────────────

        public void SaveLibrary()
        {
            lock (_saveLock)
            {
                try
                {
                    File.WriteAllText(
                        Path.Combine(DataFolder, SongsFile),
                        JsonConvert.SerializeObject(Songs.ToList(), Formatting.Indented));

                    File.WriteAllText(
                        Path.Combine(DataFolder, PlaylistsFile),
                        JsonConvert.SerializeObject(Playlists.ToList(), Formatting.Indented));
                }
                catch (Exception ex)
                {
                    Logger.Instance.Error("LibraryService: SaveLibrary failed", ex);
                }
            }
        }

        public Task SaveLibraryAsync()
            => Task.Run(SaveLibrary);

        // ── Add / remove songs ─────────────────────────────────────────────────

        public Song? AddLocalSong(string mp3Path, string? coverSourcePath, string artist, string title)
        {
            try
            {
                var destFileName = $"{Guid.NewGuid()}{Path.GetExtension(mp3Path)}";
                var destPath     = Path.Combine(MusicFolder, destFileName);
                File.Copy(mp3Path, destPath, overwrite: true);

                string? coverDestPath = null;
                if (coverSourcePath != null && File.Exists(coverSourcePath))
                {
                    var coverFileName = $"{Guid.NewGuid()}{Path.GetExtension(coverSourcePath)}";
                    coverDestPath = Path.Combine(CoversFolder, coverFileName);
                    File.Copy(coverSourcePath, coverDestPath, overwrite: true);
                }

                var song = ReadTagsIntoSong(destPath);
                // Allow caller overrides.
                if (!string.IsNullOrWhiteSpace(title))  song.Title  = title;
                if (!string.IsNullOrWhiteSpace(artist)) song.Artist = artist;
                if (coverDestPath != null)               song.CoverPath = coverDestPath;

                song.Source    = SongSource.Local;
                song.DateAdded = DateTime.Now;

                Songs.Add(song);
                _ = SaveLibraryAsync();
                return song;
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("AddLocalSong failed", ex);
                return null;
            }
        }

        public void RemoveSong(Song song)
        {
            Songs.Remove(song);
            foreach (var pl in Playlists)
                pl.Songs.Remove(song);
            _ = SaveLibraryAsync();

            try
            {
                if (!string.IsNullOrEmpty(song.FilePath) && File.Exists(song.FilePath))
                    File.Delete(song.FilePath);
            }
            catch (Exception ex)
            {
                Logger.Instance.Warning($"LibraryService: could not delete file — {ex.Message}");
            }
        }

        // ── Playlists ──────────────────────────────────────────────────────────

        public Playlist CreatePlaylist(string name)
        {
            var pl = new Playlist { Name = name };
            Playlists.Add(pl);
            _ = SaveLibraryAsync();
            return pl;
        }

        public void DeletePlaylist(Playlist playlist)
        {
            Playlists.Remove(playlist);
            _ = SaveLibraryAsync();
        }

        public void AddSongToPlaylist(Playlist playlist, Song song)
        {
            if (playlist.Songs.Contains(song)) return;
            playlist.Songs.Add(song);
            _ = SaveLibraryAsync();
        }

        public void RemoveSongFromPlaylist(Playlist playlist, Song song)
        {
            playlist.Songs.Remove(song);
            _ = SaveLibraryAsync();
        }

        // ── Folder import (sync) ───────────────────────────────────────────────

        private static readonly HashSet<string> AudioExtensions = new(StringComparer.OrdinalIgnoreCase)
            { ".mp3", ".flac", ".wav", ".aac", ".ogg", ".m4a", ".wma", ".opus" };

        public List<Song> ImportFolder(string folderPath)
        {
            var added = new List<Song>();
            var existingPaths = new HashSet<string>(Songs.Select(s => s.FilePath), StringComparer.OrdinalIgnoreCase);

            var files = Directory.GetFiles(folderPath, "*.*", SearchOption.AllDirectories);
            foreach (var file in files)
            {
                if (!AudioExtensions.Contains(Path.GetExtension(file))) continue;
                if (existingPaths.Contains(file)) continue;

                var song = ReadTagsIntoSong(file);
                Songs.Add(song);
                added.Add(song);
                existingPaths.Add(file);
            }

            if (added.Count > 0)
            {
                _ = SaveLibraryAsync();
                Logger.Instance.Info($"ImportFolder: added {added.Count} songs from '{folderPath}'");
            }

            return added;
        }

        /// <summary>
        /// Async folder import with progress reporting.
        /// Suitable for large libraries — reports progress every 50 files.
        /// </summary>
        public async Task<List<Song>> ImportFolderAsync(
            string folderPath,
            CancellationToken ct = default)
        {
            return await Task.Run(() =>
            {
                var added = new List<Song>();
                var existingPaths = new HashSet<string>(Songs.Select(s => s.FilePath), StringComparer.OrdinalIgnoreCase);

                var files = Directory.GetFiles(folderPath, "*.*", SearchOption.AllDirectories)
                                     .Where(f => AudioExtensions.Contains(Path.GetExtension(f)))
                                     .ToList();

                for (int i = 0; i < files.Count; i++)
                {
                    ct.ThrowIfCancellationRequested();

                    if (existingPaths.Contains(files[i])) continue;

                    var song = ReadTagsIntoSong(files[i]);

                    System.Windows.Application.Current.Dispatcher.Invoke(() => Songs.Add(song));
                    added.Add(song);
                    existingPaths.Add(files[i]);

                    if (i % 50 == 0)
                        ImportProgressChanged?.Invoke(this, (int)(i * 100.0 / files.Count));
                }

                if (added.Count > 0)
                {
                    SaveLibrary();
                    Logger.Instance.Info($"ImportFolderAsync: added {added.Count} songs from '{folderPath}'");
                }

                ImportProgressChanged?.Invoke(this, 100);
                return added;
            }, ct);
        }

        // ── Duplicate detection ────────────────────────────────────────────────

        /// <summary>
        /// Returns groups of songs that appear to be duplicates.
        /// Two songs are considered duplicates when they share the same normalised
        /// title+artist, OR when their file sizes differ by less than 5 KB
        /// (same rip, different paths).
        /// </summary>
        public List<List<Song>> FindDuplicates()
        {
            // Group by normalised "artist – title"
            var byKey = Songs
                .GroupBy(s => $"{s.DisplayArtist.ToLowerInvariant().Trim()}|{s.DisplayTitle.ToLowerInvariant().Trim()}")
                .Where(g => g.Count() > 1)
                .Select(g => g.ToList())
                .ToList();

            return byKey;
        }

        // ── Tag reading helper ─────────────────────────────────────────────────

        /// <summary>
        /// Reads ID3/Vorbis tags from a file and returns a populated Song.
        /// Also extracts embedded cover art and saves it to CoversFolder.
        /// </summary>
        private Song ReadTagsIntoSong(string filePath)
        {
            var song = new Song
            {
                FilePath  = filePath,
                Title     = Path.GetFileNameWithoutExtension(filePath),
                Artist    = "Unknown Artist",
                Source    = SongSource.Local,
                DateAdded = DateTime.Now,
            };

            try
            {
                using var tf = TagLib.File.Create(filePath);

                song.Duration = tf.Properties.Duration;
                song.Bitrate  = tf.Properties.AudioBitrate;

                if (!string.IsNullOrWhiteSpace(tf.Tag.Title))         song.Title       = tf.Tag.Title;
                if (!string.IsNullOrWhiteSpace(tf.Tag.FirstPerformer))song.Artist      = tf.Tag.FirstPerformer;
                if (!string.IsNullOrWhiteSpace(tf.Tag.Album))         song.Album       = tf.Tag.Album;
                if (!string.IsNullOrWhiteSpace(tf.Tag.FirstGenre))    song.Genre       = tf.Tag.FirstGenre;
                if (!string.IsNullOrWhiteSpace(tf.Tag.Comment))       song.Comment     = tf.Tag.Comment;
                if (tf.Tag.Track > 0)                                  song.TrackNumber = (int)tf.Tag.Track;
                if (tf.Tag.Disc  > 0)                                  song.DiscNumber  = (int)tf.Tag.Disc;
                if (tf.Tag.Year  > 0)                                  song.Year        = (int)tf.Tag.Year;
                if (tf.Tag.BeatsPerMinute > 0)                         song.Bpm         = (int)tf.Tag.BeatsPerMinute;

                // Extract embedded cover art
                var pic = tf.Tag.Pictures?.FirstOrDefault();
                if (pic != null && pic.Data.Count > 0)
                {
                    try
                    {
                        var coverFileName = $"{Guid.NewGuid()}.jpg";
                        var coverPath     = Path.Combine(CoversFolder, coverFileName);
                        File.WriteAllBytes(coverPath, pic.Data.Data);
                        song.CoverPath = coverPath;
                    }
                    catch { /* cover extraction failed — not fatal */ }
                }
            }
            catch { /* TagLib failed — use defaults */ }

            return song;
        }

        // ── Export / Import ────────────────────────────────────────────────────

        public void ExportLibrary(string destPath)
        {
            var export = new { ExportedAt = DateTime.Now, Songs = Songs.ToList(), Playlists = Playlists.ToList() };
            File.WriteAllText(destPath, JsonConvert.SerializeObject(export, Formatting.Indented));
            Logger.Instance.Info($"Library exported to '{destPath}'");
        }

        public int ImportLibrary(string srcPath)
        {
            try
            {
                var json = File.ReadAllText(srcPath);
                dynamic? data = JsonConvert.DeserializeObject(json);
                if (data == null) return 0;

                int added = 0;
                var songs = JsonConvert.DeserializeObject<List<Song>>(data.Songs.ToString());
                if (songs != null)
                {
                    var existingIds = new HashSet<string>(Songs.Select(s => s.Id));
                    foreach (var s in songs)
                    {
                        if (existingIds.Contains(s.Id)) continue;
                        if (!s.IsStreaming && !File.Exists(s.FilePath)) continue;
                        Songs.Add(s);
                        existingIds.Add(s.Id);
                        added++;
                    }
                }

                if (added > 0) _ = SaveLibraryAsync();
                Logger.Instance.Info($"ImportLibrary: merged {added} songs from '{srcPath}'");
                return added;
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("ImportLibrary failed", ex);
                return 0;
            }
        }

        // ── Smart views ────────────────────────────────────────────────────────

        public List<Song> GetMostPlayed(int top = 25)
            => Songs.Where(s => s.PlayCount > 0)
                    .OrderByDescending(s => s.PlayCount)
                    .Take(top).ToList();

        public List<Song> GetRecentlyAdded(int top = 25)
            => Songs.OrderByDescending(s => s.DateAdded).Take(top).ToList();

        public List<Song> GetFavorites()
            => Songs.Where(s => s.IsFavorite).ToList();

        public List<Song> GetNeverPlayed()
            => Songs.Where(s => s.PlayCount == 0).ToList();

        public List<Song> GetRecentlyPlayed(int top = 25)
            => Songs.Where(s => s.LastPlayed.HasValue)
                    .OrderByDescending(s => s.LastPlayed)
                    .Take(top).ToList();

        /// <summary>Returns all songs with a rating >= minRating (1–5).</summary>
        public List<Song> GetByMinRating(int minRating)
            => Songs.Where(s => s.Rating >= minRating).OrderByDescending(s => s.Rating).ToList();

        /// <summary>Returns distinct genre strings sorted alphabetically.</summary>
        public List<string> GetAllGenres()
            => Songs.Select(s => s.Genre)
                    .Where(g => !string.IsNullOrWhiteSpace(g))
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .OrderBy(g => g)
                    .ToList();

        /// <summary>Returns songs matching a specific genre (case-insensitive).</summary>
        public List<Song> GetByGenre(string genre)
            => Songs.Where(s => string.Equals(s.Genre, genre, StringComparison.OrdinalIgnoreCase)).ToList();

        /// <summary>Returns distinct mood strings sorted alphabetically.</summary>
        public List<string> GetAllMoods()
            => Songs.Select(s => s.Mood)
                    .Where(m => !string.IsNullOrWhiteSpace(m))
                    .Select(m => m!)
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .OrderBy(m => m)
                    .ToList();

        /// <summary>Returns songs matching a specific mood (case-insensitive).</summary>
        public List<Song> GetByMood(string mood)
            => Songs.Where(s => string.Equals(s.Mood, mood, StringComparison.OrdinalIgnoreCase)).ToList();

        /// <summary>Returns songs released in a given year.</summary>
        public List<Song> GetByYear(int year)
            => Songs.Where(s => s.Year == year).ToList();

        /// <summary>Returns all unique years present in the library (desc).</summary>
        public List<int> GetAllYears()
            => Songs.Where(s => s.Year > 0)
                    .Select(s => s.Year)
                    .Distinct()
                    .OrderByDescending(y => y)
                    .ToList();

        // ── Sorted / searched views ────────────────────────────────────────────

        public IEnumerable<Song> GetSorted(string by, bool descending)
        {
            IEnumerable<Song> q = Songs;
            q = by switch
            {
                "Title"      => descending ? q.OrderByDescending(s => s.DisplayTitle)  : q.OrderBy(s => s.DisplayTitle),
                "Artist"     => descending ? q.OrderByDescending(s => s.DisplayArtist) : q.OrderBy(s => s.DisplayArtist),
                "Album"      => descending ? q.OrderByDescending(s => s.Album)         : q.OrderBy(s => s.Album),
                "Genre"      => descending ? q.OrderByDescending(s => s.Genre)         : q.OrderBy(s => s.Genre),
                "Year"       => descending ? q.OrderByDescending(s => s.Year)          : q.OrderBy(s => s.Year),
                "Duration"   => descending ? q.OrderByDescending(s => s.Duration)      : q.OrderBy(s => s.Duration),
                "PlayCount"  => descending ? q.OrderByDescending(s => s.PlayCount)     : q.OrderBy(s => s.PlayCount),
                "LastPlayed" => descending ? q.OrderByDescending(s => s.LastPlayed)    : q.OrderBy(s => s.LastPlayed),
                "Rating"     => descending ? q.OrderByDescending(s => s.Rating)        : q.OrderBy(s => s.Rating),
                _            => descending ? q.OrderByDescending(s => s.DateAdded)     : q.OrderBy(s => s.DateAdded),
            };
            return q;
        }

        /// <summary>
        /// Case-insensitive search across Title, Artist, Album, Genre, and Comment.
        /// </summary>
        public IEnumerable<Song> Search(string query)
        {
            if (string.IsNullOrWhiteSpace(query)) return Songs;
            var q = query.Trim();
            return Songs.Where(s =>
                s.Title.Contains(q,   StringComparison.OrdinalIgnoreCase) ||
                s.Artist.Contains(q,  StringComparison.OrdinalIgnoreCase) ||
                s.Album.Contains(q,   StringComparison.OrdinalIgnoreCase) ||
                s.Genre.Contains(q,   StringComparison.OrdinalIgnoreCase) ||
                (s.Comment?.Contains(q, StringComparison.OrdinalIgnoreCase) ?? false));
        }

        // ── Statistics ─────────────────────────────────────────────────────────

        public TimeSpan TotalDuration => TimeSpan.FromTicks(Songs.Sum(s => s.Duration.Ticks));

        public int UniqueArtistCount
            => Songs.Select(s => s.DisplayArtist).Distinct(StringComparer.OrdinalIgnoreCase).Count();

        public int UniqueAlbumCount
            => Songs.Where(s => !string.IsNullOrWhiteSpace(s.Album))
                    .Select(s => s.Album)
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .Count();

        /// <summary>Returns a summary string suitable for the status bar.</summary>
        public string GetStatsSummary()
        {
            var hours = (int)TotalDuration.TotalHours;
            var mins  = TotalDuration.Minutes;
            return $"{Songs.Count} songs  ·  {UniqueArtistCount} artists  ·  {UniqueAlbumCount} albums  ·  {hours}h {mins}m";
        }
    }
}
