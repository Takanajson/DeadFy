using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using DeadFy.Models;

namespace DeadFy.Services
{
    public class LibraryService
    {
        private static LibraryService? _instance;
        public static LibraryService Instance => _instance ??= new LibraryService();

        public string RootFolder   { get; private set; }
        public string MusicFolder  { get; private set; }
        public string CoversFolder { get; private set; }
        public string DataFolder   { get; private set; }

        private const string SongsFile     = "songs.json";
        private const string PlaylistsFile  = "playlists.json";

        // Lock used by async save to avoid concurrent writes
        private readonly object _saveLock = new();

        public ObservableCollection<Song>     Songs     { get; } = new();
        public ObservableCollection<Playlist> Playlists { get; } = new();

        private LibraryService()
        {
            RootFolder   = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyMusic), "DeadFy");
            MusicFolder  = Path.Combine(RootFolder, "Music");
            CoversFolder = Path.Combine(RootFolder, "Covers");
            DataFolder   = Path.Combine(RootFolder, "Data");
        }

        // ── Initialise ────────────────────────────────────────────────────────

        public void EnsureDirectories()
        {
            Directory.CreateDirectory(RootFolder);
            Directory.CreateDirectory(MusicFolder);
            Directory.CreateDirectory(CoversFolder);
            Directory.CreateDirectory(DataFolder);
            LoadLibrary();
        }

        // ── Load ──────────────────────────────────────────────────────────────

        public void LoadLibrary()
        {
            Songs.Clear();
            Playlists.Clear();

            // Songs — skip any whose file has been deleted externally
            var songsPath = Path.Combine(DataFolder, SongsFile);
            if (File.Exists(songsPath))
            {
                try
                {
                    var songs = JsonConvert.DeserializeObject<List<Song>>(File.ReadAllText(songsPath));
                    if (songs != null)
                        foreach (var s in songs.Where(s => s.IsStreaming || File.Exists(s.FilePath)))
                            Songs.Add(s);
                }
                catch (Exception ex)
                {
                    Logger.Instance.Error("LibraryService: failed to load songs.json", ex);
                }
            }

            // Playlists
            var playlistsPath = Path.Combine(DataFolder, PlaylistsFile);
            if (File.Exists(playlistsPath))
            {
                try
                {
                    var pls = JsonConvert.DeserializeObject<List<Playlist>>(File.ReadAllText(playlistsPath));
                    if (pls != null)
                        foreach (var pl in pls)
                            Playlists.Add(pl);
                }
                catch (Exception ex)
                {
                    Logger.Instance.Error("LibraryService: failed to load playlists.json", ex);
                }
            }
        }

        // ── Save (sync + async) ───────────────────────────────────────────────

        public void SaveLibrary()
        {
            lock (_saveLock)
            {
                try
                {
                    File.WriteAllText(
                        Path.Combine(DataFolder, SongsFile),
                        JsonConvert.SerializeObject(Songs.ToList(), Formatting.Indented));

                    File.WriteAllText(
                        Path.Combine(DataFolder, PlaylistsFile),
                        JsonConvert.SerializeObject(Playlists.ToList(), Formatting.Indented));
                }
                catch (Exception ex)
                {
                    Logger.Instance.Error("LibraryService: SaveLibrary failed", ex);
                }
            }
        }

        /// <summary>
        /// Writes the library on a background thread so the UI never stalls.
        /// Fire-and-forget; errors are logged.
        /// </summary>
        public Task SaveLibraryAsync()
            => Task.Run(SaveLibrary);

        // ── Add / remove songs ────────────────────────────────────────────────

        public Song? AddLocalSong(string mp3Path, string? coverSourcePath, string artist, string title)
        {
            try
            {
                // Copy audio file
                var destFileName = $"{Guid.NewGuid()}.mp3";
                var destPath     = Path.Combine(MusicFolder, destFileName);
                File.Copy(mp3Path, destPath, overwrite: true);

                // Copy cover
                string? coverDestPath = null;
                if (coverSourcePath != null && File.Exists(coverSourcePath))
                {
                    var coverFileName = $"{Guid.NewGuid()}{Path.GetExtension(coverSourcePath)}";
                    coverDestPath = Path.Combine(CoversFolder, coverFileName);
                    File.Copy(coverSourcePath, coverDestPath, overwrite: true);
                }

                // Read tags via TagLib
                var duration = TimeSpan.Zero;
                try
                {
                    using var tf = TagLib.File.Create(destPath);
                    duration = tf.Properties.Duration;
                    if (string.IsNullOrWhiteSpace(title))  title  = tf.Tag.Title           ?? Path.GetFileNameWithoutExtension(mp3Path);
                    if (string.IsNullOrWhiteSpace(artist)) artist = tf.Tag.FirstPerformer   ?? "Unknown Artist";
                }
                catch { /* TagLib failed — use provided values */ }

                var song = new Song
                {
                    Title     = string.IsNullOrWhiteSpace(title)  ? Path.GetFileNameWithoutExtension(mp3Path) : title,
                    Artist    = string.IsNullOrWhiteSpace(artist) ? "Unknown Artist" : artist,
                    FilePath  = destPath,
                    CoverPath = coverDestPath,
                    Duration  = duration,
                    Source    = SongSource.Local,
                    DateAdded = DateTime.Now
                };

                Songs.Add(song);
                _ = SaveLibraryAsync();
                return song;
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("AddLocalSong failed", ex);
                return null;
            }
        }

        public void RemoveSong(Song song)
        {
            Songs.Remove(song);
            foreach (var pl in Playlists)
                pl.Songs.Remove(song);
            _ = SaveLibraryAsync();

            // Delete audio file
            try
            {
                if (!string.IsNullOrEmpty(song.FilePath) && File.Exists(song.FilePath))
                    File.Delete(song.FilePath);
            }
            catch (Exception ex)
            {
                Logger.Instance.Warning($"LibraryService: could not delete file — {ex.Message}");
            }
        }

        // ── Playlists ─────────────────────────────────────────────────────────

        public Playlist CreatePlaylist(string name)
        {
            var pl = new Playlist { Name = name };
            Playlists.Add(pl);
            _ = SaveLibraryAsync();
            return pl;
        }

        public void DeletePlaylist(Playlist playlist)
        {
            Playlists.Remove(playlist);
            _ = SaveLibraryAsync();
        }

        public void AddSongToPlaylist(Playlist playlist, Song song)
        {
            if (playlist.Songs.Contains(song)) return;
            playlist.Songs.Add(song);
            _ = SaveLibraryAsync();
        }

        public void RemoveSongFromPlaylist(Playlist playlist, Song song)
        {
            playlist.Songs.Remove(song);
            _ = SaveLibraryAsync();
        }

        // ── Folder import ─────────────────────────────────────────────────────

        private static readonly HashSet<string> AudioExtensions = new(StringComparer.OrdinalIgnoreCase)
            { ".mp3", ".flac", ".wav", ".aac", ".ogg", ".m4a", ".wma", ".opus" };

        /// <summary>
        /// Scans a folder tree and imports all recognised audio files that are
        /// not already in the library.  Returns the new songs.
        /// </summary>
        public List<Song> ImportFolder(string folderPath)
        {
            var added = new List<Song>();
            var existingPaths = new HashSet<string>(Songs.Select(s => s.FilePath), StringComparer.OrdinalIgnoreCase);

            var files = Directory.GetFiles(folderPath, "*.*", SearchOption.AllDirectories);
            foreach (var file in files)
            {
                if (!AudioExtensions.Contains(Path.GetExtension(file))) continue;
                if (existingPaths.Contains(file)) continue;

                var duration = TimeSpan.Zero;
                var title    = Path.GetFileNameWithoutExtension(file);
                var artist   = "Unknown Artist";
                var album    = string.Empty;

                try
                {
                    using var tf = TagLib.File.Create(file);
                    duration = tf.Properties.Duration;
                    if (!string.IsNullOrWhiteSpace(tf.Tag.Title))          title  = tf.Tag.Title;
                    if (!string.IsNullOrWhiteSpace(tf.Tag.FirstPerformer)) artist = tf.Tag.FirstPerformer;
                    if (!string.IsNullOrWhiteSpace(tf.Tag.Album))          album  = tf.Tag.Album;
                }
                catch { /* use defaults */ }

                var song = new Song
                {
                    Title     = title,
                    Artist    = artist,
                    Album     = album,
                    FilePath  = file,
                    Duration  = duration,
                    Source    = SongSource.Local,
                    DateAdded = DateTime.Now
                };

                Songs.Add(song);
                added.Add(song);
                existingPaths.Add(file);
            }

            if (added.Count > 0)
            {
                _ = SaveLibraryAsync();
                Logger.Instance.Info($"ImportFolder: added {added.Count} songs from '{folderPath}'");
            }

            return added;
        }

        // ── Export / Import ───────────────────────────────────────────────────

        public void ExportLibrary(string destPath)
        {
            var export = new { ExportedAt = DateTime.Now, Songs = Songs.ToList(), Playlists = Playlists.ToList() };
            File.WriteAllText(destPath, JsonConvert.SerializeObject(export, Formatting.Indented));
            Logger.Instance.Info($"Library exported to '{destPath}'");
        }

        public int ImportLibrary(string srcPath)
        {
            try
            {
                var json = File.ReadAllText(srcPath);
                dynamic? data = JsonConvert.DeserializeObject(json);
                if (data == null) return 0;

                int added = 0;
                var songs = JsonConvert.DeserializeObject<List<Song>>(data.Songs.ToString());
                if (songs != null)
                {
                    var existingIds = new HashSet<string>(Songs.Select(s => s.Id));
                    foreach (var s in songs)
                    {
                        if (existingIds.Contains(s.Id)) continue;
                        if (!s.IsStreaming && !File.Exists(s.FilePath)) continue;
                        Songs.Add(s);
                        existingIds.Add(s.Id);
                        added++;
                    }
                }

                if (added > 0) _ = SaveLibraryAsync();
                Logger.Instance.Info($"ImportLibrary: merged {added} songs from '{srcPath}'");
                return added;
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("ImportLibrary failed", ex);
                return 0;
            }
        }

        // ── Smart views ───────────────────────────────────────────────────────

        public List<Song> GetMostPlayed(int top = 25)
            => Songs.Where(s => s.PlayCount > 0)
                    .OrderByDescending(s => s.PlayCount)
                    .Take(top).ToList();

        public List<Song> GetRecentlyAdded(int top = 25)
            => Songs.OrderByDescending(s => s.DateAdded).Take(top).ToList();

        public List<Song> GetFavorites()
            => Songs.Where(s => s.IsFavorite).ToList();

        public List<Song> GetNeverPlayed()
            => Songs.Where(s => s.PlayCount == 0).ToList();

        public List<Song> GetRecentlyPlayed(int top = 25)
            => Songs.Where(s => s.LastPlayed.HasValue)
                    .OrderByDescending(s => s.LastPlayed)
                    .Take(top).ToList();

        // ── Sorted / searched views ───────────────────────────────────────────

        public IEnumerable<Song> GetSorted(string by, bool descending)
        {
            IEnumerable<Song> q = Songs;
            q = by switch
            {
                "Title"      => descending ? q.OrderByDescending(s => s.DisplayTitle)  : q.OrderBy(s => s.DisplayTitle),
                "Artist"     => descending ? q.OrderByDescending(s => s.DisplayArtist) : q.OrderBy(s => s.DisplayArtist),
                "Duration"   => descending ? q.OrderByDescending(s => s.Duration)      : q.OrderBy(s => s.Duration),
                "PlayCount"  => descending ? q.OrderByDescending(s => s.PlayCount)     : q.OrderBy(s => s.PlayCount),
                "LastPlayed" => descending ? q.OrderByDescending(s => s.LastPlayed)    : q.OrderBy(s => s.LastPlayed),
                _            => descending ? q.OrderByDescending(s => s.DateAdded)     : q.OrderBy(s => s.DateAdded),
            };
            return q;
        }

        /// <summary>
        /// Case-insensitive search across Title, Artist, and Album.
        /// Returns songs where any field contains <paramref name="query"/>.
        /// </summary>
        public IEnumerable<Song> Search(string query)
        {
            if (string.IsNullOrWhiteSpace(query)) return Songs;
            var q = query.Trim();
            return Songs.Where(s =>
                s.Title.Contains(q,  StringComparison.OrdinalIgnoreCase) ||
                s.Artist.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                s.Album.Contains(q,  StringComparison.OrdinalIgnoreCase));
        }

        // ── Statistics ────────────────────────────────────────────────────────

        /// <summary>Total duration of all songs in the library.</summary>
        public TimeSpan TotalDuration => TimeSpan.FromTicks(Songs.Sum(s => s.Duration.Ticks));

        /// <summary>Number of unique artists in the library.</summary>
        public int UniqueArtistCount
            => Songs.Select(s => s.DisplayArtist).Distinct(StringComparer.OrdinalIgnoreCase).Count();
    }
}
