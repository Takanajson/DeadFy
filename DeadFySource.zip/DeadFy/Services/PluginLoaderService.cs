using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using DeadFy.Models;
using DeadFy.Plugins;

namespace DeadFy.Services
{
    // ══════════════════════════════════════════════════════════════════
    //  PLUGIN INFO  — runtime descriptor for one loaded plugin
    // ══════════════════════════════════════════════════════════════════
    public class PluginInfo : INotifyPropertyChanged
    {
        public string Name        { get; init; } = string.Empty;
        public string Version     { get; init; } = string.Empty;
        public string Author      { get; init; } = string.Empty;
        public string Description { get; init; } = string.Empty;
        public string FilePath    { get; init; } = string.Empty;
        public string FileName    => Path.GetFileName(FilePath);

        public List<string> Capabilities { get; init; } = new();
        public string CapabilityTags => string.Join("  ", Capabilities.Select(c => $"[{c}]"));

        private bool _isEnabled = true;
        public bool IsEnabled
        {
            get => _isEnabled;
            set { _isEnabled = value; OnPropertyChanged(); }
        }

        private string _status = "Loaded";
        public string Status
        {
            get => _status;
            set { _status = value; OnPropertyChanged(); OnPropertyChanged(nameof(HasError)); }
        }

        public bool HasError => Status.StartsWith("Error");

        internal IDeadPlugin?         Instance    { get; set; }
        internal AssemblyLoadContext? LoadContext { get; set; }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? n = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
    }

    // ══════════════════════════════════════════════════════════════════
    //  PLUGIN LOADER SERVICE
    // ══════════════════════════════════════════════════════════════════
    public class PluginLoaderService : INotifyPropertyChanged
    {
        private static PluginLoaderService? _instance;
        public static PluginLoaderService Instance => _instance ??= new PluginLoaderService();

        public static string PluginsDir => Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, "Plugins");

        private readonly FileSystemWatcher _watcher;
        private readonly System.Windows.Threading.Dispatcher _dispatcher;
        private readonly Dictionary<string, PluginInfo> _plugins = new();
        private IPluginHost? _host;

        // ── Public collections ────────────────────────────────────────
        public ObservableCollection<PluginInfo> Plugins { get; } = new();

        // ── Extension point registries ────────────────────────────────
        public List<IAudioPlugin>    AudioPlugins    { get; } = new();
        public List<ILyricsPlugin>   LyricsPlugins   { get; } = new();
        public List<ISearchPlugin>   SearchPlugins   { get; } = new();
        public List<IMetadataPlugin> MetadataPlugins { get; } = new();

        private PluginLoaderService()
        {
            _dispatcher = Application.Current.Dispatcher;
            Directory.CreateDirectory(PluginsDir);
            WritePluginReadme();

            _watcher = new FileSystemWatcher(PluginsDir, "*.dll")
            {
                NotifyFilter          = NotifyFilters.FileName | NotifyFilters.LastWrite,
                EnableRaisingEvents   = false,
                IncludeSubdirectories = false
            };
            _watcher.Created += (_, e) => _ = HotReloadAsync(e.FullPath);
            _watcher.Changed += (_, e) => _ = HotReloadAsync(e.FullPath);
        }

        public void Initialize(IPluginHost host)
        {
            _host = host;
            LoadAllPlugins();
            _watcher.EnableRaisingEvents = true;
            Log("Plugin system initialized. Watching: " + PluginsDir);
        }

        private void LoadAllPlugins()
        {
            foreach (var dll in Directory.GetFiles(PluginsDir, "*.dll"))
                LoadPlugin(dll);
        }

        private void LoadPlugin(string dllPath)
        {
            var key = Path.GetFileNameWithoutExtension(dllPath).ToLowerInvariant();
            try
            {
                Log($"[Plugin] Loading: {Path.GetFileName(dllPath)}", LogLevel.Debug);

                var ctx = new PluginLoadContext(dllPath);
                var asm = ctx.LoadFromAssemblyPath(dllPath);

                // ── Get all types, tolerating partial load failures ───
                Type[] allTypes;
                try
                {
                    allTypes = asm.GetTypes();
                }
                catch (ReflectionTypeLoadException ex)
                {
                    Log($"[Plugin] Type load errors in {Path.GetFileName(dllPath)}:", LogLevel.Error);
                    foreach (var le in ex.LoaderExceptions)
                        if (le != null) Log($"  → {le.Message}", LogLevel.Error);
                    allTypes = ex.Types.Where(t => t != null).ToArray()!;
                }

                Log($"[Plugin] {allTypes.Length} types found", LogLevel.Debug);

                // ── Find entry point by ATTRIBUTE CLASS NAME (string) ─
                // We match by name rather than type identity so the plugin
                // works whether it compiled IDeadPlugin.cs directly or
                // referenced DeadFy.SDK.dll — both produce an attribute
                // named "DeadPluginAttribute" even if the CLR treats them
                // as different Type objects across load contexts.
                Type? entryType = null;
                foreach (var t in allTypes)
                {
                    if (t.IsAbstract) continue;

                    var hasAttr = t.GetCustomAttributesData()
                        .Any(a => a.AttributeType.Name == "DeadPluginAttribute");

                    if (!hasAttr) continue;

                    Log($"[Plugin] Found [DeadPlugin] on: {t.FullName}", LogLevel.Debug);

                    // Accept as long as it has an interface named IDeadPlugin
                    var implementsBase = t.GetInterfaces()
                        .Any(i => i.Name == "IDeadPlugin");

                    if (implementsBase)
                    {
                        entryType = t;
                        break;
                    }

                    Log($"[Plugin] {t.FullName} has [DeadPlugin] but does not implement IDeadPlugin.", LogLevel.Warning);
                }

                if (entryType == null)
                {
                    Log($"[Plugin] {Path.GetFileName(dllPath)}: No valid [DeadPlugin] entry point — skipping.", LogLevel.Warning);
                    ctx.Unload();
                    return;
                }

                // ── Read attribute constructor args by position ────────
                var attrData = entryType.GetCustomAttributesData()
                    .First(a => a.AttributeType.Name == "DeadPluginAttribute");

                string Arg(int i, string fallback) =>
                    attrData.ConstructorArguments.Count > i
                        ? attrData.ConstructorArguments[i].Value?.ToString() ?? fallback
                        : fallback;

                var pluginName    = Arg(0, "Unknown");
                var pluginVersion = Arg(1, "1.0.0");
                var pluginAuthor  = Arg(2, "Unknown");
                var pluginDesc    = Arg(3, "");

                // ── Detect capabilities by interface name ─────────────
                var ifaceNames = entryType.GetInterfaces().Select(i => i.Name).ToHashSet();
                var caps = new List<string>();
                if (ifaceNames.Contains("IAudioPlugin"))    caps.Add("Audio");
                if (ifaceNames.Contains("ILyricsPlugin"))   caps.Add("Lyrics");
                if (ifaceNames.Contains("ISearchPlugin"))   caps.Add("Search");
                if (ifaceNames.Contains("IMetadataPlugin")) caps.Add("Metadata");
                if (caps.Count == 0) caps.Add("General");

                Log($"[Plugin] Capabilities: {string.Join(", ", caps)}", LogLevel.Debug);

                // ── Instantiate raw object ────────────────────────────
                var rawInstance = Activator.CreateInstance(entryType)
                    ?? throw new InvalidOperationException($"Activator returned null for {entryType.FullName}");

                // ── Wrap in a proxy that implements the HOST's interfaces
                // This bridges the type-identity gap: the proxy implements
                // DeadFy's own ISearchPlugin (etc.) and forwards calls to
                // the plugin's raw instance via reflection.
                var instance = PluginProxy.Wrap(rawInstance, ifaceNames, _host!);

                // ── Register in extension chains ──────────────────────
                if (instance is IAudioPlugin    ap) { AudioPlugins.Add(ap);  AudioPlugins.Sort((a, b) => a.Priority.CompareTo(b.Priority)); }
                if (instance is ILyricsPlugin   lp) { LyricsPlugins.Add(lp); LyricsPlugins.Sort((a, b) => a.Priority.CompareTo(b.Priority)); }
                if (instance is ISearchPlugin   sp) SearchPlugins.Add(sp);
                if (instance is IMetadataPlugin mp) MetadataPlugins.Add(mp);

                var info = new PluginInfo
                {
                    Name         = pluginName,
                    Version      = pluginVersion,
                    Author       = pluginAuthor,
                    Description  = pluginDesc,
                    FilePath     = dllPath,
                    Capabilities = caps,
                    Status       = "✓ Loaded",
                    Instance     = instance,
                    LoadContext  = ctx
                };

                _plugins[key] = info;
                _dispatcher.Invoke(() => Plugins.Add(info));
                Log($"[Plugin] ✓ Loaded: {pluginName} v{pluginVersion} by {pluginAuthor} ({string.Join(", ", caps)})");
            }
            catch (Exception ex)
            {
                Log($"[Plugin] Failed to load {Path.GetFileName(dllPath)}: {ex.Message}", LogLevel.Error);
                Log($"[Plugin] Stack: {ex.StackTrace}", LogLevel.Debug);
                var errorInfo = new PluginInfo
                {
                    Name         = Path.GetFileNameWithoutExtension(dllPath),
                    FilePath     = dllPath,
                    Status       = $"Error: {ex.Message}",
                    Capabilities = new List<string> { "Error" }
                };
                _dispatcher.Invoke(() => Plugins.Add(errorInfo));
            }
        }

        // ── Hot reload ────────────────────────────────────────────────
        private readonly SemaphoreSlim _reloadLock = new(1, 1);

        private async Task HotReloadAsync(string dllPath)
        {
            await _reloadLock.WaitAsync();
            try
            {
                await Task.Delay(500);
                var key = Path.GetFileNameWithoutExtension(dllPath).ToLowerInvariant();

                if (_plugins.TryGetValue(key, out var existing))
                {
                    UnloadPlugin(existing);
                    _plugins.Remove(key);
                    _dispatcher.Invoke(() => Plugins.Remove(existing));
                }

                LoadPlugin(dllPath);
                _host?.ShowNotification($"Plugin reloaded: {Path.GetFileName(dllPath)}", NotificationKind.Success);
            }
            finally { _reloadLock.Release(); }
        }

        private void UnloadPlugin(PluginInfo info)
        {
            try
            {
                if (info.Instance is IAudioPlugin    ap) AudioPlugins.Remove(ap);
                if (info.Instance is ILyricsPlugin   lp) LyricsPlugins.Remove(lp);
                if (info.Instance is ISearchPlugin   sp) SearchPlugins.Remove(sp);
                if (info.Instance is IMetadataPlugin mp) MetadataPlugins.Remove(mp);

                info.Instance?.Shutdown();
                info.Instance?.Dispose();
                info.LoadContext?.Unload();
            }
            catch (Exception ex)
            {
                Log($"[Plugin] Error unloading {info.Name}: {ex.Message}", LogLevel.Warning);
            }
        }

        public void EnablePlugin(PluginInfo info)  { info.IsEnabled = true;  info.Status = "✓ Loaded";   Log($"[Plugin] Enabled: {info.Name}");  }
        public void DisablePlugin(PluginInfo info) { info.IsEnabled = false; info.Status = "⏸ Disabled"; Log($"[Plugin] Disabled: {info.Name}"); }
        public void ReloadPlugin(PluginInfo info)  => _ = HotReloadAsync(info.FilePath);
        public void OpenPluginsFolder()            => Process.Start(new ProcessStartInfo(PluginsDir) { UseShellExecute = true });

        public void ProcessAudioChain(float[] samples, int sampleRate, int channels)
        {
            foreach (var plugin in AudioPlugins)
                if (plugin.IsEnabled)
                    try { plugin.ProcessAudio(samples, sampleRate, channels); }
                    catch (Exception ex) { Log($"[AudioPlugin] {ex.Message}", LogLevel.Error); }
        }

        public async Task<LyricsData?> TryGetLyricsFromPluginsAsync(string title, string artist,
            CancellationToken ct = default)
        {
            foreach (var plugin in LyricsPlugins)
                try
                {
                    var result = await plugin.GetLyricsAsync(title, artist, ct);
                    if (result != null) return result;
                }
                catch (Exception ex) { Log($"[LyricsPlugin] {ex.Message}", LogLevel.Warning); }
            return null;
        }

        public async Task EnrichSongMetadataAsync(Song song, CancellationToken ct = default)
        {
            foreach (var plugin in MetadataPlugins)
                try { await plugin.EnrichAsync(song, ct); }
                catch (Exception ex) { Log($"[MetadataPlugin] {ex.Message}", LogLevel.Warning); }
        }

        // ── Logging ───────────────────────────────────────────────────
        public ObservableCollection<string> Logs { get; } = new();
        private const int MaxLogs = 500;

        public void Log(string message, LogLevel level = LogLevel.Info)
        {
            var line = $"[{DateTime.Now:HH:mm:ss}] [{level}] {message}";
            Debug.WriteLine(line);
            _dispatcher.Invoke(() =>
            {
                Logs.Add(line);
                if (Logs.Count > MaxLogs) Logs.RemoveAt(0);
            });
        }

        private void WritePluginReadme()
        {
            var path = Path.Combine(PluginsDir, "HOW_TO_CREATE_A_PLUGIN.txt");
            if (File.Exists(path)) return;
            File.WriteAllText(path, @"
╔════════════════════════════════════════════════════════╗
║         DeadFy Plugin Development Guide              ║
╚════════════════════════════════════════════════════════╝

QUICK START
───────────
1. Create a new .NET 8 Class Library project in Visual Studio
2. Copy IDeadPlugin.cs (from this folder) into your project
3. Implement IDeadPlugin + one of the extension interfaces
4. Add [DeadPlugin] attribute to your main class
5. Build → copy YourPlugin.dll into this Plugins/ folder
6. DeadFy loads it automatically (hot-reload while running too!)

PLUGIN TYPES
────────────
IAudioPlugin     — Process raw PCM audio samples (EQ, effects, etc.)
ILyricsPlugin    — Provide synced/plain lyrics from any source
ISearchPlugin    — Add a new Search tab (SoundCloud, Bandcamp, etc.)
IMetadataPlugin  — Enrich song metadata on import (BPM, key, mood, art)
");
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? n = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
    }

    // ══════════════════════════════════════════════════════════════════
    //  PLUGIN PROXY
    //
    //  The core problem: a plugin compiled with its own copy of
    //  IDeadPlugin.cs has types like ISearchPlugin that are DIFFERENT
    //  CLR Type objects from the host's ISearchPlugin, even though the
    //  source is identical. So "pluginInstance is ISearchPlugin" = false.
    //
    //  Solution: wrap the raw plugin object in a proxy class that:
    //    • Implements the HOST's interface types (so "is ISearchPlugin" = true)
    //    • Forwards every call to the raw plugin via reflection
    //
    //  This means plugins work regardless of how they were compiled.
    // ══════════════════════════════════════════════════════════════════
    internal static class PluginProxy
    {
        public static IDeadPlugin Wrap(object raw, HashSet<string> ifaceNames, IPluginHost host)
        {
            if (ifaceNames.Contains("ISearchPlugin"))   return new SearchPluginProxy(raw, host);
            if (ifaceNames.Contains("IAudioPlugin"))    return new AudioPluginProxy(raw, host);
            if (ifaceNames.Contains("ILyricsPlugin"))   return new LyricsPluginProxy(raw, host);
            if (ifaceNames.Contains("IMetadataPlugin")) return new MetadataPluginProxy(raw, host);
            return new BasePluginProxy(raw, host);
        }

        // ── Reflection helpers ────────────────────────────────────────
        private static void Call(object o, string method, params object?[] args)
            => o.GetType().GetMethod(method)?.Invoke(o, args);

        private static T Get<T>(object o, string prop)
            => (T)o.GetType().GetProperty(prop)!.GetValue(o)!;

        private static async Task<object?> AwaitTask(object taskObj)
        {
            await (Task)taskObj;
            return taskObj.GetType().GetProperty("Result")?.GetValue(taskObj);
        }

        // ── Base ──────────────────────────────────────────────────────
        private class BasePluginProxy : IDeadPlugin
        {
            protected readonly object     _raw;
            protected readonly IPluginHost _host;

            public BasePluginProxy(object raw, IPluginHost host)
            {
                _raw  = raw;
                _host = host;
                Call(_raw, "Initialize", host);
            }

            public void Initialize(IPluginHost host) { }
            public void Shutdown() => Call(_raw, "Shutdown");
            public void Dispose()  => (_raw as IDisposable)?.Dispose();
        }

        // ── Search ────────────────────────────────────────────────────
        private class SearchPluginProxy : BasePluginProxy, ISearchPlugin
        {
            public SearchPluginProxy(object raw, IPluginHost host) : base(raw, host) { }

            public string SourceName => Get<string>(_raw, "SourceName");
            public string SourceIcon => Get<string>(_raw, "SourceIcon");

            public async Task<IReadOnlyList<SearchResult>> SearchAsync(
                string query, CancellationToken ct = default)
            {
                var taskObj = _raw.GetType()
                    .GetMethod("SearchAsync")!
                    .Invoke(_raw, new object[] { query, ct })!;

                var rawResult = await AwaitTask(taskObj) as System.Collections.IEnumerable;
                if (rawResult == null) return Array.Empty<SearchResult>();

                var list = new List<SearchResult>();
                foreach (var item in rawResult)
                {
                    var t = item.GetType();
                    list.Add(new SearchResult
                    {
                        Id           = t.GetProperty("Id")?.GetValue(item)?.ToString()           ?? "",
                        Title        = t.GetProperty("Title")?.GetValue(item)?.ToString()        ?? "",
                        Author       = t.GetProperty("Author")?.GetValue(item)?.ToString()       ?? "",
                        Duration     = (TimeSpan)(t.GetProperty("Duration")?.GetValue(item)      ?? TimeSpan.Zero),
                        ThumbnailUrl = t.GetProperty("ThumbnailUrl")?.GetValue(item)?.ToString() ?? "",
                        Url          = t.GetProperty("Url")?.GetValue(item)?.ToString()          ?? "",
                        Source       = t.GetProperty("Source")?.GetValue(item)?.ToString()       ?? "",
                        Extra        = t.GetProperty("Extra")?.GetValue(item)
                    });
                }
                return list;
            }

            public async Task<Song?> ResolveAsync(
                SearchResult result,
                IProgress<double>? progress = null,
                CancellationToken ct = default)
            {
                // Rebuild SearchResult in the plugin's own type if needed
                var pluginSrType = _raw.GetType().Assembly.GetTypes()
                    .FirstOrDefault(t => t.Name == "SearchResult");

                object pluginResult;
                if (pluginSrType != null)
                {
                    pluginResult = Activator.CreateInstance(pluginSrType)!;
                    void Set(string p, object? v) => pluginSrType.GetProperty(p)?.SetValue(pluginResult, v);
                    Set("Id",           result.Id);
                    Set("Title",        result.Title);
                    Set("Author",       result.Author);
                    Set("Duration",     result.Duration);
                    Set("ThumbnailUrl", result.ThumbnailUrl);
                    Set("Url",          result.Url);
                    Set("Source",       result.Source);
                    Set("Extra",        result.Extra);
                }
                else
                {
                    pluginResult = result;
                }

                var taskObj = _raw.GetType()
                    .GetMethod("ResolveAsync")!
                    .Invoke(_raw, new object?[] { pluginResult, progress, ct })!;

                var raw = await AwaitTask(taskObj);
                if (raw == null) return null;

                var rt = raw.GetType();
                T? Prop<T>(string name) => (T?)rt.GetProperty(name)?.GetValue(raw);

                return new Song
                {
                    Title        = Prop<string>("Title")   ?? "",
                    Artist       = Prop<string>("Artist")  ?? "",
                    Album        = Prop<string>("Album")   ?? "",
                    FilePath     = Prop<string>("FilePath") ?? "",
                    ThumbnailUrl = Prop<string>("ThumbnailUrl"),
                    StreamUrl    = Prop<string>("StreamUrl"),
                    Duration     = Prop<TimeSpan>("Duration"),
                    IsStreaming  = Prop<bool>("IsStreaming"),
                    Source       = SongSource.Stream
                };
            }
        }

        // ── Audio ─────────────────────────────────────────────────────
        private class AudioPluginProxy : BasePluginProxy, IAudioPlugin
        {
            public AudioPluginProxy(object raw, IPluginHost host) : base(raw, host) { }
            public string ProcessorName => Get<string>(_raw, "ProcessorName");
            public int    Priority      => Get<int>(_raw, "Priority");
            public bool IsEnabled
            {
                get => Get<bool>(_raw, "IsEnabled");
                set => _raw.GetType().GetProperty("IsEnabled")?.SetValue(_raw, value);
            }
            public void ProcessAudio(float[] samples, int sampleRate, int channels)
                => Call(_raw, "ProcessAudio", samples, sampleRate, channels);
        }

        // ── Lyrics ────────────────────────────────────────────────────
        private class LyricsPluginProxy : BasePluginProxy, ILyricsPlugin
        {
            public LyricsPluginProxy(object raw, IPluginHost host) : base(raw, host) { }
            public string ProviderName => Get<string>(_raw, "ProviderName");
            public int    Priority     => Get<int>(_raw, "Priority");

            public async Task<LyricsData?> GetLyricsAsync(
                string title, string artist, CancellationToken ct = default)
            {
                var taskObj = _raw.GetType()
                    .GetMethod("GetLyricsAsync")!
                    .Invoke(_raw, new object[] { title, artist, ct })!;

                var raw = await AwaitTask(taskObj);
                if (raw == null) return null;

                var rt    = raw.GetType();
                var plain = rt.GetProperty("PlainLyrics")?.GetValue(raw)?.ToString() ?? "";
                var lines = new List<LyricLineData>();

                if (rt.GetProperty("SyncedLines")?.GetValue(raw) is System.Collections.IEnumerable synced)
                    foreach (var line in synced)
                    {
                        var lt = line.GetType();
                        lines.Add(new LyricLineData
                        {
                            Time = (TimeSpan)(lt.GetProperty("Time")?.GetValue(line) ?? TimeSpan.Zero),
                            Text = lt.GetProperty("Text")?.GetValue(line)?.ToString() ?? ""
                        });
                    }

                return new LyricsData { PlainLyrics = plain, SyncedLines = lines };
            }
        }

        // ── Metadata ──────────────────────────────────────────────────
        private class MetadataPluginProxy : BasePluginProxy, IMetadataPlugin
        {
            public MetadataPluginProxy(object raw, IPluginHost host) : base(raw, host) { }
            public string EnricherName => Get<string>(_raw, "EnricherName");
            public async Task EnrichAsync(Song song, CancellationToken ct = default)
            {
                var taskObj = _raw.GetType()
                    .GetMethod("EnrichAsync")!
                    .Invoke(_raw, new object[] { song, ct })!;
                await (Task)taskObj;
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    //  ISOLATED ASSEMBLY LOAD CONTEXT
    // ══════════════════════════════════════════════════════════════════
    internal class PluginLoadContext : AssemblyLoadContext
    {
        private readonly AssemblyDependencyResolver _resolver;

        public PluginLoadContext(string pluginPath) : base(isCollectible: true)
        {
            _resolver = new AssemblyDependencyResolver(pluginPath);
        }

        protected override Assembly? Load(AssemblyName assemblyName)
        {
            // Load private plugin dependencies from its own folder
            var path = _resolver.ResolveAssemblyToPath(assemblyName);
            if (path != null) return LoadFromAssemblyPath(path);

            // Fallback: share from the host's Default context
            return null;
        }

        protected override IntPtr LoadUnmanagedDll(string unmanagedDllName)
        {
            var path = _resolver.ResolveUnmanagedDllToPath(unmanagedDllName);
            return path != null ? LoadUnmanagedDllFromPath(path) : IntPtr.Zero;
        }
    }
}
