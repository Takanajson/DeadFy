using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using DeadFy.Models;
using DeadFy.Plugins;

namespace DeadFy.Services
{
    // ══════════════════════════════════════════════════════════════════
    //  PLUGIN INFO  — runtime descriptor for one loaded plugin
    // ══════════════════════════════════════════════════════════════════
    public class PluginInfo : INotifyPropertyChanged
    {
        public string Name        { get; init; } = string.Empty;
        public string Version     { get; init; } = string.Empty;
        public string Author      { get; init; } = string.Empty;
        public string Description { get; init; } = string.Empty;
        public string FilePath    { get; init; } = string.Empty;
        public string FileName    => Path.GetFileName(FilePath);

        public List<string> Capabilities { get; init; } = new();
        public string CapabilityTags => string.Join("  ", Capabilities.Select(c => $"[{c}]"));

        private bool _isEnabled = true;
        public bool IsEnabled
        {
            get => _isEnabled;
            set { _isEnabled = value; OnPropertyChanged(); }
        }

        private string _status = "Loaded";
        public string Status
        {
            get => _status;
            set { _status = value; OnPropertyChanged(); OnPropertyChanged(nameof(HasError)); }
        }

        public bool HasError => Status.StartsWith("Error");

        internal IDeadPlugin?      Instance    { get; set; }
        internal AssemblyLoadContext? LoadContext { get; set; }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? n = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
    }

    // ══════════════════════════════════════════════════════════════════
    //  PLUGIN LOADER SERVICE
    // ══════════════════════════════════════════════════════════════════
    public class PluginLoaderService : INotifyPropertyChanged
    {
        private static PluginLoaderService? _instance;
        public static PluginLoaderService Instance => _instance ??= new PluginLoaderService();

        public static string PluginsDir => Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, "Plugins");

        private readonly FileSystemWatcher _watcher;
        private readonly System.Windows.Threading.Dispatcher _dispatcher;
        private readonly Dictionary<string, PluginInfo> _plugins = new();
        private IPluginHost? _host;

        // ── Public collections ────────────────────────────────────────
        public ObservableCollection<PluginInfo> Plugins { get; } = new();

        // ── Extension point registries ────────────────────────────────
        public List<IAudioPlugin>    AudioPlugins    { get; } = new();
        public List<ILyricsPlugin>   LyricsPlugins   { get; } = new();
        public List<ISearchPlugin>   SearchPlugins   { get; } = new();
        public List<IMetadataPlugin> MetadataPlugins { get; } = new();

        private PluginLoaderService()
        {
            _dispatcher = Application.Current.Dispatcher;
            Directory.CreateDirectory(PluginsDir);

            // Create README for plugin devs
            WritePluginReadme();

            // Watch for new/updated DLLs
            _watcher = new FileSystemWatcher(PluginsDir, "*.dll")
            {
                NotifyFilter          = NotifyFilters.FileName | NotifyFilters.LastWrite,
                EnableRaisingEvents   = false,
                IncludeSubdirectories = false
            };
            _watcher.Created += (_, e) => _ = HotReloadAsync(e.FullPath);
            _watcher.Changed += (_, e) => _ = HotReloadAsync(e.FullPath);
        }

        // ── Initialise with host + scan on startup ────────────────────
        public void Initialize(IPluginHost host)
        {
            _host = host;
            LoadAllPlugins();
            _watcher.EnableRaisingEvents = true;
            Log("Plugin system initialized. Watching: " + PluginsDir);
        }

        // ── Scan and load all DLLs in Plugins folder ─────────────────
        private void LoadAllPlugins()
        {
            foreach (var dll in Directory.GetFiles(PluginsDir, "*.dll"))
                LoadPlugin(dll);
        }

        private void LoadPlugin(string dllPath)
        {
            var key = Path.GetFileNameWithoutExtension(dllPath).ToLowerInvariant();
            try
            {
                // Each plugin gets its own isolated load context so it can be unloaded
                var ctx = new PluginLoadContext(dllPath);
                var asm = ctx.LoadFromAssemblyPath(dllPath);

                // Find the entry point class — the one with [DeadPlugin]
                var entryType = asm.GetTypes().FirstOrDefault(t =>
                    t.GetCustomAttribute<DeadPluginAttribute>() != null &&
                    typeof(IDeadPlugin).IsAssignableFrom(t) &&
                    !t.IsAbstract);

                if (entryType == null)
                {
                    Log($"[Plugin] {Path.GetFileName(dllPath)}: No [DeadPlugin] entry point found — skipping.", LogLevel.Warning);
                    ctx.Unload();
                    return;
                }

                var attr = entryType.GetCustomAttribute<DeadPluginAttribute>()!;

                // Detect capabilities
                var caps = new List<string>();
                if (typeof(IAudioPlugin)   .IsAssignableFrom(entryType)) caps.Add("Audio");
                if (typeof(ILyricsPlugin)  .IsAssignableFrom(entryType)) caps.Add("Lyrics");
                if (typeof(ISearchPlugin)  .IsAssignableFrom(entryType)) caps.Add("Search");
                if (typeof(IMetadataPlugin).IsAssignableFrom(entryType)) caps.Add("Metadata");
                if (caps.Count == 0) caps.Add("General");

                var instance = (IDeadPlugin)Activator.CreateInstance(entryType)!;
                instance.Initialize(_host!);

                // Register in extension chains
                if (instance is IAudioPlugin    ap) { AudioPlugins.Add(ap);    AudioPlugins.Sort((a, b) => a.Priority.CompareTo(b.Priority)); }
                if (instance is ILyricsPlugin   lp) { LyricsPlugins.Add(lp);   LyricsPlugins.Sort((a, b) => a.Priority.CompareTo(b.Priority)); }
                if (instance is ISearchPlugin   sp) { SearchPlugins.Add(sp);   }
                if (instance is IMetadataPlugin mp) { MetadataPlugins.Add(mp); }

                var info = new PluginInfo
                {
                    Name         = attr.Name,
                    Version      = attr.Version,
                    Author       = attr.Author,
                    Description  = attr.Description,
                    FilePath     = dllPath,
                    Capabilities = caps,
                    Status       = "✓ Loaded",
                    Instance     = instance,
                    LoadContext  = ctx
                };

                _plugins[key] = info;
                _dispatcher.Invoke(() => Plugins.Add(info));
                Log($"[Plugin] Loaded: {attr.Name} v{attr.Version} by {attr.Author} ({string.Join(", ", caps)})");
            }
            catch (Exception ex)
            {
                Log($"[Plugin] Failed to load {Path.GetFileName(dllPath)}: {ex.Message}", LogLevel.Error);
                var errorInfo = new PluginInfo
                {
                    Name     = Path.GetFileNameWithoutExtension(dllPath),
                    FilePath = dllPath,
                    Status   = $"Error: {ex.Message}",
                    Capabilities = new List<string> { "Error" }
                };
                _dispatcher.Invoke(() => Plugins.Add(errorInfo));
            }
        }

        // ── Hot reload — unload old, load new ─────────────────────────
        private readonly SemaphoreSlim _reloadLock = new(1, 1);

        private async Task HotReloadAsync(string dllPath)
        {
            await _reloadLock.WaitAsync();
            try
            {
                // Small delay so the file write is complete
                await Task.Delay(500);
                var key = Path.GetFileNameWithoutExtension(dllPath).ToLowerInvariant();

                // Unload existing
                if (_plugins.TryGetValue(key, out var existing))
                {
                    UnloadPlugin(existing);
                    _plugins.Remove(key);
                    _dispatcher.Invoke(() => Plugins.Remove(existing));
                }

                // Reload
                LoadPlugin(dllPath);
                _host?.ShowNotification($"Plugin reloaded: {Path.GetFileName(dllPath)}", NotificationKind.Success);
            }
            finally { _reloadLock.Release(); }
        }

        // ── Unload a plugin ───────────────────────────────────────────
        private void UnloadPlugin(PluginInfo info)
        {
            try
            {
                if (info.Instance is IAudioPlugin    ap) AudioPlugins.Remove(ap);
                if (info.Instance is ILyricsPlugin   lp) LyricsPlugins.Remove(lp);
                if (info.Instance is ISearchPlugin   sp) SearchPlugins.Remove(sp);
                if (info.Instance is IMetadataPlugin mp) MetadataPlugins.Remove(mp);

                info.Instance?.Shutdown();
                info.Instance?.Dispose();
                info.LoadContext?.Unload();
            }
            catch (Exception ex)
            {
                Log($"[Plugin] Error unloading {info.Name}: {ex.Message}", LogLevel.Warning);
            }
        }

        // ── Public control ────────────────────────────────────────────
        public void EnablePlugin(PluginInfo info)
        {
            info.IsEnabled = true;
            info.Status = "✓ Loaded";
            Log($"[Plugin] Enabled: {info.Name}");
        }

        public void DisablePlugin(PluginInfo info)
        {
            info.IsEnabled = false;
            info.Status = "⏸ Disabled";
            Log($"[Plugin] Disabled: {info.Name}");
        }

        public void ReloadPlugin(PluginInfo info)
            => _ = HotReloadAsync(info.FilePath);

        public void OpenPluginsFolder()
            => Process.Start(new ProcessStartInfo(PluginsDir) { UseShellExecute = true });

        // ── Audio chain ───────────────────────────────────────────────
        /// <summary>Run audio samples through all enabled IAudioPlugin processors in priority order.</summary>
        public void ProcessAudioChain(float[] samples, int sampleRate, int channels)
        {
            foreach (var plugin in AudioPlugins)
                if (plugin.IsEnabled)
                    try { plugin.ProcessAudio(samples, sampleRate, channels); }
                    catch (Exception ex) { Log($"[AudioPlugin] {ex.Message}", LogLevel.Error); }
        }

        // ── Lyrics chain ──────────────────────────────────────────────
        /// <summary>Try each lyrics plugin in priority order; return first non-null result.</summary>
        public async Task<LyricsData?> TryGetLyricsFromPluginsAsync(string title, string artist,
            System.Threading.CancellationToken ct = default)
        {
            foreach (var plugin in LyricsPlugins)
                if (plugin is IDeadPlugin p && ((PluginInfo?)null)?.IsEnabled != false)
                    try
                    {
                        var result = await plugin.GetLyricsAsync(title, artist, ct);
                        if (result != null) return result;
                    }
                    catch (Exception ex) { Log($"[LyricsPlugin] {ex.Message}", LogLevel.Warning); }
            return null;
        }

        // ── Metadata enrichment ───────────────────────────────────────
        public async Task EnrichSongMetadataAsync(Song song, System.Threading.CancellationToken ct = default)
        {
            foreach (var plugin in MetadataPlugins)
                try { await plugin.EnrichAsync(song, ct); }
                catch (Exception ex) { Log($"[MetadataPlugin] {ex.Message}", LogLevel.Warning); }
        }

        // ── Logging ───────────────────────────────────────────────────
        public ObservableCollection<string> Logs { get; } = new();
        private const int MaxLogs = 500;

        public void Log(string message, LogLevel level = LogLevel.Info)
        {
            var line = $"[{DateTime.Now:HH:mm:ss}] [{level}] {message}";
            Debug.WriteLine(line);
            _dispatcher.Invoke(() =>
            {
                Logs.Add(line);
                if (Logs.Count > MaxLogs) Logs.RemoveAt(0);
            });
        }

        // ── Plugin dev README ─────────────────────────────────────────
        private void WritePluginReadme()
        {
            var path = Path.Combine(PluginsDir, "HOW_TO_CREATE_A_PLUGIN.txt");
            if (File.Exists(path)) return;
            File.WriteAllText(path, @"
╔════════════════════════════════════════════════════════╗
║         DeadFy Plugin Development Guide              ║
╚════════════════════════════════════════════════════════╝

QUICK START
───────────
1. Create a new .NET 8 Class Library project in Visual Studio
2. Reference the SDK — pick one option:
     Option A (recommended): add DeadFy.SDK.dll (in this folder) as an Assembly Reference
     Option B: copy IDeadPlugin.cs (also in this folder) directly into your project
3. Implement IDeadPlugin + one of the extension interfaces
4. Build → copy YourPlugin.dll into this Plugins/ folder
5. DeadFy loads it automatically (hot-reload while running too!)

NOTE: DeadFy.SDK.dll and IDeadPlugin.cs are regenerated here on every build.

PLUGIN TYPES
────────────
IAudioPlugin     — Process raw PCM audio samples (EQ, effects, etc.)
ILyricsPlugin    — Provide synced/plain lyrics from any source
ISearchPlugin    — Add a new Search tab (SoundCloud, Bandcamp, etc.)
IMetadataPlugin  — Enrich song metadata on import (BPM, key, mood, art)

MINIMAL EXAMPLE
───────────────
[DeadPlugin(""My Plugin"", ""1.0.0"", ""YourName"", ""Does something cool"")]
public class MyPlugin : IDeadPlugin
{
    private IPluginHost _host = null!;

    public void Initialize(IPluginHost host)
    {
        _host = host;
        host.SongChanged += (_, song) =>
        {
            if (song != null)
                host.ShowNotification($""Now playing: {song.Title}"");
        };
    }

    public void Shutdown() { }
    public void Dispose()  { }
}

LYRICS PLUGIN EXAMPLE
─────────────────────
[DeadPlugin(""My Lyrics Source"", ""1.0.0"", ""YourName"", ""Fetches lyrics from MySite"")]
public class MyLyricsPlugin : ILyricsPlugin
{
    public string ProviderName => ""MySite"";
    public int    Priority     => 1;  // lower = tried before built-in LRCLIB

    public void Initialize(IPluginHost host) { }
    public void Shutdown() { }
    public void Dispose()  { }

    public async Task<LyricsData?> GetLyricsAsync(string title, string artist, CancellationToken ct)
    {
        // fetch from your source...
        return new LyricsData
        {
            SyncedLines = new List<LyricLineData>
            {
                new() { Time = TimeSpan.FromSeconds(10), Text = ""Hello world"" },
                // ...
            }
        };
    }
}

NOTES
─────
• DLLs are loaded in isolated AssemblyLoadContexts — crashes won't take down the app
• Hot-reload: replace the DLL while DeadFy is running and it reloads automatically
• Use host.Log() to write to the Plugin Console in the Plugin Manager
• Use host.ShowNotification() for toast messages in the player UI
• Use host.RegisterSettingsPanel() to add a config UI in Settings → Plugins
");
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? n = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
    }

    // ══════════════════════════════════════════════════════════════════
    //  ISOLATED ASSEMBLY LOAD CONTEXT
    //  Each plugin gets its own context so it can be unloaded cleanly
    // ══════════════════════════════════════════════════════════════════
    internal class PluginLoadContext : AssemblyLoadContext
    {
        private readonly AssemblyDependencyResolver _resolver;

        public PluginLoadContext(string pluginPath) : base(isCollectible: true)
        {
            _resolver = new AssemblyDependencyResolver(pluginPath);
        }

        protected override Assembly? Load(AssemblyName assemblyName)
        {
            // Let the plugin load its own deps; fall back to host app for shared types
            var path = _resolver.ResolveAssemblyToPath(assemblyName);
            if (path != null) return LoadFromAssemblyPath(path);

            // Don't re-load assemblies already in the host — share them
            return null;
        }

        protected override IntPtr LoadUnmanagedDll(string unmanagedDllName)
        {
            var path = _resolver.ResolveUnmanagedDllToPath(unmanagedDllName);
            return path != null ? LoadUnmanagedDllFromPath(path) : IntPtr.Zero;
        }
    }
}
