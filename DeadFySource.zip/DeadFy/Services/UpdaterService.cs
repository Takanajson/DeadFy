// ============================================================
//  UpdaterService.cs  —  DeadFy
// ============================================================

using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace DeadFy.Services
{
    public sealed class UpdaterService
    {
        private static UpdaterService? _instance;
        public static UpdaterService Instance => _instance ??= new UpdaterService();

        // ── CONFIGURE THIS ────────────────────────────────────────────────────
        private const string VersionJsonUrl =
            "https://github.com/Takanajson/DeadFy/raw/refs/heads/main/version.json";
        // ─────────────────────────────────────────────────────────────────────

        private const string LocalVersionFile = "version.txt";
        private const string TempZipName = "DeadFy_update.zip";

        private static readonly Logger Log = Logger.Instance;

        // ── Entry point ───────────────────────────────────────────────────────
        public void CheckAndApplyOnStartup()
        {
            // Spin up a completely fresh thread with NO synchronization context.
            // This avoids every possible async deadlock.
            var done = new ManualResetEventSlim(false);

            var thread = new Thread(() =>
            {
                // Clear any inherited sync context
                SynchronizationContext.SetSynchronizationContext(null);
                try
                {
                    RunUpdateAsync().GetAwaiter().GetResult();
                }
                catch (Exception ex)
                {
                    Log.Error("[Updater] Unexpected error", ex);
                }
                finally
                {
                    done.Set();
                }
            });
            thread.IsBackground = true;
            thread.Start();

            // Block startup until the update check is fully done
            done.Wait();
        }

        // ── Core ──────────────────────────────────────────────────────────────
        private static async Task RunUpdateAsync()
        {
            Log.Info($"[Updater] Checking — local: {ReadLocalVersion()}");

            // 1. Fetch version.json
            RemoteVersionInfo? remote = await FetchVersionJsonAsync();
            if (remote == null)
            {
                Log.Info("[Updater] Server unreachable — opening normally");
                return;
            }

            Log.Info($"[Updater] Remote: {remote.Version}  Local: {ReadLocalVersion()}");

            // 2. Compare
            if (!IsNewer(remote.Version, ReadLocalVersion()))
            {
                Log.Info("[Updater] Already up to date");
                return;
            }

            Log.Info($"[Updater] Update {remote.Version} found — downloading…");

            // 3. Show "Please wait" on its own STA thread
            Window? waitWin = null;
            var winReady = new ManualResetEventSlim(false);

            var uiThread = new Thread(() =>
            {
                waitWin = new Window
                {
                    Title = "DeadFy",
                    Width = 340,
                    Height = 110,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen,
                    ResizeMode = ResizeMode.NoResize,
                    WindowStyle = WindowStyle.ToolWindow,
                    Topmost = true,
                    ShowInTaskbar = true,
                    Content = new TextBlock
                    {
                        Text = $"Updating DeadFy to v{remote.Version}, please wait…",
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment = VerticalAlignment.Center,
                        FontSize = 13,
                        TextWrapping = TextWrapping.Wrap,
                        Margin = new Thickness(20)
                    }
                };
                waitWin.Loaded += (_, _) => winReady.Set();
                waitWin.Show();
                System.Windows.Threading.Dispatcher.Run();
            });
            uiThread.SetApartmentState(ApartmentState.STA);
            uiThread.IsBackground = true;
            uiThread.Start();

            winReady.Wait(2000); // wait until window is actually visible

            // 4. Download
            string zipPath = Path.Combine(Path.GetTempPath(), TempZipName);
            try
            {
                await DownloadAsync(remote.DownloadUrl, zipPath);
                Log.Info("[Updater] Download complete");
            }
            catch (Exception ex)
            {
                Log.Error("[Updater] Download failed", ex);
                CloseWaitWindow(waitWin);
                return;
            }

            // 5. Extract to a temp staging folder (app is still running — can't overwrite live files yet)
            string stagingDir = Path.Combine(Path.GetTempPath(), "DeadFy_staging");
            try
            {
                if (Directory.Exists(stagingDir)) Directory.Delete(stagingDir, true);
                Directory.CreateDirectory(stagingDir);
                ExtractZip(zipPath, stagingDir);
                Log.Info("[Updater] Extraction complete");
            }
            catch (Exception ex)
            {
                Log.Error("[Updater] Extraction failed", ex);
                CloseWaitWindow(waitWin);
                try { File.Delete(zipPath); } catch { }
                return;
            }

            // 6. Cleanup zip
            try { File.Delete(zipPath); } catch { }

            CloseWaitWindow(waitWin);

            Log.Info("[Updater] Done — handing off to batch updater and exiting");
            RelaunchAndExit(stagingDir, remote.Version);
        }

        // ── Helpers ───────────────────────────────────────────────────────────
        private static void CloseWaitWindow(Window? win)
        {
            try { win?.Dispatcher.Invoke(() => win.Close()); } catch { }
        }

        private static async Task<RemoteVersionInfo?> FetchVersionJsonAsync()
        {
            try
            {
                using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
                http.DefaultRequestHeaders.UserAgent
                    .Add(new ProductInfoHeaderValue("DeadFy-Updater", "1.0"));

                string json = await http.GetStringAsync(VersionJsonUrl);
                Log.Info($"[Updater] version.json: {json}");

                return JsonSerializer.Deserialize<RemoteVersionInfo>(json,
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            }
            catch (Exception ex)
            {
                Log.Warning($"[Updater] FetchVersionJson failed: {ex.Message}");
                return null;
            }
        }

        private static async Task DownloadAsync(string url, string destPath)
        {
            using var http = new HttpClient { Timeout = TimeSpan.FromMinutes(10) };
            http.DefaultRequestHeaders.UserAgent
                .Add(new ProductInfoHeaderValue("DeadFy-Updater", "1.0"));

            using var response = await http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
            response.EnsureSuccessStatusCode();
            await using var src = await response.Content.ReadAsStreamAsync();
            await using var dest = new FileStream(destPath, FileMode.Create, FileAccess.Write,
                                                  FileShare.None, 81920, useAsync: true);
            await src.CopyToAsync(dest);
        }

        private static void ExtractZip(string zipPath, string targetDir)
        {
            using var archive = ZipFile.OpenRead(zipPath);
            foreach (var entry in archive.Entries)
            {
                if (string.IsNullOrEmpty(entry.Name)) continue;
                string destFile = Path.GetFullPath(Path.Combine(targetDir, entry.FullName));
                if (!destFile.StartsWith(targetDir, StringComparison.OrdinalIgnoreCase)) continue;
                string? dir = Path.GetDirectoryName(destFile);
                if (dir != null) Directory.CreateDirectory(dir);
                entry.ExtractToFile(destFile, overwrite: true);
            }
        }

        private static void RelaunchAndExit(string stagingDir, string newVersion)
        {
            string appDir = AppDir;
            string exe = Path.Combine(appDir, "DeadFy.exe");
            string verFile = Path.Combine(appDir, LocalVersionFile);
            int pid = Process.GetCurrentProcess().Id;

            // Write a batch script that:
            //   1. Waits for this process to exit
            //   2. Copies staged files over the live install
            //   3. Writes the new version.txt
            //   4. Relaunches DeadFy.exe
            string batPath = Path.Combine(Path.GetTempPath(), "DeadFy_update.bat");
            // Build batch content without interpolated verbatim string to avoid compiler confusion
            // with braces, quotes, and percent signs all meaning different things.
            string batContent =
                "@echo off" + "\r\n" +
                ":waitloop" + "\r\n" +
                $"tasklist /FI \"PID eq {pid}\" 2>NUL | find \"{pid}\" >NUL" + "\r\n" +
                "if not errorlevel 1 (" + "\r\n" +
                "    timeout /t 1 /nobreak >NUL" + "\r\n" +
                "    goto waitloop" + "\r\n" +
                ")" + "\r\n" +
                $"xcopy /E /Y /I \"{stagingDir}\" \"{appDir}\"" + "\r\n" +
                $"echo {newVersion}>\"{verFile}\"" + "\r\n" +
                $"start \"\" \"{exe}\"" + "\r\n" +
                "del \"%~f0\"" + "\r\n";
            File.WriteAllText(batPath, batContent);

            Process.Start(new ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = $"/C \"{batPath}\"",
                UseShellExecute = false,
                CreateNoWindow = true
            });

            Environment.Exit(0);
        }

        private static string ReadLocalVersion()
        {
            string path = Path.Combine(AppDir, LocalVersionFile);
            return File.Exists(path) ? File.ReadAllText(path).Trim() : "0.0.0";
        }

        private static bool IsNewer(string remote, string local) =>
            Version.TryParse(remote, out var r) &&
            Version.TryParse(local, out var l) &&
            r > l;

        private static string AppDir =>
            Path.GetDirectoryName(Process.GetCurrentProcess().MainModule?.FileName
                                  ?? AppDomain.CurrentDomain.BaseDirectory)
            ?? AppDomain.CurrentDomain.BaseDirectory;
    }

    internal sealed class RemoteVersionInfo
    {
        public string Version { get; set; } = "0.0.0";

        [JsonPropertyName("download_url")]
        public string DownloadUrl { get; set; } = string.Empty;
    }
}