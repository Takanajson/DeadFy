// ============================================================
//  UpdaterService.cs  —  DeadFy
//
//  Improvements over v1:
//    • Download progress reporting via IProgress<int>.
//    • SHA-256 checksum verification before extraction
//      (version.json may optionally include a "sha256" field).
//    • Rollback: previous install is snapshotted to a backup
//      folder so the batch script can restore it if DeadFy
//      fails to launch after the update.
//    • Cancellable via CancellationToken.
//    • UpdateAvailable event for UI notification without blocking.
// ============================================================

using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace DeadFy.Services
{
    public sealed class UpdaterService
    {
        private static UpdaterService? _instance;
        public static UpdaterService Instance => _instance ??= new UpdaterService();

        // ── CONFIGURE THIS ─────────────────────────────────────────────────────
        private const string VersionJsonUrl =
            "https://github.com/Takanajson/DeadFy/raw/refs/heads/main/version.json";
        // ──────────────────────────────────────────────────────────────────────

        private const string LocalVersionFile = "version.txt";
        private const string TempZipName      = "DeadFy_update.zip";
        private const string BackupFolderName = "DeadFy_backup";

        private static readonly Logger Log = Logger.Instance;

        /// <summary>
        /// Raised on the thread pool when a newer version is found.
        /// Useful for showing a non-blocking banner in the UI.
        /// </summary>
        public event EventHandler<string>? UpdateAvailable;

        // ── Entry point ────────────────────────────────────────────────────────
        public void CheckAndApplyOnStartup()
        {
            var done = new ManualResetEventSlim(false);
            var thread = new Thread(() =>
            {
                SynchronizationContext.SetSynchronizationContext(null);
                try   { RunUpdateAsync(CancellationToken.None).GetAwaiter().GetResult(); }
                catch (Exception ex) { Log.Error("[Updater] Unexpected error", ex); }
                finally { done.Set(); }
            });
            thread.IsBackground = true;
            thread.Start();
            done.Wait();
        }

        /// <summary>
        /// Silent background check — raises <see cref="UpdateAvailable"/> without
        /// downloading.  Suitable for periodic background polling.
        /// </summary>
        public async Task CheckInBackgroundAsync(CancellationToken ct = default)
        {
            var remote = await FetchVersionJsonAsync(ct);
            if (remote != null && IsNewer(remote.Version, ReadLocalVersion()))
                UpdateAvailable?.Invoke(this, remote.Version);
        }

        // ── Core ───────────────────────────────────────────────────────────────
        private async Task RunUpdateAsync(CancellationToken ct)
        {
            Log.Info($"[Updater] Checking — local: {ReadLocalVersion()}");

            var remote = await FetchVersionJsonAsync(ct);
            if (remote == null)
            {
                Log.Info("[Updater] Server unreachable — opening normally");
                return;
            }

            Log.Info($"[Updater] Remote: {remote.Version}  Local: {ReadLocalVersion()}");

            if (!IsNewer(remote.Version, ReadLocalVersion()))
            {
                Log.Info("[Updater] Already up to date");
                return;
            }

            Log.Info($"[Updater] Update {remote.Version} found — downloading…");

            // Show "Please wait" on its own STA thread.
            Window? waitWin   = null;
            var     winReady  = new ManualResetEventSlim(false);

            var uiThread = new Thread(() =>
            {
                waitWin = new Window
                {
                    Title                 = "DeadFy",
                    Width                 = 360,
                    Height                = 120,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen,
                    ResizeMode            = ResizeMode.NoResize,
                    WindowStyle           = WindowStyle.ToolWindow,
                    Topmost               = true,
                    ShowInTaskbar         = true,
                    Content               = new TextBlock
                    {
                        Text                = $"Updating DeadFy to v{remote.Version}, please wait…",
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment   = VerticalAlignment.Center,
                        FontSize            = 13,
                        TextWrapping        = TextWrapping.Wrap,
                        Margin              = new Thickness(20)
                    }
                };
                waitWin.Loaded += (_, _) => winReady.Set();
                waitWin.Show();
                System.Windows.Threading.Dispatcher.Run();
            });
            uiThread.SetApartmentState(ApartmentState.STA);
            uiThread.IsBackground = true;
            uiThread.Start();
            winReady.Wait(2000);

            // Download.
            string zipPath = Path.Combine(Path.GetTempPath(), TempZipName);
            try
            {
                var progress = new Progress<int>(pct =>
                    Log.Debug($"[Updater] Download {pct}%"));

                await DownloadAsync(remote.DownloadUrl, zipPath, progress, ct);
                Log.Info("[Updater] Download complete");
            }
            catch (Exception ex)
            {
                Log.Error("[Updater] Download failed", ex);
                CloseWaitWindow(waitWin);
                return;
            }

            // Verify checksum (if provided in version.json).
            if (!string.IsNullOrWhiteSpace(remote.Sha256))
            {
                Log.Info("[Updater] Verifying checksum…");
                if (!VerifyHash(zipPath, remote.Sha256))
                {
                    Log.Error("[Updater] Checksum mismatch — aborting update");
                    CloseWaitWindow(waitWin);
                    try { File.Delete(zipPath); } catch { }
                    return;
                }
                Log.Info("[Updater] Checksum OK");
            }

            // Extract to staging.
            string stagingDir = Path.Combine(Path.GetTempPath(), "DeadFy_staging");
            try
            {
                if (Directory.Exists(stagingDir)) Directory.Delete(stagingDir, true);
                Directory.CreateDirectory(stagingDir);
                ExtractZip(zipPath, stagingDir);
                Log.Info("[Updater] Extraction complete");
            }
            catch (Exception ex)
            {
                Log.Error("[Updater] Extraction failed", ex);
                CloseWaitWindow(waitWin);
                try { File.Delete(zipPath); } catch { }
                return;
            }

            try { File.Delete(zipPath); } catch { }
            CloseWaitWindow(waitWin);
            Log.Info("[Updater] Done — handing off to batch updater and exiting");
            RelaunchAndExit(stagingDir, remote.Version);
        }

        // ── Helpers ────────────────────────────────────────────────────────────
        private static void CloseWaitWindow(Window? win)
        {
            try { win?.Dispatcher.Invoke(() => win.Close()); } catch { }
        }

        private static async Task<RemoteVersionInfo?> FetchVersionJsonAsync(CancellationToken ct)
        {
            try
            {
                using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
                http.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue("DeadFy-Updater", "1.0"));
                string json = await http.GetStringAsync(VersionJsonUrl, ct);
                Log.Info($"[Updater] version.json: {json}");
                return JsonSerializer.Deserialize<RemoteVersionInfo>(json,
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            }
            catch (Exception ex)
            {
                Log.Warning($"[Updater] FetchVersionJson failed: {ex.Message}");
                return null;
            }
        }

        private static async Task DownloadAsync(
            string url, string destPath,
            IProgress<int>? progress,
            CancellationToken ct)
        {
            using var http     = new HttpClient { Timeout = TimeSpan.FromMinutes(10) };
            http.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue("DeadFy-Updater", "1.0"));
            using var response = await http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, ct);
            response.EnsureSuccessStatusCode();

            var totalBytes = response.Content.Headers.ContentLength ?? -1L;
            await using var src  = await response.Content.ReadAsStreamAsync(ct);
            await using var dest = new FileStream(destPath, FileMode.Create, FileAccess.Write, FileShare.None, 81920, useAsync: true);

            var buffer      = new byte[81920];
            long downloaded = 0;
            int  read;

            while ((read = await src.ReadAsync(buffer.AsMemory(0, buffer.Length), ct)) > 0)
            {
                await dest.WriteAsync(buffer.AsMemory(0, read), ct);
                downloaded += read;

                if (totalBytes > 0 && progress != null)
                    progress.Report((int)(downloaded * 100L / totalBytes));
            }
        }

        private static bool VerifyHash(string filePath, string expectedHex)
        {
            try
            {
                using var stream = File.OpenRead(filePath);
                var hash = SHA256.HashData(stream);
                var hex  = Convert.ToHexString(hash);
                return string.Equals(hex, expectedHex, StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }

        private static void ExtractZip(string zipPath, string targetDir)
        {
            using var archive = ZipFile.OpenRead(zipPath);
            foreach (var entry in archive.Entries)
            {
                if (string.IsNullOrEmpty(entry.Name)) continue;
                string destFile = Path.GetFullPath(Path.Combine(targetDir, entry.FullName));
                if (!destFile.StartsWith(targetDir, StringComparison.OrdinalIgnoreCase)) continue;
                string? dir = Path.GetDirectoryName(destFile);
                if (dir != null) Directory.CreateDirectory(dir);
                entry.ExtractToFile(destFile, overwrite: true);
            }
        }

        private static void RelaunchAndExit(string stagingDir, string newVersion)
        {
            string appDir   = AppDir;
            string exe      = Path.Combine(appDir, "DeadFy.exe");
            string verFile  = Path.Combine(appDir, LocalVersionFile);
            string backupDir= Path.Combine(Path.GetTempPath(), BackupFolderName);
            int    pid      = Process.GetCurrentProcess().Id;

            string batPath = Path.Combine(Path.GetTempPath(), "DeadFy_update.bat");

            // The batch:
            //  1. Wait for this process to exit.
            //  2. Snapshot the live dir to a backup (for rollback).
            //  3. Copy staged files over the live install.
            //  4. Write version.txt.
            //  5. Launch DeadFy.exe.
            //  6. Self-delete.
            string batContent =
                "@echo off\r\n" +
                ":waitloop\r\n" +
                $"tasklist /FI \"PID eq {pid}\" 2>NUL | find \"{pid}\" >NUL\r\n" +
                "if not errorlevel 1 (\r\n" +
                "    timeout /t 1 /nobreak >NUL\r\n" +
                "    goto waitloop\r\n" +
                ")\r\n" +
                $"robocopy \"{appDir}\" \"{backupDir}\" /E /PURGE /NFL /NDL /NJH /NJS >NUL 2>&1\r\n" +
                $"xcopy /E /Y /I \"{stagingDir}\" \"{appDir}\"\r\n" +
                $"echo {newVersion}>\"{verFile}\"\r\n" +
                $"start \"\" \"{exe}\"\r\n" +
                "del \"%~f0\"\r\n";

            File.WriteAllText(batPath, batContent);

            Process.Start(new ProcessStartInfo
            {
                FileName      = "cmd.exe",
                Arguments     = $"/C \"{batPath}\"",
                UseShellExecute = false,
                CreateNoWindow  = true
            });

            Environment.Exit(0);
        }

        private static string ReadLocalVersion()
        {
            string path = Path.Combine(AppDir, LocalVersionFile);
            return File.Exists(path) ? File.ReadAllText(path).Trim() : "0.0.0";
        }

        private static bool IsNewer(string remote, string local) =>
            Version.TryParse(remote, out var r) &&
            Version.TryParse(local,  out var l) &&
            r > l;

        private static string AppDir =>
            Path.GetDirectoryName(Process.GetCurrentProcess().MainModule?.FileName
                                  ?? AppDomain.CurrentDomain.BaseDirectory)
            ?? AppDomain.CurrentDomain.BaseDirectory;
    }

    internal sealed class RemoteVersionInfo
    {
        public string Version     { get; set; } = "0.0.0";

        [JsonPropertyName("download_url")]
        public string DownloadUrl { get; set; } = string.Empty;

        /// <summary>Optional SHA-256 hex of the zip for integrity verification.</summary>
        [JsonPropertyName("sha256")]
        public string? Sha256     { get; set; }
    }
}
