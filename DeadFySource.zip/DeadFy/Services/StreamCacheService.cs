using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace DeadFy.Services
{
    /// <summary>
    /// Resolves a YouTube video URL to a direct audio CDN URL via yt-dlp --get-url.
    /// That URL is fed straight to NAudio's MediaFoundationReader so playback starts
    /// in ~1 second without downloading the whole file.
    ///
    /// Falls back to a full disk-cached download when live resolution fails.
    /// </summary>
    public class StreamCacheService
    {
        private static StreamCacheService? _instance;
        public  static StreamCacheService Instance => _instance ??= new StreamCacheService();

        // ── Paths ─────────────────────────────────────────────────────────────
        private static string AppDataDir  => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "DeadFy");
        private static string YtDlpExe   => Path.Combine(AppDataDir, "yt-dlp.exe");
        public  static string CacheDir   => Path.Combine(Path.GetTempPath(), "DeadFy_stream");

        // ── In-memory URL cache (YouTube CDN URLs expire in ~6 h) ────────────
        private readonly Dictionary<string, (string Url, DateTime Expiry)> _urlCache = new();
        private static readonly TimeSpan UrlCacheTtl = TimeSpan.FromHours(5.5);

        // ── Concurrency ───────────────────────────────────────────────────────
        // Cap at 3 simultaneous yt-dlp processes to avoid rate-limiting.
        private readonly SemaphoreSlim _resolveLock = new(3, 3);

        // Track files written this session so ClearSessionCache knows what to remove.
        private readonly HashSet<string> _sessionFiles = new();

        private StreamCacheService()
        {
            Directory.CreateDirectory(CacheDir);
        }

        // ── PRIMARY: Resolve live CDN URL (~0.5–1 s) ─────────────────────────

        /// <summary>
        /// Returns a direct HTTP audio URL for the given YouTube video.
        /// Returns null on failure — caller should fall back to <see cref="GetStreamAsync"/>.
        /// </summary>
        public async Task<string?> ResolveStreamUrlAsync(
            string videoId,
            string videoUrl,
            Action<string>? onStatus = null,
            CancellationToken ct = default)
        {
            // 1. In-memory URL cache
            lock (_urlCache)
            {
                if (_urlCache.TryGetValue(videoId, out var cached) && DateTime.UtcNow < cached.Expiry)
                    return cached.Url;
            }

            // 2. Disk cache (previously fully downloaded)
            var diskPath = FindCachedFile(videoId);
            if (diskPath != null) return diskPath;

            // 3. Resolve with yt-dlp (serialised to MaxConcurrent)
            await _resolveLock.WaitAsync(ct).ConfigureAwait(false);
            try
            {
                // Double-check inside the lock in case another thread already resolved it
                lock (_urlCache)
                {
                    if (_urlCache.TryGetValue(videoId, out var cached2) && DateTime.UtcNow < cached2.Expiry)
                        return cached2.Url;
                }

                await YouTubeService.EnsureYtDlpAsync(onStatus, ct).ConfigureAwait(false);

                var psi = BuildProcessInfo(YtDlpExe);
                psi.ArgumentList.Add(videoUrl);
                psi.ArgumentList.Add("--format");          psi.ArgumentList.Add("bestaudio[ext=m4a]/bestaudio[ext=webm]/bestaudio");
                psi.ArgumentList.Add("--get-url");
                psi.ArgumentList.Add("--no-playlist");
                psi.ArgumentList.Add("--no-warnings");
                psi.ArgumentList.Add("--socket-timeout"); psi.ArgumentList.Add("10");

                var outputLines = new List<string>();
                using var proc = new Process { StartInfo = psi };
                proc.OutputDataReceived += (_, e) => { if (e.Data != null) outputLines.Add(e.Data.Trim()); };
                proc.ErrorDataReceived  += (_, e) => { if (e.Data != null) Logger.Instance.Debug($"[yt-dlp URL err] {e.Data}"); };

                proc.Start();
                proc.BeginOutputReadLine();
                proc.BeginErrorReadLine();
                await proc.WaitForExitAsync(ct).ConfigureAwait(false);

                string? directUrl = null;
                foreach (var line in outputLines)
                {
                    if (line.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
                    { directUrl = line; break; }
                }

                if (directUrl == null)
                {
                    Logger.Instance.Warning($"StreamCache: no URL for videoId={videoId} (exit {proc.ExitCode})");
                    return null;
                }

                lock (_urlCache)
                    _urlCache[videoId] = (directUrl, DateTime.UtcNow.Add(UrlCacheTtl));

                Logger.Instance.Debug($"StreamCache: resolved URL for {videoId}");
                return directUrl;
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                Logger.Instance.Error($"StreamCache.ResolveStreamUrlAsync failed for {videoId}", ex);
                return null;
            }
            finally
            {
                _resolveLock.Release();
            }
        }

        // ── FALLBACK: Full download to disk ───────────────────────────────────

        public async Task<string?> GetStreamAsync(
            string videoId,
            string videoUrl,
            Action<double>? onProgress = null,
            CancellationToken ct = default)
        {
            var cached = FindCachedFile(videoId);
            if (cached != null) { onProgress?.Invoke(1.0); return cached; }

            await _resolveLock.WaitAsync(ct).ConfigureAwait(false);
            try
            {
                cached = FindCachedFile(videoId);
                if (cached != null) { onProgress?.Invoke(1.0); return cached; }

                await YouTubeService.EnsureYtDlpAsync(null, ct).ConfigureAwait(false);

                var outTemplate = Path.Combine(CacheDir, $"{videoId}.%(ext)s");
                var psi = BuildProcessInfo(YtDlpExe);
                psi.ArgumentList.Add(videoUrl);
                psi.ArgumentList.Add("--format");               psi.ArgumentList.Add("bestaudio[ext=m4a]/bestaudio[ext=webm]/bestaudio");
                psi.ArgumentList.Add("-o");                      psi.ArgumentList.Add(outTemplate);
                psi.ArgumentList.Add("--no-playlist");
                psi.ArgumentList.Add("--newline");
                psi.ArgumentList.Add("--no-part");
                psi.ArgumentList.Add("--no-write-info-json");
                psi.ArgumentList.Add("--no-warnings");
                psi.ArgumentList.Add("--no-mtime");
                psi.ArgumentList.Add("--concurrent-fragments"); psi.ArgumentList.Add("8");
                psi.ArgumentList.Add("--buffer-size");          psi.ArgumentList.Add("16K");
                psi.ArgumentList.Add("--retries");              psi.ArgumentList.Add("3");
                psi.ArgumentList.Add("--socket-timeout");       psi.ArgumentList.Add("10");

                using var proc = new Process { StartInfo = psi };
                proc.OutputDataReceived += (_, e) =>
                {
                    if (e.Data == null) return;
                    if (e.Data.Contains("[download]") && e.Data.Contains('%'))
                    {
                        var before = e.Data.Split('%')[0];
                        var parts  = before.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length > 0 &&
                            double.TryParse(parts[^1],
                                System.Globalization.NumberStyles.Float,
                                System.Globalization.CultureInfo.InvariantCulture,
                                out var pct))
                            onProgress?.Invoke(Math.Clamp(pct / 100.0, 0.02, 0.98));
                    }
                };
                proc.ErrorDataReceived += (_, e) =>
                {
                    if (e.Data != null) Logger.Instance.Debug($"[yt-dlp DL err] {e.Data}");
                };

                proc.Start();
                proc.BeginOutputReadLine();
                proc.BeginErrorReadLine();
                await proc.WaitForExitAsync(ct).ConfigureAwait(false);

                if (proc.ExitCode != 0)
                    throw new Exception($"yt-dlp exited with code {proc.ExitCode}");

                var finalPath = FindCachedFile(videoId)
                    ?? throw new FileNotFoundException($"yt-dlp output not found for {videoId}");

                lock (_sessionFiles) _sessionFiles.Add(finalPath);
                onProgress?.Invoke(1.0);
                Logger.Instance.Info($"StreamCache: downloaded {videoId} → {Path.GetFileName(finalPath)}");
                return finalPath;
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                Logger.Instance.Error($"StreamCache.GetStreamAsync failed for {videoId}", ex);
                throw;
            }
            finally
            {
                _resolveLock.Release();
            }
        }

        // ── Cache management ──────────────────────────────────────────────────

        public void InvalidateUrlCache(string videoId)
        {
            lock (_urlCache) _urlCache.Remove(videoId);
            Logger.Instance.Debug($"StreamCache: invalidated URL cache for {videoId}");
        }

        /// <summary>Delete only files written during this session.</summary>
        public void ClearSessionCache()
        {
            lock (_sessionFiles)
            {
                foreach (var f in _sessionFiles)
                    TryDelete(f);
                _sessionFiles.Clear();
            }
        }

        /// <summary>Delete all disk-cached files and clear the URL cache.</summary>
        public void ClearAllCache()
        {
            try
            {
                foreach (var f in Directory.GetFiles(CacheDir))
                    TryDelete(f);
            }
            catch { }

            lock (_sessionFiles) _sessionFiles.Clear();
            lock (_urlCache)     _urlCache.Clear();
            Logger.Instance.Info("StreamCache: all cache cleared");
        }

        public long GetCacheSizeBytes()
        {
            long total = 0;
            try
            {
                foreach (var f in Directory.GetFiles(CacheDir))
                {
                    try { total += new FileInfo(f).Length; } catch { }
                }
            }
            catch { }
            return total;
        }

        /// <summary>Human-readable cache size, e.g. "42.3 MB".</summary>
        public string GetCacheSizeText()
        {
            double mb = GetCacheSizeBytes() / (1024.0 * 1024.0);
            return mb >= 1024
                ? $"{mb / 1024.0:F1} GB"
                : $"{mb:F1} MB";
        }

        // ── Helpers ───────────────────────────────────────────────────────────

        private static string? FindCachedFile(string videoId)
        {
            try
            {
                foreach (var f in Directory.GetFiles(CacheDir))
                    if (Path.GetFileNameWithoutExtension(f) == videoId) return f;
            }
            catch { }
            return null;
        }

        private static ProcessStartInfo BuildProcessInfo(string exe) => new()
        {
            FileName               = exe,
            UseShellExecute        = false,
            RedirectStandardOutput = true,
            RedirectStandardError  = true,
            CreateNoWindow         = true
        };

        private static void TryDelete(string path)
        {
            try { if (File.Exists(path)) File.Delete(path); } catch { }
        }
    }
}
