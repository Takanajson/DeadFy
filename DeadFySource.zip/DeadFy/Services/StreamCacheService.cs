using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace DeadFy.Services
{
    /// <summary>
    /// Resolves a YouTube video URL to a direct audio CDN URL via yt-dlp --get-url.
    /// Improvements over v1:
    ///   • Cache size enforcement — trims oldest files when MaxCacheMb is exceeded.
    ///   • PreResolveAsync — call with the *next* song so the URL is warm before playback.
    ///   • GetCacheEntries — returns metadata for a Settings "Clear cache" panel.
    ///   • Cleanup runs on a background task, never on the UI thread.
    /// </summary>
    public class StreamCacheService
    {
        private static StreamCacheService? _instance;
        public  static StreamCacheService Instance => _instance ??= new StreamCacheService();

        private static string AppDataDir => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "DeadFy");
        private static string YtDlpExe  => Path.Combine(AppDataDir, "yt-dlp.exe");
        public  static string CacheDir  => Path.Combine(Path.GetTempPath(), "DeadFy_stream");

        // ── In-memory URL cache (CDN URLs expire in ~6 h) ─────────────────────
        private readonly Dictionary<string, (string Url, DateTime Expiry)> _urlCache = new();
        private static readonly TimeSpan UrlCacheTtl = TimeSpan.FromHours(5.5);

        // Cap simultaneous yt-dlp processes.
        private readonly SemaphoreSlim _resolveLock = new(3, 3);

        // Track files written this session.
        private readonly HashSet<string> _sessionFiles = new();

        private StreamCacheService()
        {
            Directory.CreateDirectory(CacheDir);
        }

        // ── Pre-resolve for next track ─────────────────────────────────────────

        /// <summary>
        /// Quietly resolves the CDN URL for the next song in the background so it's
        /// already cached when playback is requested. Fire-and-forget.
        /// </summary>
        public void PreResolve(string videoId, string videoUrl)
        {
            lock (_urlCache)
            {
                if (_urlCache.TryGetValue(videoId, out var c) && DateTime.UtcNow < c.Expiry)
                    return; // Already warm.
            }

            _ = Task.Run(async () =>
            {
                try
                {
                    await ResolveStreamUrlAsync(videoId, videoUrl,
                        onStatus: null, ct: CancellationToken.None)
                        .ConfigureAwait(false);
                    Logger.Instance.Debug($"StreamCache: pre-resolved {videoId}");
                }
                catch { /* non-fatal */ }
            });
        }

        // ── PRIMARY: Resolve live CDN URL ──────────────────────────────────────

        public async Task<string?> ResolveStreamUrlAsync(
            string videoId,
            string videoUrl,
            Action<string>? onStatus = null,
            CancellationToken ct = default)
        {
            lock (_urlCache)
            {
                if (_urlCache.TryGetValue(videoId, out var cached) && DateTime.UtcNow < cached.Expiry)
                    return cached.Url;
            }

            var diskPath = FindCachedFile(videoId);
            if (diskPath != null) return diskPath;

            await _resolveLock.WaitAsync(ct).ConfigureAwait(false);
            try
            {
                lock (_urlCache)
                {
                    if (_urlCache.TryGetValue(videoId, out var cached2) && DateTime.UtcNow < cached2.Expiry)
                        return cached2.Url;
                }

                await YouTubeService.EnsureYtDlpAsync(onStatus, ct).ConfigureAwait(false);

                var psi = BuildProcessInfo(YtDlpExe);
                psi.ArgumentList.Add(videoUrl);
                psi.ArgumentList.Add("--format");         psi.ArgumentList.Add("bestaudio[ext=m4a]/bestaudio[ext=webm]/bestaudio");
                psi.ArgumentList.Add("--get-url");
                psi.ArgumentList.Add("--no-playlist");
                psi.ArgumentList.Add("--no-warnings");
                psi.ArgumentList.Add("--socket-timeout"); psi.ArgumentList.Add("10");

                var outputLines = new List<string>();
                using var proc  = new Process { StartInfo = psi };
                proc.OutputDataReceived += (_, e) => { if (e.Data != null) outputLines.Add(e.Data.Trim()); };
                proc.ErrorDataReceived  += (_, e) => { if (e.Data != null) Logger.Instance.Debug($"[yt-dlp URL err] {e.Data}"); };

                proc.Start();
                proc.BeginOutputReadLine();
                proc.BeginErrorReadLine();
                await proc.WaitForExitAsync(ct).ConfigureAwait(false);

                string? directUrl = outputLines.FirstOrDefault(l =>
                    l.StartsWith("https://", StringComparison.OrdinalIgnoreCase));

                if (directUrl == null)
                {
                    Logger.Instance.Warning($"StreamCache: no URL for videoId={videoId} (exit {proc.ExitCode})");
                    return null;
                }

                lock (_urlCache)
                    _urlCache[videoId] = (directUrl, DateTime.UtcNow.Add(UrlCacheTtl));

                Logger.Instance.Debug($"StreamCache: resolved URL for {videoId}");
                return directUrl;
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                Logger.Instance.Error($"StreamCache.ResolveStreamUrlAsync failed for {videoId}", ex);
                return null;
            }
            finally { _resolveLock.Release(); }
        }

        // ── FALLBACK: Full download to disk ────────────────────────────────────

        public async Task<string?> GetStreamAsync(
            string videoId,
            string videoUrl,
            Action<double>? onProgress = null,
            CancellationToken ct = default)
        {
            var cached = FindCachedFile(videoId);
            if (cached != null) { onProgress?.Invoke(1.0); return cached; }

            await _resolveLock.WaitAsync(ct).ConfigureAwait(false);
            try
            {
                cached = FindCachedFile(videoId);
                if (cached != null) { onProgress?.Invoke(1.0); return cached; }

                await YouTubeService.EnsureYtDlpAsync(null, ct).ConfigureAwait(false);

                // Enforce cache size limit before adding more.
                EnforceCacheLimit();

                var outTemplate = Path.Combine(CacheDir, $"{videoId}.%(ext)s");
                var psi = BuildProcessInfo(YtDlpExe);
                psi.ArgumentList.Add(videoUrl);
                psi.ArgumentList.Add("--format");               psi.ArgumentList.Add("bestaudio[ext=m4a]/bestaudio[ext=webm]/bestaudio");
                psi.ArgumentList.Add("-o");                      psi.ArgumentList.Add(outTemplate);
                psi.ArgumentList.Add("--no-playlist");
                psi.ArgumentList.Add("--newline");
                psi.ArgumentList.Add("--no-part");
                psi.ArgumentList.Add("--no-write-info-json");
                psi.ArgumentList.Add("--no-warnings");
                psi.ArgumentList.Add("--no-mtime");
                psi.ArgumentList.Add("--concurrent-fragments"); psi.ArgumentList.Add("8");
                psi.ArgumentList.Add("--buffer-size");          psi.ArgumentList.Add("16K");
                psi.ArgumentList.Add("--retries");              psi.ArgumentList.Add("3");
                psi.ArgumentList.Add("--socket-timeout");       psi.ArgumentList.Add("10");

                using var proc = new Process { StartInfo = psi };
                proc.OutputDataReceived += (_, e) =>
                {
                    if (e.Data == null) return;
                    if (e.Data.Contains("[download]") && e.Data.Contains('%'))
                    {
                        var before = e.Data.Split('%')[0];
                        var parts  = before.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length > 0 &&
                            double.TryParse(parts[^1],
                                System.Globalization.NumberStyles.Float,
                                System.Globalization.CultureInfo.InvariantCulture,
                                out var pct))
                            onProgress?.Invoke(Math.Clamp(pct / 100.0, 0.02, 0.98));
                    }
                };
                proc.ErrorDataReceived += (_, e) =>
                {
                    if (e.Data != null) Logger.Instance.Debug($"[yt-dlp DL err] {e.Data}");
                };

                proc.Start();
                proc.BeginOutputReadLine();
                proc.BeginErrorReadLine();
                await proc.WaitForExitAsync(ct).ConfigureAwait(false);

                if (proc.ExitCode != 0)
                    throw new Exception($"yt-dlp exited with code {proc.ExitCode}");

                var finalPath = FindCachedFile(videoId)
                    ?? throw new FileNotFoundException($"yt-dlp output not found for {videoId}");

                lock (_sessionFiles) _sessionFiles.Add(finalPath);
                onProgress?.Invoke(1.0);
                Logger.Instance.Info($"StreamCache: downloaded {videoId} → {Path.GetFileName(finalPath)}");
                return finalPath;
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                Logger.Instance.Error($"StreamCache.GetStreamAsync failed for {videoId}", ex);
                throw;
            }
            finally { _resolveLock.Release(); }
        }

        // ── Cache management ───────────────────────────────────────────────────

        public void InvalidateUrlCache(string videoId)
        {
            lock (_urlCache) _urlCache.Remove(videoId);
            Logger.Instance.Debug($"StreamCache: invalidated URL cache for {videoId}");
        }

        public void ClearSessionCache()
        {
            lock (_sessionFiles)
            {
                foreach (var f in _sessionFiles) TryDelete(f);
                _sessionFiles.Clear();
            }
        }

        public void ClearAllCache()
        {
            try
            {
                foreach (var f in Directory.GetFiles(CacheDir)) TryDelete(f);
            }
            catch { }
            lock (_sessionFiles) _sessionFiles.Clear();
            lock (_urlCache)     _urlCache.Clear();
            Logger.Instance.Info("StreamCache: all cache cleared");
        }

        /// <summary>
        /// Trims the oldest cached files until the total is under MaxStreamCacheMb.
        /// Runs synchronously; call from a background thread.
        /// </summary>
        public void EnforceCacheLimit()
        {
            var maxMb = SettingsService.Instance.Settings.MaxStreamCacheMb;
            if (maxMb <= 0) return;

            try
            {
                var files = Directory.GetFiles(CacheDir)
                    .Select(f => new FileInfo(f))
                    .OrderBy(fi => fi.LastAccessTime)
                    .ToList();

                long totalBytes = files.Sum(fi => fi.Length);
                long limitBytes = (long)maxMb * 1024 * 1024;

                foreach (var fi in files)
                {
                    if (totalBytes <= limitBytes) break;
                    try
                    {
                        totalBytes -= fi.Length;
                        fi.Delete();
                        Logger.Instance.Debug($"StreamCache: evicted {fi.Name} (limit enforcement)");
                    }
                    catch { }
                }
            }
            catch (Exception ex) { Logger.Instance.Warning($"StreamCache.EnforceCacheLimit: {ex.Message}"); }
        }

        public long GetCacheSizeBytes()
        {
            long total = 0;
            try
            {
                foreach (var f in Directory.GetFiles(CacheDir))
                    try { total += new FileInfo(f).Length; } catch { }
            }
            catch { }
            return total;
        }

        public string GetCacheSizeText()
        {
            double mb = GetCacheSizeBytes() / (1024.0 * 1024.0);
            return mb >= 1024 ? $"{mb / 1024.0:F1} GB" : $"{mb:F1} MB";
        }

        /// <summary>Returns a list of (FileName, SizeBytes, LastAccess) for the cache panel UI.</summary>
        public List<(string FileName, long SizeBytes, DateTime LastAccess)> GetCacheEntries()
        {
            try
            {
                return Directory.GetFiles(CacheDir)
                    .Select(f => new FileInfo(f))
                    .OrderByDescending(fi => fi.LastAccessTime)
                    .Select(fi => (fi.Name, fi.Length, fi.LastAccessTime))
                    .ToList();
            }
            catch { return new List<(string, long, DateTime)>(); }
        }

        // ── Helpers ────────────────────────────────────────────────────────────

        private static string? FindCachedFile(string videoId)
        {
            try
            {
                return Directory.GetFiles(CacheDir)
                    .FirstOrDefault(f => Path.GetFileNameWithoutExtension(f) == videoId);
            }
            catch { return null; }
        }

        private static ProcessStartInfo BuildProcessInfo(string exe) => new()
        {
            FileName               = exe,
            UseShellExecute        = false,
            RedirectStandardOutput = true,
            RedirectStandardError  = true,
            CreateNoWindow         = true
        };

        private static void TryDelete(string path)
        {
            try { if (File.Exists(path)) File.Delete(path); } catch { }
        }
    }
}
