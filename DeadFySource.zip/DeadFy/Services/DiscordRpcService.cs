// ============================================================
//  DiscordRpcService.cs  —  DeadFy
//
//  Improvements over v1:
//    • Shows elapsed time in the presence so Discord displays
//      how long into the track the user is.
//    • Debounce: rapid successive calls (e.g. seek) wait 800 ms
//      before sending so the pipe isn't spammed.
//    • SetStreamingPresence for YouTube/Spotify songs shows
//      "Streaming" state alongside the track info.
//    • Sanitises presence strings more robustly.
// ============================================================

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Pipes;
using System.Text;
using System.Threading;
using System.Windows.Threading;
using DiscordRPC;
using DiscordRPC.IO;
using DiscordRPC.Logging;
using DeadFy.Models;

namespace DeadFy.Services
{
    internal sealed class ListeningPipeClient : INamedPipeClient
    {
        private readonly ManagedNamedPipeClient _inner = new();

        public bool IsConnected   => _inner.IsConnected;
        public int  ConnectedPipe => _inner.ConnectedPipe;
        public ILogger Logger { get => _inner.Logger; set => _inner.Logger = value; }

        public bool Connect(int pipe) => _inner.Connect(pipe);
        public void Close()   => _inner.Close();
        public void Dispose() => _inner.Dispose();
        public bool ReadFrame(out PipeFrame frame) => _inner.ReadFrame(out frame);

        public bool WriteFrame(PipeFrame frame)
        {
            if (frame.Opcode == Opcode.Frame)
            {
                var json = frame.Message;
                if (json.Contains("\"activity\":{") || json.Contains("\"activity\": {"))
                {
                    json  = InjectActivityType(json);
                    frame = new PipeFrame { Opcode = frame.Opcode, Message = json };
                }
            }
            return _inner.WriteFrame(frame);
        }

        private static string InjectActivityType(string json)
        {
            const string marker  = "\"activity\":{";
            const string marker2 = "\"activity\": {";

            int idx = json.IndexOf(marker, StringComparison.Ordinal);
            if (idx < 0) { idx = json.IndexOf(marker2, StringComparison.Ordinal); if (idx < 0) return json; idx += marker2.Length; }
            else         { idx += marker.Length; }

            var after = json.Substring(idx).TrimStart();
            if (after.StartsWith("\"type\"", StringComparison.Ordinal)) return json;
            return json[..idx] + "\"type\":2," + json[idx..];
        }
    }

    public class DiscordRpcService : IDisposable
    {
        private static DiscordRpcService? _instance;
        public static DiscordRpcService Instance => _instance ??= new DiscordRpcService();

        private static string ClientId =>
            !string.IsNullOrWhiteSpace(ApiConfig.DiscordClientId)
                ? ApiConfig.DiscordClientId
                : "1480733403866337280";

        private DiscordRpcClient? _client;
        private bool _initialized   = false;
        private bool _enabled       = true;
        private Song? _lastSong;
        private bool  _lastWasPlaying = false;

        private DispatcherTimer? _gameWatchTimer;
        private bool _gameIsRunning = false;

        // ── Debounce ───────────────────────────────────────────────────────────
        private DispatcherTimer? _debounceTimer;
        private RichPresence?    _pendingPresence;
        private const int        DebounceMs = 800;

        private static readonly HashSet<string> KnownGameProcesses =
            new(StringComparer.OrdinalIgnoreCase)
        {
            "among us", "among_us", "cs2", "csgo", "valorant",
            "leagueoflegends", "riotclientservices", "fortnite",
            "fortniteclient-win64-shipping", "overwatch", "overwatch2",
            "minecraft", "minecraftlauncher", "javaw", "dota2",
            "r5apex", "gta5", "gtav", "eldenring", "sekiro",
            "cyberpunk2077", "destiny2", "cod", "modernwarfare",
            "rocketleague", "hl2",
        };

        public bool Enabled
        {
            get => _enabled;
            set { _enabled = value; if (!value) ClearPresence(); else RestoreLastPresence(); }
        }

        private DiscordRpcService() { }

        // ── Init ───────────────────────────────────────────────────────────────

        public void EnsureInitialized()
        {
            if (_initialized) return;
            _initialized = true;

            try
            {
                _client = new DiscordRpcClient(
                    ClientId,
                    pipe:       -1,
                    logger:     new NullLogger(),
                    autoEvents: true,
                    client:     new ListeningPipeClient())
                {
                    SkipIdenticalPresence = true
                };

                _client.OnReady           += (_, e) => Debug.WriteLine($"[Discord] Ready — {e.User.Username}");
                _client.OnError           += (_, e) => Debug.WriteLine($"[Discord] Error {e.Code}: {e.Message}");
                _client.OnConnectionFailed+= (_, e) => Debug.WriteLine($"[Discord] Pipe {e.FailedPipe} failed");

                _client.Initialize();

                var warmup = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
                warmup.Tick += (_, _) => { warmup.Stop(); SetIdlePresence(); };
                warmup.Start();

                _gameWatchTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(10) };
                _gameWatchTimer.Tick += (_, _) => CheckForGames();
                _gameWatchTimer.Start();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[Discord] Init error: {ex.GetType().Name}: {ex.Message}");
                _client = null;
            }
        }

        // ── Public API ─────────────────────────────────────────────────────────

        public void UpdatePresence(Song? song)
        {
            if (!_enabled || song == null) return;
            EnsureInitialized();
            if (_client == null || !_client.IsInitialized) return;

            _lastSong       = song;
            _lastWasPlaying = true;
            if (_gameIsRunning) return;

            // Build state string: add streaming badge for online tracks.
            var state = Truncate(song.DisplayArtist, 128);
            if (song.IsStreaming)
                state = "🎵 Streaming · " + state;

            EnqueuePresence(new RichPresence
            {
                Details    = Truncate(song.DisplayTitle, 128),
                State      = state,
                Timestamps = Timestamps.Now,   // shows elapsed time in Discord
                Assets     = new Assets
                {
                    LargeImageKey  = "deadfylogo",
                    LargeImageText = string.IsNullOrWhiteSpace(song.Album) ? "DeadFy" : Truncate(song.Album, 128),
                    SmallImageKey  = "playing",
                    SmallImageText = "Playing"
                }
            });
        }

        public void SetPaused(Song? song)
        {
            if (!_enabled) return;
            EnsureInitialized();
            if (_client == null || !_client.IsInitialized) return;

            _lastSong       = song;
            _lastWasPlaying = false;
            if (_gameIsRunning) return;

            EnqueuePresence(new RichPresence
            {
                Details = song != null ? Truncate(song.DisplayTitle, 128) : "DeadFy",
                State   = song != null ? Truncate(song.DisplayArtist, 128) : "Paused",
                Assets  = new Assets
                {
                    LargeImageKey  = "deadfylogo",
                    LargeImageText = "DeadFy",
                    SmallImageKey  = "paused",
                    SmallImageText = "Paused"
                }
            });
        }

        public void SetIdlePresence()
        {
            if (!_enabled) return;
            EnsureInitialized();
            if (_client?.IsInitialized != true || _gameIsRunning) return;

            EnqueuePresence(new RichPresence
            {
                Details = "DeadFy",
                State   = "Ready to play",
                Assets  = new Assets
                {
                    LargeImageKey  = "deadfylogo",
                    LargeImageText = "DeadFy"
                }
            });
        }

        public void ClearPresence()
        {
            try { _client?.ClearPresence(); }
            catch (Exception ex) { Debug.WriteLine($"[Discord] ClearPresence error: {ex.Message}"); }
        }

        // ── Debounce engine ────────────────────────────────────────────────────

        private void EnqueuePresence(RichPresence presence)
        {
            _pendingPresence = presence;

            if (_debounceTimer == null)
            {
                _debounceTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(DebounceMs) };
                _debounceTimer.Tick += (_, _) =>
                {
                    _debounceTimer.Stop();
                    if (_pendingPresence != null) SendDirect(_pendingPresence);
                    _pendingPresence = null;
                };
            }

            _debounceTimer.Stop();
            _debounceTimer.Start();
        }

        private void SendDirect(RichPresence presence)
        {
            if (_client == null || !_client.IsInitialized) return;
            try
            {
                _client.SetPresence(presence);
                Debug.WriteLine($"[Discord] Sent — {presence.Details} / {presence.State}");
            }
            catch (Exception ex) { Debug.WriteLine($"[Discord] Send error: {ex.Message}"); }
        }

        // ── Game watcher ───────────────────────────────────────────────────────

        private void CheckForGames()
        {
            bool found = false;
            try
            {
                foreach (var proc in Process.GetProcesses())
                    try { if (KnownGameProcesses.Contains(proc.ProcessName)) { found = true; break; } }
                    catch { }
            }
            catch (Exception ex) { Debug.WriteLine($"[Discord] GameWatcher error: {ex.Message}"); }

            if (found && !_gameIsRunning)
            {
                _gameIsRunning = true;
                ClearPresence();
                Debug.WriteLine("[Discord] Game detected — presence cleared.");
            }
            else if (!found && _gameIsRunning)
            {
                _gameIsRunning = false;
                RestoreLastPresence();
                Debug.WriteLine("[Discord] Game closed — presence restored.");
            }
        }

        private void RestoreLastPresence()
        {
            if (!_enabled || _client?.IsInitialized != true) return;
            if (_lastSong != null)
            {
                if (_lastWasPlaying) UpdatePresence(_lastSong);
                else SetPaused(_lastSong);
            }
            else SetIdlePresence();
        }

        private static string Truncate(string s, int max)
            => s.Length <= max ? s : s[..(max - 1)] + "…";

        public void Dispose()
        {
            _debounceTimer?.Stop();
            _gameWatchTimer?.Stop();
            _gameWatchTimer = null;
            try { ClearPresence(); _client?.Dispose(); _client = null; }
            catch (Exception ex) { Debug.WriteLine($"[Discord] Dispose error: {ex.Message}"); }
        }
    }
}
