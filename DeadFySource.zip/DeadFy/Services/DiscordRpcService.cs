// ============================================================
//  DiscordRpcService.cs  —  DeadFy
//
//  Song artwork in Discord presence:
//    • Streamed songs  → downloads YouTube/Spotify thumbnail bytes,
//                        uploads to imgbb.com
//    • Local songs     → extracts embedded cover art via TagLibSharp,
//                        uploads to imgbb.com
//    • imgbb URLs are cached by song ID so the same track never
//      uploads twice per session.
//    • Falls back to "deadfylogo" asset if the API key is missing,
//      upload fails, or the song has no art at all.
//
//  32-char limit workaround:
//    DiscordRPC.NET enforces a 32-char max on LargeImageKey, but
//    Discord itself accepts full HTTPS URLs. We store the full imgbb
//    URL in a static lookup table, pass a short placeholder key
//    (e.g. "img_0") through the library, and ListeningPipeClient
//    replaces the placeholder with the real URL in the raw JSON
//    before it hits the pipe — completely transparent to the library.
//
//  Setup: add your free imgbb API key to ApiConfig.cs:
//    public const string ImgbbApiKey = "YOUR_KEY_HERE";
//  Get one free at: https://api.imgbb.com
// ============================================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Pipes;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Threading;
using DiscordRPC;
using DiscordRPC.IO;
using DiscordRPC.Logging;
using DeadFy.Models;
using TagLib;
using File = System.IO.File;

namespace DeadFy.Services
{
    // ═══════════════════════════════════════════════════════════════════════
    //  Pipe client wrapper — injects "type":2 (Listening) into every
    //  activity payload so Discord shows the music note icon, AND replaces
    //  short placeholder image keys with their full HTTPS URLs so Discord
    //  can display uploaded artwork despite the library's 32-char limit.
    // ═══════════════════════════════════════════════════════════════════════

    internal sealed class ListeningPipeClient : INamedPipeClient
    {
        private readonly ManagedNamedPipeClient _inner = new();

        public bool IsConnected => _inner.IsConnected;
        public int ConnectedPipe => _inner.ConnectedPipe;
        public ILogger Logger { get => _inner.Logger; set => _inner.Logger = value; }

        public bool Connect(int pipe) => _inner.Connect(pipe);
        public void Close() => _inner.Close();
        public void Dispose() => _inner.Dispose();
        public bool ReadFrame(out PipeFrame frame) => _inner.ReadFrame(out frame);

        public bool WriteFrame(PipeFrame frame)
        {
            if (frame.Opcode == Opcode.Frame)
            {
                var json = frame.Message;
                if (json.Contains("\"activity\":{") || json.Contains("\"activity\": {"))
                {
                    json = InjectActivityType(json);
                    json = ExpandImageKeys(json);
                    frame = new PipeFrame { Opcode = frame.Opcode, Message = json };
                }
            }
            return _inner.WriteFrame(frame);
        }

        private static string InjectActivityType(string json)
        {
            const string marker = "\"activity\":{";
            const string marker2 = "\"activity\": {";

            int idx = json.IndexOf(marker, StringComparison.Ordinal);
            if (idx < 0)
            {
                idx = json.IndexOf(marker2, StringComparison.Ordinal);
                if (idx < 0) return json;
                idx += marker2.Length;
            }
            else idx += marker.Length;

            var after = json.Substring(idx).TrimStart();
            if (after.StartsWith("\"type\"", StringComparison.Ordinal)) return json;

            return json[..idx] + "\"type\":2," + json[idx..];
        }

        /// <summary>
        /// Replaces placeholder keys like "img_0" with their real full HTTPS
        /// URLs from the shared lookup table, in the raw JSON string.
        /// </summary>
        private static string ExpandImageKeys(string json)
        {
            foreach (var (placeholder, url) in DiscordRpcService.ImageKeyMap)
            {
                // Match the quoted placeholder as a JSON string value.
                var quoted = $"\"{placeholder}\"";
                if (json.Contains(quoted))
                    json = json.Replace(quoted, $"\"{url}\"");
            }
            return json;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  DiscordRpcService
    // ═══════════════════════════════════════════════════════════════════════

    public sealed class DiscordRpcService : IDisposable
    {
        // ── Singleton ──────────────────────────────────────────────────────────
        private static DiscordRpcService? _instance;
        public static DiscordRpcService Instance => _instance ??= new DiscordRpcService();

        private static string ClientId =>
            !string.IsNullOrWhiteSpace(ApiConfig.DiscordClientId)
                ? ApiConfig.DiscordClientId
                : "1480733403866337280";

        // ── Shared HTTP client ─────────────────────────────────────────────────
        private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(15) };

        // ── Placeholder → full URL map (shared with ListeningPipeClient) ───────
        // Keys are short strings like "img_0" that satisfy the 32-char limit.
        // ListeningPipeClient replaces them with the real URL in the raw JSON.
        internal static readonly ConcurrentDictionary<string, string> ImageKeyMap = new();
        private static int _imageKeyCounter;

        // ── imgbb session cache: songId → placeholder key ─────────────────────
        // Avoids re-uploading the same song's art more than once per session.
        private readonly ConcurrentDictionary<string, string> _artCache = new();

        // ── State ──────────────────────────────────────────────────────────────
        private DiscordRpcClient? _client;
        private bool _initialized;
        private bool _disposed;

        private bool _enabled = true;
        private Song? _lastSong;
        private bool _lastWasPlaying;

        // ── Debounce ───────────────────────────────────────────────────────────
        private const int DebounceMs = 250;
        private DispatcherTimer? _debounceTimer;
        private RichPresence? _pendingPresence;

        // ── Game watcher ───────────────────────────────────────────────────────
        private DispatcherTimer? _gameWatchTimer;
        private bool _gameIsRunning;

        private static readonly HashSet<string> KnownGameProcesses =
            new(StringComparer.OrdinalIgnoreCase)
        {
            "among us", "among_us",
            "cs2", "csgo",
            "valorant",
            "leagueoflegends",
            "riotclientservices",
            "fortnite",
            "fortniteclient-win64-shipping",
            "overwatch", "overwatch2",
            "minecraft", "minecraftlauncher", "javaw",
            "dota2",
            "r5apex",
            "gta5", "gtav",
            "eldenring",
            "sekiro",
            "cyberpunk2077",
            "destiny2",
            "cod", "modernwarfare",
            "rocketleague",
            "hl2",
        };

        // ── Public property ────────────────────────────────────────────────────

        public bool Enabled
        {
            get => _enabled;
            set
            {
                _enabled = value;
                if (!value) ClearPresence();
                else RestoreLastPresence();
            }
        }

        private DiscordRpcService() { }

        // ══════════════════════════════════════════════════════════════════════
        //  Init / reinit
        // ══════════════════════════════════════════════════════════════════════

        public void EnsureInitialized()
        {
            if (_initialized && _client?.IsInitialized == true) return;

            if (_client != null)
            {
                try { _client.Dispose(); } catch { }
                _client = null;
            }

            _initialized = true;

            try
            {
                _client = new DiscordRpcClient(
                    ClientId,
                    pipe: -1,
                    logger: new NullLogger(),
                    autoEvents: true,
                    client: new ListeningPipeClient());

                _client.OnReady += (_, e) => Debug.WriteLine($"[Discord] Ready — {e.User.Username}");
                _client.OnError += (_, e) => Debug.WriteLine($"[Discord] Error {e.Code}: {e.Message}");
                _client.OnConnectionFailed += (_, e) =>
                {
                    Debug.WriteLine($"[Discord] Pipe {e.FailedPipe} failed — will retry on next update");
                    _initialized = false;
                };

                _client.Initialize();

                var warmup = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
                warmup.Tick += (_, _) =>
                {
                    warmup.Stop();
                    if (_lastSong != null) RestoreLastPresence();
                    else SetIdlePresence();
                };
                warmup.Start();

                if (_gameWatchTimer == null)
                {
                    _gameWatchTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(10) };
                    _gameWatchTimer.Tick += (_, _) => CheckForGames();
                    _gameWatchTimer.Start();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[Discord] Init error: {ex.GetType().Name}: {ex.Message}");
                _client = null;
                _initialized = false;
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        //  Public API
        // ══════════════════════════════════════════════════════════════════════

        public void UpdatePresence(Song? song)
        {
            if (!_enabled || song == null) return;
            EnsureInitialized();
            if (_client == null || !_client.IsInitialized) return;

            _lastSong = song;
            _lastWasPlaying = true;
            if (_gameIsRunning) return;

            _ = UpdatePresenceWithArtAsync(song);
        }

        private async Task UpdatePresenceWithArtAsync(Song song)
        {
            var state = Truncate(song.DisplayArtist, 128);
            if (song.IsStreaming)
                state = "🎵 Streaming · " + state;

            var (largeKey, largeText) = await ResolveImageAsync(song).ConfigureAwait(false);

            await System.Windows.Application.Current.Dispatcher.InvokeAsync(() =>
            {
                // Guard: song may have changed while awaiting the imgbb upload.
                if (_lastSong?.Id != song.Id || !_lastWasPlaying) return;

                EnqueuePresence(new RichPresence
                {
                    Details = Truncate(song.DisplayTitle, 128),
                    State = state,
                    Timestamps = Timestamps.Now,
                    Assets = new Assets
                    {
                        LargeImageKey = largeKey,
                        LargeImageText = largeText,
                        SmallImageKey = "playing",
                        SmallImageText = "Playing"
                    }
                }, priority: true);
            });
        }

        public void SetPaused(Song? song)
        {
            if (!_enabled) return;
            EnsureInitialized();
            if (_client == null || !_client.IsInitialized) return;

            _lastSong = song;
            _lastWasPlaying = false;
            if (_gameIsRunning) return;

            _ = SetPausedWithArtAsync(song);
        }

        private async Task SetPausedWithArtAsync(Song? song)
        {
            string largeKey, largeText;

            if (song != null)
                (largeKey, largeText) = await ResolveImageAsync(song).ConfigureAwait(false);
            else
                (largeKey, largeText) = ("deadfylogo", "DeadFy");

            await System.Windows.Application.Current.Dispatcher.InvokeAsync(() =>
            {
                EnqueuePresence(new RichPresence
                {
                    Details = song != null ? Truncate(song.DisplayTitle, 128) : "DeadFy",
                    State = song != null ? Truncate(song.DisplayArtist, 128) : "Paused",
                    Assets = new Assets
                    {
                        LargeImageKey = largeKey,
                        LargeImageText = largeText,
                        SmallImageKey = "paused",
                        SmallImageText = "Paused"
                    }
                });
            });
        }

        public void SetIdlePresence()
        {
            if (!_enabled) return;
            EnsureInitialized();
            if (_client?.IsInitialized != true || _gameIsRunning) return;

            _lastSong = null;
            _lastWasPlaying = false;

            EnqueuePresence(new RichPresence
            {
                Details = "DeadFy",
                State = "Ready to play",
                Assets = new Assets
                {
                    LargeImageKey = "deadfylogo",
                    LargeImageText = "DeadFy"
                }
            });
        }

        public void ClearPresence()
        {
            _debounceTimer?.Stop();
            _pendingPresence = null;
            try { _client?.ClearPresence(); }
            catch (Exception ex) { Debug.WriteLine($"[Discord] ClearPresence error: {ex.Message}"); }
        }

        // ══════════════════════════════════════════════════════════════════════
        //  Artwork resolution + imgbb upload
        // ══════════════════════════════════════════════════════════════════════

        private async Task<(string Key, string Text)> ResolveImageAsync(Song song)
        {
            var fallbackText = !string.IsNullOrWhiteSpace(song.Album)
                ? Truncate(song.Album, 128)
                : Truncate(song.DisplayArtist, 128);

            if (string.IsNullOrWhiteSpace(fallbackText))
                fallbackText = "DeadFy";

            // Cache hit — already uploaded this session, return the placeholder.
            if (_artCache.TryGetValue(song.Id, out var cached))
            {
                Logger.Instance.Info($"[Imgbb] Cache hit for song {song.Id}");
                return (cached, fallbackText);
            }

            // No imgbb API key configured — skip upload, use logo.
            if (string.IsNullOrWhiteSpace(ApiConfig.ImgbbApiKey))
                return ("deadfylogo", fallbackText);

            byte[]? imageBytes = null;
            string filename = "cover.jpg";

            if (song.IsStreaming && !string.IsNullOrWhiteSpace(song.ThumbnailUrl))
            {
                // Streamed: download the YouTube/Spotify thumbnail bytes.
                try
                {
                    imageBytes = await Http.GetByteArrayAsync(song.ThumbnailUrl).ConfigureAwait(false);
                    filename = "thumbnail.jpg";
                }
                catch (Exception ex)
                {
                    Logger.Instance.Warning($"[Imgbb] Thumbnail download failed: {ex.Message}");
                }
            }
            else if (!string.IsNullOrWhiteSpace(song.CoverPath) && File.Exists(song.CoverPath))
            {
                // Local with separate cover file: read the file directly.
                try
                {
                    imageBytes = await File.ReadAllBytesAsync(song.CoverPath).ConfigureAwait(false);
                    filename = Path.GetFileName(song.CoverPath);
                }
                catch (Exception ex)
                {
                    Logger.Instance.Warning($"[Imgbb] CoverPath read failed: {ex.Message}");
                }
            }

            // Fallback for local songs: try extracting embedded art if no separate file was found.
            if (imageBytes == null && !string.IsNullOrWhiteSpace(song.FilePath) && File.Exists(song.FilePath))
            {
                // Local: extract embedded cover art via TagLibSharp.
                imageBytes = await Task.Run(() =>
                {
                    try
                    {
                        using var tagFile = TagLib.File.Create(song.FilePath);
                        var pictures = tagFile.Tag.Pictures;
                        if (pictures == null || pictures.Length == 0) return null;

                        // Prefer front cover (ID3 type 3), fall back to first picture.
                        IPicture? pic = null;
                        foreach (var p in pictures)
                            if (p.Type == PictureType.FrontCover) { pic = p; break; }
                        pic ??= pictures[0];

                        return pic.Data?.Data;
                    }
                    catch (Exception ex)
                    {
                        Logger.Instance.Warning($"[TagLib] Read failed for {song.FilePath}: {ex.Message}");
                        return null;
                    }
                }).ConfigureAwait(false);
            }

            if (imageBytes != null && imageBytes.Length > 0)
            {
                var url = await UploadToImgbbAsync(imageBytes, filename).ConfigureAwait(false);
                if (url != null)
                {
                    // Register a short placeholder key and map it to the full URL.
                    // ListeningPipeClient will swap it back in the raw pipe JSON.
                    var placeholder = $"img_{System.Threading.Interlocked.Increment(ref _imageKeyCounter)}";
                    ImageKeyMap[placeholder] = url;
                    _artCache[song.Id] = placeholder;

                    Logger.Instance.Info($"[Imgbb] Uploaded song {song.Id} → {url} (key: {placeholder})");
                    return (placeholder, fallbackText);
                }
            }

            return ("deadfylogo", fallbackText);
        }

        /// <summary>
        /// Uploads raw image bytes to imgbb.com using the configured API key.
        /// Returns the direct image URL on success, null on failure.
        /// e.g. "https://i.ibb.co/abc123/cover.jpg"
        /// </summary>
        private static byte[] MakeSquareWithPadding(byte[] inputBytes)
        {
            try
            {
                using var msInput = new MemoryStream(inputBytes);
                using var original = Image.FromStream(msInput);

                int maxDim = Math.Max(original.Width, original.Height);
                using var square = new Bitmap(maxDim, maxDim);
                using var g = Graphics.FromImage(square);

                // Clear with transparent or black background
                g.Clear(Color.Transparent);
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.SmoothingMode = SmoothingMode.HighQuality;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;

                // Center the original image
                int x = (maxDim - original.Width) / 2;
                int y = (maxDim - original.Height) / 2;
                g.DrawImage(original, x, y, original.Width, original.Height);

                using var msOutput = new MemoryStream();
                square.Save(msOutput, ImageFormat.Png);
                return msOutput.ToArray();
            }
            catch (Exception ex)
            {
                Logger.Instance.Warning($"[Imgbb] Squaring failed: {ex.Message}");
                return inputBytes; // Fallback to original
            }
        }

        private static async Task<string?> UploadToImgbbAsync(byte[] bytes, string filename)
        {
            try
            {
                // Process image to be square so Discord doesn't zoom/crop it
                bytes = MakeSquareWithPadding(bytes);

                using var content = new MultipartFormDataContent();
                content.Add(new StringContent(ApiConfig.ImgbbApiKey), "key");
                content.Add(new StringContent(Convert.ToBase64String(bytes)), "image");
                content.Add(new StringContent(Path.GetFileNameWithoutExtension(filename)), "name");

                var response = await Http.PostAsync("https://api.imgbb.com/1/upload", content)
                                         .ConfigureAwait(false);
                var json = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

                using var doc = JsonDocument.Parse(json);
                if (doc.RootElement.TryGetProperty("data", out var data) &&
                    data.TryGetProperty("url", out var url))
                    return url.GetString();

                Logger.Instance.Warning($"[Imgbb] Unexpected response: {json[..Math.Min(json.Length, 200)]}");
                return null;
            }
            catch (Exception ex)
            {
                Logger.Instance.Warning($"[Imgbb] Upload failed: {ex.Message} | Inner: {ex.InnerException?.Message}");
                return null;
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        //  Debounce engine
        // ══════════════════════════════════════════════════════════════════════

        private void EnqueuePresence(RichPresence presence, bool priority = false)
        {
            _pendingPresence = presence;

            if (_debounceTimer == null)
            {
                _debounceTimer = new DispatcherTimer();
                _debounceTimer.Tick += (_, _) =>
                {
                    _debounceTimer.Stop();
                    if (_pendingPresence != null)
                    {
                        SendDirect(_pendingPresence);
                        _pendingPresence = null;
                    }
                };
            }

            _debounceTimer.Stop();
            _debounceTimer.Interval = TimeSpan.FromMilliseconds(priority ? 50 : DebounceMs);
            _debounceTimer.Start();
        }

        private void SendDirect(RichPresence presence)
        {
            if (_client == null || !_client.IsInitialized) return;
            try
            {
                _client.SetPresence(presence);
                Debug.WriteLine($"[Discord] Sent — {presence.Details} / {presence.State}");
            }
            catch (DiscordRPC.Exceptions.StringOutOfRangeException ex)
            {
                Debug.WriteLine($"[Discord] String too long — skipped: {ex.Message}");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[Discord] Send error: {ex.Message}");
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        //  Game watcher
        // ══════════════════════════════════════════════════════════════════════

        private void CheckForGames()
        {
            bool found = false;
            try
            {
                foreach (var proc in Process.GetProcesses())
                    try { if (KnownGameProcesses.Contains(proc.ProcessName)) { found = true; break; } }
                    catch { }
            }
            catch (Exception ex) { Debug.WriteLine($"[Discord] GameWatcher error: {ex.Message}"); }

            if (found && !_gameIsRunning)
            {
                _gameIsRunning = true;
                ClearPresence();
                Debug.WriteLine("[Discord] Game detected — presence cleared.");
            }
            else if (!found && _gameIsRunning)
            {
                _gameIsRunning = false;
                RestoreLastPresence();
                Debug.WriteLine("[Discord] Game closed — presence restored.");
            }
        }

        private void RestoreLastPresence()
        {
            if (!_enabled || _client?.IsInitialized != true) return;
            if (_lastSong != null)
            {
                if (_lastWasPlaying) UpdatePresence(_lastSong);
                else SetPaused(_lastSong);
            }
            else SetIdlePresence();
        }

        // ══════════════════════════════════════════════════════════════════════
        //  Helpers
        // ══════════════════════════════════════════════════════════════════════

        private static string Truncate(string? s, int max)
        {
            if (string.IsNullOrEmpty(s)) return string.Empty;
            return s.Length <= max ? s : s[..(max - 1)] + "…";
        }

        // ══════════════════════════════════════════════════════════════════════
        //  IDisposable
        // ══════════════════════════════════════════════════════════════════════

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;

            if (_debounceTimer != null)
            {
                _debounceTimer.Stop();
                if (_pendingPresence != null) { SendDirect(_pendingPresence); _pendingPresence = null; }
            }

            _gameWatchTimer?.Stop();
            _gameWatchTimer = null;

            try { ClearPresence(); _client?.Dispose(); _client = null; }
            catch (Exception ex) { Debug.WriteLine($"[Discord] Dispose error: {ex.Message}"); }
        }
    }
}