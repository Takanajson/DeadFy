// ============================================================
//  DiscordRpcService.cs  —  DeadFy
//
//  Uses DiscordRichPresence 1.0.175 (Lachee).
//
//  HOW "Listening to" WORKS:
//  RichPresence is sealed so we cannot subclass it. Instead,
//  we supply a custom INamedPipeClient (ListeningPipeClient)
//  that wraps the real ManagedNamedPipeClient and intercepts
//  every outgoing JSON frame before it hits the pipe.
//  It finds the "activity" object in the payload and injects
//  "type":2  →  Discord renders "Listening to DeadFy"
//  with the music-note icon instead of the gamepad icon.
// ============================================================

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Text;
using System.Threading;
using System.Windows.Threading;
using DiscordRPC;
using DiscordRPC.IO;
using DiscordRPC.Logging;
using DeadFy.Models;

namespace DeadFy.Services
{
    // ──────────────────────────────────────────────────────────────
    //  Custom pipe client that injects "type":2 into every frame
    //  that contains an "activity" object, making Discord show
    //  "Listening to" instead of "Playing".
    // ──────────────────────────────────────────────────────────────
    internal sealed class ListeningPipeClient : INamedPipeClient
    {
        private readonly ManagedNamedPipeClient _inner = new();

        public bool IsConnected   => _inner.IsConnected;
        public int  ConnectedPipe => _inner.ConnectedPipe;
        public ILogger Logger
        {
            get => _inner.Logger;
            set => _inner.Logger = value;
        }

        public bool Connect(int pipe) => _inner.Connect(pipe);
        public void Close() => _inner.Close();
        public void Dispose() => _inner.Dispose();
        public bool ReadFrame(out PipeFrame frame) => _inner.ReadFrame(out frame);

        public bool WriteFrame(PipeFrame frame)
        {
            // Only intercept SET_ACTIVITY commands (opcode 1)
            if (frame.Opcode == Opcode.Frame)
            {
                var json = frame.Message;
                // Inject "type":2 inside the "activity":{} object
                if (json.Contains("\"activity\":{") || json.Contains("\"activity\": {"))
                {
                    json = InjectActivityType(json);
                    frame = new PipeFrame
                    {
                        Opcode  = frame.Opcode,
                        Message = json
                    };
                }
            }
            return _inner.WriteFrame(frame);
        }

        // Finds "activity":{ and inserts "type":2, before the first real key.
        private static string InjectActivityType(string json)
        {
            const string marker = "\"activity\":{";
            int idx = json.IndexOf(marker, StringComparison.Ordinal);
            if (idx < 0)
            {
                // try with a space
                const string marker2 = "\"activity\": {";
                idx = json.IndexOf(marker2, StringComparison.Ordinal);
                if (idx < 0) return json;
                idx += marker2.Length;
            }
            else
            {
                idx += marker.Length;
            }

            // Don't double-inject
            var after = json.Substring(idx).TrimStart();
            if (after.StartsWith("\"type\"", StringComparison.Ordinal)) return json;

            // Insert at idx — right after the opening brace of "activity"
            return json.Substring(0, idx) + "\"type\":2," + json.Substring(idx);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  DiscordRpcService
    // ══════════════════════════════════════════════════════════════
    public class DiscordRpcService : IDisposable
    {
        private static DiscordRpcService? _instance;
        public static DiscordRpcService Instance => _instance ??= new DiscordRpcService();

        private static string ClientId =>
            !string.IsNullOrWhiteSpace(ApiConfig.DiscordClientId)
                ? ApiConfig.DiscordClientId
                : "1480733403866337280";

        private DiscordRpcClient? _client;
        private bool _initialized = false;
        private bool _enabled = true;
        private Song? _lastSong;
        private bool _lastWasPlaying = false;

        private DispatcherTimer? _gameWatchTimer;
        private bool _gameIsRunning = false;

        private static readonly HashSet<string> KnownGameProcesses =
            new(StringComparer.OrdinalIgnoreCase)
        {
            "among us", "among_us", "cs2", "csgo", "valorant",
            "leagueoflegends", "riotclientservices", "fortnite",
            "fortniteclient-win64-shipping", "overwatch", "overwatch2",
            "minecraft", "minecraftlauncher", "javaw", "dota2",
            "r5apex", "gta5", "gtav", "eldenring", "sekiro",
            "cyberpunk2077", "destiny2", "cod", "modernwarfare",
            "rocketleague", "hl2",
        };

        public bool Enabled
        {
            get => _enabled;
            set
            {
                _enabled = value;
                if (!value) ClearPresence();
                else RestoreLastPresence();
            }
        }

        private DiscordRpcService() { }

        // ══════════════════════════════════════════════════════════
        //  INIT — pass our custom pipe client so type:2 is injected
        // ══════════════════════════════════════════════════════════
        public void EnsureInitialized()
        {
            if (_initialized) return;
            _initialized = true;

            try
            {
                // Pass the custom pipe client here — this is the key
                _client = new DiscordRpcClient(
                    ClientId,
                    pipe:       -1,
                    logger:     new NullLogger(),
                    autoEvents: true,
                    client:     new ListeningPipeClient()
                )
                {
                    SkipIdenticalPresence = true
                };

                _client.OnReady += (_, e) =>
                    Debug.WriteLine($"[Discord] Ready — {e.User.Username}");
                _client.OnError += (_, e) =>
                    Debug.WriteLine($"[Discord] Error {e.Code}: {e.Message}");
                _client.OnConnectionFailed += (_, e) =>
                    Debug.WriteLine($"[Discord] Connection failed on pipe {e.FailedPipe}");

                // Do NOT call RegisterUriScheme() — that marks this as a game
                _client.Initialize();

                var warmup = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
                warmup.Tick += (_, _) => { warmup.Stop(); SetIdlePresence(); };
                warmup.Start();

                _gameWatchTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(10) };
                _gameWatchTimer.Tick += (_, _) => CheckForGames();
                _gameWatchTimer.Start();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[Discord] Init error: {ex.GetType().Name}: {ex.Message}");
                _client = null;
            }
        }

        // ══════════════════════════════════════════════════════════
        //  PUBLIC API
        // ══════════════════════════════════════════════════════════
        public void UpdatePresence(Song? song)
        {
            if (!_enabled || song == null) return;
            EnsureInitialized();
            if (_client == null || !_client.IsInitialized) return;

            _lastSong = song;
            _lastWasPlaying = true;
            if (_gameIsRunning) return;

            try
            {
                Send(new RichPresence
                {
                    Details    = Truncate(song.DisplayTitle, 128),
                    State      = Truncate(song.DisplayArtist, 128),
                    Timestamps = Timestamps.Now,
                    Assets     = new Assets
                    {
                        LargeImageKey  = "deadfylogo",
                        LargeImageText = "DeadFy"
                    }
                });
            }
            catch (Exception ex) { Debug.WriteLine($"[Discord] UpdatePresence error: {ex.Message}"); }
        }

        public void SetPaused(Song? song)
        {
            if (!_enabled) return;
            EnsureInitialized();
            if (_client == null || !_client.IsInitialized) return;

            _lastSong = song;
            _lastWasPlaying = false;
            if (_gameIsRunning) return;

            try
            {
                Send(new RichPresence
                {
                    Details = song != null ? Truncate(song.DisplayTitle, 128) : "DeadFy",
                    State   = song != null ? Truncate(song.DisplayArtist, 128) : "Paused",
                    Assets  = new Assets
                    {
                        LargeImageKey  = "deadfylogo",
                        LargeImageText = "DeadFy"
                    }
                });
            }
            catch (Exception ex) { Debug.WriteLine($"[Discord] SetPaused error: {ex.Message}"); }
        }

        public void SetIdlePresence()
        {
            if (!_enabled) return;
            EnsureInitialized();
            if (_client?.IsInitialized != true) return;
            if (_gameIsRunning) return;

            try
            {
                Send(new RichPresence
                {
                    Details = "DeadFy",
                    State   = "Ready to play",
                    Assets  = new Assets
                    {
                        LargeImageKey  = "deadfylogo",
                        LargeImageText = "DeadFy"
                    }
                });
            }
            catch (Exception ex) { Debug.WriteLine($"[Discord] SetIdlePresence error: {ex.Message}"); }
        }

        public void ClearPresence()
        {
            try { _client?.ClearPresence(); }
            catch (Exception ex) { Debug.WriteLine($"[Discord] ClearPresence error: {ex.Message}"); }
        }

        private void Send(RichPresence presence)
        {
            if (_client == null || !_client.IsInitialized) return;
            _client.SetPresence(presence);
            Debug.WriteLine($"[Discord] Sent — {presence.Details} / {presence.State}");
        }

        // ══════════════════════════════════════════════════════════
        //  GAME WATCHER
        // ══════════════════════════════════════════════════════════
        private void CheckForGames()
        {
            bool found = false;
            try
            {
                foreach (var proc in Process.GetProcesses())
                {
                    try { if (KnownGameProcesses.Contains(proc.ProcessName)) { found = true; break; } }
                    catch { }
                }
            }
            catch (Exception ex) { Debug.WriteLine($"[Discord] GameWatcher error: {ex.Message}"); }

            if (found && !_gameIsRunning)
            {
                _gameIsRunning = true;
                ClearPresence();
                Debug.WriteLine("[Discord] Game detected — DeadFy presence cleared.");
            }
            else if (!found && _gameIsRunning)
            {
                _gameIsRunning = false;
                RestoreLastPresence();
                Debug.WriteLine("[Discord] Game closed — DeadFy presence restored.");
            }
        }

        private void RestoreLastPresence()
        {
            if (!_enabled || _client?.IsInitialized != true) return;
            if (_lastSong != null)
            {
                if (_lastWasPlaying) UpdatePresence(_lastSong);
                else SetPaused(_lastSong);
            }
            else SetIdlePresence();
        }



        private static string Truncate(string s, int max)
            => s.Length <= max ? s : s[..(max - 1)] + "…";

        public void Dispose()
        {
            _gameWatchTimer?.Stop();
            _gameWatchTimer = null;
            try { ClearPresence(); _client?.Dispose(); _client = null; }
            catch (Exception ex) { Debug.WriteLine($"[Discord] Dispose error: {ex.Message}"); }
        }
    }
}
