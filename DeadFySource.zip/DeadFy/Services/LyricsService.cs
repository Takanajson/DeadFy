using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using DeadFy.Plugins;

namespace DeadFy.Services
{
    /// <summary>One line of synced lyrics with its timestamp.</summary>
    public class LyricLine
    {
        public TimeSpan Time { get; set; }
        public string Text { get; set; } = string.Empty;
    }

    public class LyricsResult
    {
        /// <summary>Plain text lyrics (always populated if found).</summary>
        public string PlainLyrics { get; set; } = string.Empty;

        /// <summary>Synced lines (populated only when an LRC source is available).</summary>
        public List<LyricLine> SyncedLines { get; set; } = new();

        /// <summary>Name of the source that supplied the lyrics (for UI attribution).</summary>
        public string Source { get; set; } = string.Empty;

        public bool HasSync => SyncedLines.Count > 0;
        public bool IsEmpty => string.IsNullOrWhiteSpace(PlainLyrics) && SyncedLines.Count == 0;
    }

    public class LyricsService
    {
        private static LyricsService? _instance;
        public static LyricsService Instance => _instance ??= new LyricsService();

        private static readonly HttpClient Http = new()
        {
            Timeout = TimeSpan.FromSeconds(12),
            DefaultRequestHeaders = { { "User-Agent", "DeadFy/1.0" } }
        };

        // ── Disk cache ─────────────────────────────────────────────────────────
        private static string CacheDir => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "DeadFy", "LyricsCache");

        // In-memory single-entry cache for the currently loaded song.
        private string _lastKey = string.Empty;
        private LyricsResult _lastResult = new();

        // ── Public API ─────────────────────────────────────────────────────────

        /// <summary>Returns plain lyrics string (for callers that just want text).</summary>
        public async Task<string> GetLyricsAsync(string title, string artist, CancellationToken ct = default)
            => (await GetFullAsync(title, artist, null, ct)).PlainLyrics;

        /// <summary>Returns full result including synced lines.</summary>
        public async Task<LyricsResult> GetFullAsync(
            string title,
            string artist,
            TimeSpan? duration = null,
            CancellationToken ct = default)
        {
            var key = BuildKey(title, artist);
            if (key == _lastKey) return _lastResult;

            // 1. Check disk cache first (instant, no network).
            var cached = TryLoadFromDiskCache(key);
            if (cached != null)
            {
                _lastKey = key;
                _lastResult = cached;
                return cached;
            }

            LyricsResult result = new();
            try
            {
                // 2. Primary: lrclib (synced preferred).
                result = await FetchFromLrclibAsync(title, artist, duration, ct);

                // 3. Secondary fallback — try plugins registered via PluginLoaderService.
                if (result.IsEmpty)
                {
                    foreach (var plugin in PluginLoaderService.Instance.LyricsPlugins)
                    {
                        ct.ThrowIfCancellationRequested();
                        try
                        {
                            var pluginResult = await plugin.GetLyricsAsync(title, artist, ct);
                            if (pluginResult != null && !string.IsNullOrWhiteSpace(pluginResult.PlainLyrics))
                            {
                                result = new LyricsResult
                                {
                                    PlainLyrics = pluginResult.PlainLyrics,
                                    SyncedLines = pluginResult.SyncedLines
                                        .Select(l => new LyricLine { Time = l.Time, Text = l.Text })
                                        .ToList(),
                                    Source = plugin.GetType().Name
                                };
                                break;
                            }
                        }
                        catch (OperationCanceledException) { throw; }
                        catch (Exception ex)
                        {
                            Logger.Instance.Warning($"[Lyrics] Plugin {plugin.GetType().Name} failed: {ex.Message}");
                        }
                    }
                }
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex) { Logger.Instance.Error("[Lyrics] request failed", ex); }

            // 4. Cache to disk so the next lookup is instant.
            if (!result.IsEmpty)
                SaveToDiskCache(key, result);

            _lastKey = key;
            _lastResult = result;
            return result;
        }

        // ── Disk cache helpers ─────────────────────────────────────────────────

        private static string CachePath(string key)
        {
            // Sanitise key for use as filename.
            var safe = string.Concat(key.Split(Path.GetInvalidFileNameChars()));
            return Path.Combine(CacheDir, safe + ".json");
        }

        private static string BuildKey(string title, string artist)
            => $"{title.Trim()}|{artist.Trim()}".ToLowerInvariant();

        private static LyricsResult? TryLoadFromDiskCache(string key)
        {
            try
            {
                var path = CachePath(key);
                if (!File.Exists(path)) return null;

                var json = File.ReadAllText(path);
                return JsonSerializer.Deserialize<LyricsResult>(json);
            }
            catch { return null; }
        }

        private static void SaveToDiskCache(string key, LyricsResult result)
        {
            try
            {
                Directory.CreateDirectory(CacheDir);
                var path = CachePath(key);
                File.WriteAllText(path, JsonSerializer.Serialize(result));
            }
            catch { /* non-fatal */ }
        }

        /// <summary>Delete cached lyrics for a specific song (force re-fetch).</summary>
        public void InvalidateCache(string title, string artist)
        {
            try
            {
                var path = CachePath(BuildKey(title, artist));
                if (File.Exists(path)) File.Delete(path);
                _lastKey = string.Empty;
            }
            catch { }
        }

        /// <summary>Wipes the entire lyrics disk cache.</summary>
        public void ClearDiskCache()
        {
            try
            {
                if (Directory.Exists(CacheDir))
                    Directory.Delete(CacheDir, recursive: true);
                _lastKey = string.Empty;
                _lastResult = new LyricsResult();
                Logger.Instance.Info("[Lyrics] Disk cache cleared");
            }
            catch (Exception ex) { Logger.Instance.Warning($"[Lyrics] ClearDiskCache: {ex.Message}"); }
        }

        // ── LRCLIB fetch ────────────────────────────────────────────────────────
        private static async Task<LyricsResult> FetchFromLrclibAsync(
            string title, string artist, TimeSpan? duration, CancellationToken ct)
        {
            // Try exact match first (title + artist + optional duration).
            var url = "https://lrclib.net/api/get"
                    + $"?track_name={Uri.EscapeDataString(title.Trim())}"
                    + $"&artist_name={Uri.EscapeDataString(artist.Trim())}";

            if (duration.HasValue)
                url += $"&duration={Math.Round(duration.Value.TotalSeconds)}";

            try
            {
                var json = await Http.GetStringAsync(url, ct);
                var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;

                var syncedText = root.TryGetProperty("syncedLyrics", out var synced) ? synced.GetString() ?? "" : "";
                var plainText = root.TryGetProperty("plainLyrics", out var plain) ? plain.GetString() ?? "" : "";

                if (!string.IsNullOrWhiteSpace(syncedText))
                {
                    var lines = ParseLrc(syncedText);
                    return new LyricsResult
                    {
                        PlainLyrics = BuildPlain(lines),
                        SyncedLines = lines,
                        Source = "lrclib"
                    };
                }

                if (!string.IsNullOrWhiteSpace(plainText))
                    return new LyricsResult { PlainLyrics = Clean(plainText), Source = "lrclib" };
            }
            catch (HttpRequestException) { /* fall through to search */ }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex) { Logger.Instance.Debug($"[Lyrics] lrclib get: {ex.Message}"); }

            // Fallback: fuzzy search endpoint.
            var searchUrl = "https://lrclib.net/api/search"
                          + $"?q={Uri.EscapeDataString(title.Trim())}"
                          + $"&artist_name={Uri.EscapeDataString(artist.Trim())}"
                          + $"&track_name={Uri.EscapeDataString(title.Trim())}";

            try
            {
                var json = await Http.GetStringAsync(searchUrl, ct);
                var arr = JsonDocument.Parse(json).RootElement;

                if (arr.ValueKind != JsonValueKind.Array || arr.GetArrayLength() == 0)
                    return new LyricsResult();

                foreach (var item in arr.EnumerateArray())
                {
                    if (!item.TryGetProperty("syncedLyrics", out var synced)) continue;
                    var lrc = synced.GetString() ?? "";
                    if (string.IsNullOrWhiteSpace(lrc)) continue;

                    var lines = ParseLrc(lrc);
                    return new LyricsResult { PlainLyrics = BuildPlain(lines), SyncedLines = lines, Source = "lrclib" };
                }

                foreach (var item in arr.EnumerateArray())
                {
                    if (!item.TryGetProperty("plainLyrics", out var plain)) continue;
                    var text = plain.GetString() ?? "";
                    if (!string.IsNullOrWhiteSpace(text))
                        return new LyricsResult { PlainLyrics = Clean(text), Source = "lrclib" };
                }
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex) { Logger.Instance.Debug($"[Lyrics] lrclib search: {ex.Message}"); }

            return new LyricsResult();
        }

        // ── LRC parser ──────────────────────────────────────────────────────────
        // Format: [mm:ss.xx] lyric text   or   [mm:ss.xxx]
        private static readonly Regex LrcRegex =
            new(@"^\[(\d{1,3}):(\d{2})\.(\d{2,3})\](.*)", RegexOptions.Compiled);

        public static List<LyricLine> ParseLrc(string lrc)
        {
            var lines = new List<LyricLine>();
            foreach (var raw in lrc.Split('\n'))
            {
                var trimmed = raw.Trim();
                var m = LrcRegex.Match(trimmed);
                if (!m.Success) continue;

                int min = int.Parse(m.Groups[1].Value);
                int sec = int.Parse(m.Groups[2].Value);
                int ms100 = int.Parse(m.Groups[3].Value);
                int ms = m.Groups[3].Value.Length == 2 ? ms100 * 10 : ms100;
                var text = m.Groups[4].Value.Trim();

                lines.Add(new LyricLine
                {
                    Time = new TimeSpan(0, 0, min, sec, ms),
                    Text = text
                });
            }
            lines.Sort((a, b) => a.Time.CompareTo(b.Time));
            return lines;
        }

        private static string BuildPlain(List<LyricLine> lines)
        {
            var sb = new StringBuilder();
            foreach (var l in lines)
                if (!string.IsNullOrEmpty(l.Text)) sb.AppendLine(l.Text);
            return sb.ToString().Trim();
        }

        private static string Clean(string text)
            => text.Replace("\r\n", "\n").Replace("\r", "\n").Trim();
    }
}