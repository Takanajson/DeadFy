using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace DeadFy.Services
{
    /// <summary>One line of synced lyrics with its timestamp.</summary>
    public class LyricLine
    {
        public TimeSpan Time { get; set; }
        public string   Text { get; set; } = string.Empty;
    }

    public class LyricsResult
    {
        /// <summary>Plain text lyrics (always populated if found).</summary>
        public string PlainLyrics { get; set; } = string.Empty;

        /// <summary>Synced lines (populated only when lrclib returns syncedLyrics).</summary>
        public List<LyricLine> SyncedLines { get; set; } = new();

        public bool HasSync => SyncedLines.Count > 0;
    }

    public class LyricsService
    {
        private static LyricsService? _instance;
        public static LyricsService Instance => _instance ??= new LyricsService();

        private static readonly HttpClient Http = new()
        {
            Timeout = TimeSpan.FromSeconds(10),
            DefaultRequestHeaders = { { "User-Agent", "DeadFy/1.0" } }
        };

        // Simple cache keyed by "title|artist"
        private string       _lastKey    = string.Empty;
        private LyricsResult _lastResult = new();

        // ── Public API ─────────────────────────────────────────────────
        /// <summary>Returns plain lyrics string (for callers that just want text).</summary>
        public async Task<string> GetLyricsAsync(string title, string artist, CancellationToken ct = default)
            => (await GetFullAsync(title, artist, ct)).PlainLyrics;

        /// <summary>Returns full result including synced lines.</summary>
        public async Task<LyricsResult> GetFullAsync(string title, string artist, CancellationToken ct = default)
        {
            var key = $"{title}|{artist}".ToLowerInvariant();
            if (key == _lastKey) return _lastResult;

            LyricsResult result = new();
            try
            {
                result = await FetchFromLrclibAsync(title, artist, ct);
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex) { Logger.Instance.Error("[Lyrics] request failed", ex); }

            _lastKey    = key;
            _lastResult = result;
            return result;
        }

        // ── LRCLIB fetch ───────────────────────────────────────────────
        private async Task<LyricsResult> FetchFromLrclibAsync(string title, string artist, CancellationToken ct)
        {
            var url = $"https://lrclib.net/api/search" +
                      $"?q={Uri.EscapeDataString(title.Trim())}" +
                      $"&artist_name={Uri.EscapeDataString(artist.Trim())}" +
                      $"&track_name={Uri.EscapeDataString(title.Trim())}";

            var json = await Http.GetStringAsync(url, ct);
            var arr  = JsonDocument.Parse(json).RootElement;

            if (arr.ValueKind != JsonValueKind.Array || arr.GetArrayLength() == 0)
                return new LyricsResult();

            // Prefer items that have syncedLyrics
            foreach (var item in arr.EnumerateArray())
            {
                if (!item.TryGetProperty("syncedLyrics", out var synced)) continue;
                var lrc = synced.GetString() ?? "";
                if (string.IsNullOrWhiteSpace(lrc)) continue;

                var lines = ParseLrc(lrc);
                var plain = BuildPlain(lines);
                return new LyricsResult { PlainLyrics = plain, SyncedLines = lines };
            }

            // Fallback: plain lyrics only
            foreach (var item in arr.EnumerateArray())
            {
                if (!item.TryGetProperty("plainLyrics", out var plain)) continue;
                var text = plain.GetString() ?? "";
                if (!string.IsNullOrWhiteSpace(text))
                    return new LyricsResult { PlainLyrics = Clean(text) };
            }

            return new LyricsResult();
        }

        // ── LRC parser ─────────────────────────────────────────────────
        // Format: [mm:ss.xx] lyric text   or   [mm:ss.xxx]
        private static readonly Regex LrcRegex =
            new(@"^\[(\d{1,3}):(\d{2})\.(\d{2,3})\](.*)", RegexOptions.Compiled);

        public static List<LyricLine> ParseLrc(string lrc)
        {
            var lines  = new List<LyricLine>();
            foreach (var raw in lrc.Split('\n'))
            {
                var trimmed = raw.Trim();
                var m = LrcRegex.Match(trimmed);
                if (!m.Success) continue;

                int min   = int.Parse(m.Groups[1].Value);
                int sec   = int.Parse(m.Groups[2].Value);
                int ms100 = int.Parse(m.Groups[3].Value);
                // Handle both 2-digit (centiseconds) and 3-digit (milliseconds)
                int ms    = m.Groups[3].Length == 2 ? ms100 * 10 : ms100;
                var text  = m.Groups[4].Value.Trim();

                lines.Add(new LyricLine
                {
                    Time = new TimeSpan(0, 0, min, sec, ms),
                    Text = text
                });
            }
            lines.Sort((a, b) => a.Time.CompareTo(b.Time));
            return lines;
        }

        private static string BuildPlain(List<LyricLine> lines)
        {
            var sb = new StringBuilder();
            foreach (var l in lines)
                if (!string.IsNullOrEmpty(l.Text)) sb.AppendLine(l.Text);
            return sb.ToString().Trim();
        }

        private static string Clean(string text)
            => text.Replace("\r\n", "\n").Replace("\r", "\n").Trim();
    }
}
