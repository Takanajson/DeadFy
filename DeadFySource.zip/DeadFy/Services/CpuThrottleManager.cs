using System;
using System.Diagnostics;
using System.Threading;

namespace DeadFy.Services
{
    /// <summary>
    /// Monitors per-process CPU usage and injects micro-sleeps when the app
    /// approaches saturation, keeping the WPF dispatcher responsive even when
    /// background streaming, scanning, or plugin work hammers the CPU.
    ///
    /// Usage:
    ///     CpuThrottleManager.Instance.Start();   // App.OnStartup
    ///     CpuThrottleManager.Instance.Stop();    // App.OnExit
    /// </summary>
    public sealed class CpuThrottleManager : IDisposable
    {
        // ── Singleton ─────────────────────────────────────────────────────────
        private static CpuThrottleManager? _instance;
        public  static CpuThrottleManager Instance => _instance ??= new CpuThrottleManager();

        // ── Configuration ─────────────────────────────────────────────────────

        /// <summary>Per-process CPU% above which throttling kicks in (default 78).</summary>
        public int ThrottleThreshold { get; set; } = 78;

        /// <summary>How often to sample CPU, in ms (default 500).</summary>
        public int SampleIntervalMs { get; set; } = 500;

        /// <summary>
        /// Maximum sleep injected per sample when CPU is saturated, in ms (default 6).
        /// Small enough to be inaudible, large enough to let the dispatcher breathe.
        /// </summary>
        public int MaxSleepMs { get; set; } = 6;

        // ── State ─────────────────────────────────────────────────────────────
        private Thread?            _thread;
        private volatile bool      _running;
        private PerformanceCounter? _counter;
        private bool               _disposed;

        // ── Lifecycle ─────────────────────────────────────────────────────────
        public void Start()
        {
            if (_running) return;

            try
            {
                _counter = new PerformanceCounter(
                    "Process",
                    "% Processor Time",
                    Process.GetCurrentProcess().ProcessName,
                    readOnly: true);

                _counter.NextValue(); // first read always returns 0 — discard
            }
            catch
            {
                // Performance counters disabled by group policy — degrade gracefully.
                Logger.Instance.Warning("CpuThrottleManager: performance counters unavailable — throttling disabled");
                return;
            }

            _running = true;
            _thread = new Thread(MonitorLoop)
            {
                IsBackground = true,
                Name = "CpuThrottleMonitor",
                Priority = ThreadPriority.BelowNormal
            };
            _thread.Start();
            Logger.Instance.Info("CpuThrottleManager started");
        }

        public void Stop()
        {
            _running = false;
        }

        // ── Monitor loop ──────────────────────────────────────────────────────
        private void MonitorLoop()
        {
            while (_running)
            {
                try
                {
                    Thread.Sleep(SampleIntervalMs);
                    if (!_running || _counter == null) break;

                    // Raw value can exceed 100 on multi-core — normalise.
                    float raw   = _counter.NextValue();
                    float usage = raw / Math.Max(1, Environment.ProcessorCount);

                    if (usage >= ThrottleThreshold)
                    {
                        float excess  = (usage - ThrottleThreshold) / (100f - ThrottleThreshold);
                        int   sleepMs = Math.Max(1, (int)(excess * MaxSleepMs));
                        Thread.Sleep(sleepMs);
                    }
                }
                catch (ThreadAbortException) { break; }
                catch
                {
                    // Counter became unavailable (e.g. process renamed) — stop.
                    _running = false;
                }
            }
        }

        // ── IDisposable ───────────────────────────────────────────────────────
        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            Stop();
            _counter?.Dispose();
        }
    }
}
