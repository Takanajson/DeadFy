using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using DeadFy.Models;

namespace DeadFy.Services
{
    public class YouTubeService
    {
        private static YouTubeService? _instance;
        public static YouTubeService Instance => _instance ??= new YouTubeService();

        // Single shared HttpClient — never create one per request
        internal static readonly HttpClient Http = new(new HttpClientHandler
        {
            AllowAutoRedirect = true,
            UseCookies = false
        })
        {
            Timeout = TimeSpan.FromSeconds(60),
            DefaultRequestHeaders =
            {
                { "User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36" }
            }
        };

        // ─────────────────────────────────────────────────────────────
        // Paths
        // ─────────────────────────────────────────────────────────────
        private static string AppDataDir => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "DeadFy");
        private static string YtDlpExe => Path.Combine(AppDataDir, "yt-dlp.exe");
        private static string FfmpegExe => Path.Combine(AppDataDir, "ffmpeg.exe");

        // ─────────────────────────────────────────────────────────────
        // SEARCH — uses YouTube Data API v3 if key set, else scrape
        // ─────────────────────────────────────────────────────────────
        public async Task SearchStreamingAsync(
            string query,
            int maxResults,
            Action<YouTubeSearchResult> onResult,
            CancellationToken ct = default)
        {
            // ApiConfig.YouTubeApiKey takes priority; falls back to settings
            var apiKey = !string.IsNullOrWhiteSpace(ApiConfig.YouTubeApiKey)
                ? ApiConfig.YouTubeApiKey
                : SettingsService.Instance.Settings.YouTubeApiKey?.Trim();

            if (!string.IsNullOrEmpty(apiKey))
                await SearchViaDataApiAsync(query, maxResults, apiKey, onResult, ct);
            else
                await SearchViaScrapingAsync(query, maxResults, onResult, ct);
        }

        // ── YouTube Data API v3 (requires free API key) ───────────────
        private async Task SearchViaDataApiAsync(
            string query, int maxResults, string apiKey,
            Action<YouTubeSearchResult> onResult, CancellationToken ct)
        {
            try
            {
                var encoded = Uri.EscapeDataString(query);
                var url = $"https://www.googleapis.com/youtube/v3/search" +
                          $"?part=snippet&type=video&maxResults={maxResults}" +
                          $"&q={encoded}&key={apiKey}";

                var json = await Http.GetStringAsync(url, ct);
                var doc = System.Text.Json.JsonDocument.Parse(json);

                var videoIds = new List<string>();
                var snippets = new List<(string id, string title, string channel, string thumb)>();

                foreach (var item in doc.RootElement.GetProperty("items").EnumerateArray())
                {
                    var id = item.GetProperty("id").GetProperty("videoId").GetString() ?? "";
                    var snippet = item.GetProperty("snippet");
                    var title = snippet.GetProperty("title").GetString() ?? "";
                    var channel = snippet.GetProperty("channelTitle").GetString() ?? "";
                    var thumb = snippet.GetProperty("thumbnails")
                                         .GetProperty("medium")
                                         .GetProperty("url").GetString() ?? "";
                    videoIds.Add(id);
                    snippets.Add((id, title, channel, thumb));
                }

                // Fetch durations in one batch call
                var durations = new Dictionary<string, TimeSpan>();
                if (videoIds.Count > 0)
                {
                    var ids = string.Join(",", videoIds.Select(Uri.EscapeDataString));
                    var detUrl = $"https://www.googleapis.com/youtube/v3/videos" +
                                  $"?part=contentDetails&id={ids}&key={apiKey}";
                    var detJson = await Http.GetStringAsync(detUrl, ct);
                    var detDoc = System.Text.Json.JsonDocument.Parse(detJson);
                    foreach (var item in detDoc.RootElement.GetProperty("items").EnumerateArray())
                    {
                        var id = item.GetProperty("id").GetString() ?? "";
                        var iso = item.GetProperty("contentDetails").GetProperty("duration").GetString() ?? "";
                        durations[id] = ParseIso8601Duration(iso);
                    }
                }

                foreach (var (id, title, channel, thumb) in snippets)
                {
                    ct.ThrowIfCancellationRequested();
                    var result = new YouTubeSearchResult
                    {
                        VideoId = id,
                        Title = title,
                        Author = channel,
                        ThumbnailUrl = thumb,
                        Url = $"https://www.youtube.com/watch?v={id}",
                        Duration = durations.TryGetValue(id, out var d) ? d : null
                    };
                    onResult(result);
                    _ = result.LoadThumbnailAsync(ct);
                }
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                Logger.Instance.Debug($"[YT API] {ex.GetType().Name}: {ex.Message}");
                throw; // Let caller show error
            }
        }

        // ── Scrape fallback (no key needed) ───────────────────────────
        private async Task SearchViaScrapingAsync(
            string query, int maxResults,
            Action<YouTubeSearchResult> onResult, CancellationToken ct)
        {
            try
            {
                // Use YouTube's search suggest + initial data endpoint
                var encoded = Uri.EscapeDataString(query);
                var url = $"https://www.youtube.com/results?search_query={encoded}&sp=EgIQAQ%3D%3D"; // music filter

                var request = new HttpRequestMessage(HttpMethod.Get, url);
                request.Headers.Add("Accept-Language", "en-US,en;q=0.9");
                request.Headers.Add("Accept", "text/html,application/xhtml+xml");

                var response = await Http.SendAsync(request, ct);
                var html = await response.Content.ReadAsStringAsync(ct);

                // Extract ytInitialData JSON blob
                var marker = "var ytInitialData = ";
                var start = html.IndexOf(marker, StringComparison.Ordinal);
                if (start < 0) throw new Exception("Could not find ytInitialData in YouTube page");
                start += marker.Length;
                var end = html.IndexOf(";</script>", start, StringComparison.Ordinal);
                if (end < 0) end = html.IndexOf(";\n", start, StringComparison.Ordinal);
                if (end < 0) throw new Exception("Could not find end of ytInitialData");

                var ytJson = html.Substring(start, end - start);
                var doc = System.Text.Json.JsonDocument.Parse(ytJson);

                var contents = FindVideoRenderers(doc.RootElement);
                int count = 0;

                foreach (var video in contents)
                {
                    if (count >= maxResults) break;
                    ct.ThrowIfCancellationRequested();

                    try
                    {
                        var id = video.GetProperty("videoId").GetString() ?? "";
                        var title = GetNestedText(video, "title") ?? "";
                        var channel = GetNestedText(video, "longBylineText")
                                   ?? GetNestedText(video, "shortBylineText") ?? "";
                        var durText = GetNestedText(video, "lengthText") ?? "";

                        // Get best thumbnail
                        var thumb = "";
                        if (video.TryGetProperty("thumbnail", out var thumbEl) &&
                            thumbEl.TryGetProperty("thumbnails", out var thumbArr))
                        {
                            foreach (var t in thumbArr.EnumerateArray())
                            {
                                thumb = t.GetProperty("url").GetString() ?? thumb;
                            }
                        }

                        if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(title)) continue;

                        var result = new YouTubeSearchResult
                        {
                            VideoId = id,
                            Title = System.Net.WebUtility.HtmlDecode(title),
                            Author = System.Net.WebUtility.HtmlDecode(channel),
                            ThumbnailUrl = thumb,
                            Url = $"https://www.youtube.com/watch?v={id}",
                            Duration = ParseDurationText(durText)
                        };

                        onResult(result);
                        _ = result.LoadThumbnailAsync(ct);
                        count++;
                    }
                    catch (Exception ex)
                    {
                        Logger.Instance.Warning($"[YT Scrape] skip item: {ex.Message}");
                    }
                }

                if (count == 0)
                    throw new Exception("No results parsed from YouTube page");
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                Logger.Instance.Debug($"[YT Scrape] {ex.GetType().Name}: {ex.Message}");
                throw;
            }
        }

        // Walk the ytInitialData JSON to find videoRenderer objects
        private static IEnumerable<System.Text.Json.JsonElement> FindVideoRenderers(System.Text.Json.JsonElement root)
        {
            var results = new List<System.Text.Json.JsonElement>();
            WalkJson(root, results, 0);
            return results;
        }

        private static void WalkJson(System.Text.Json.JsonElement el, List<System.Text.Json.JsonElement> results, int depth)
        {
            if (depth > 20 || results.Count >= 25) return;
            if (el.ValueKind == System.Text.Json.JsonValueKind.Object)
            {
                if (el.TryGetProperty("videoRenderer", out var vr))
                { results.Add(vr); return; }
                foreach (var prop in el.EnumerateObject())
                    WalkJson(prop.Value, results, depth + 1);
            }
            else if (el.ValueKind == System.Text.Json.JsonValueKind.Array)
            {
                foreach (var item in el.EnumerateArray())
                    WalkJson(item, results, depth + 1);
            }
        }

        private static string? GetNestedText(System.Text.Json.JsonElement el, string key)
        {
            if (!el.TryGetProperty(key, out var val)) return null;
            // { "runs": [{ "text": "..." }] }
            if (val.TryGetProperty("runs", out var runs) && runs.GetArrayLength() > 0)
                return runs[0].GetProperty("text").GetString();
            // { "simpleText": "..." }
            if (val.TryGetProperty("simpleText", out var simple))
                return simple.GetString();
            return null;
        }

        private static TimeSpan? ParseDurationText(string text)
        {
            // e.g. "3:45" or "1:02:33"
            if (string.IsNullOrWhiteSpace(text)) return null;
            var parts = text.Trim().Split(':');
            try
            {
                if (parts.Length == 2)
                    return new TimeSpan(0, int.Parse(parts[0]), int.Parse(parts[1]));
                if (parts.Length == 3)
                    return new TimeSpan(int.Parse(parts[0]), int.Parse(parts[1]), int.Parse(parts[2]));
            }
            catch { }
            return null;
        }

        private static TimeSpan ParseIso8601Duration(string iso)
        {
            // e.g. PT4M33S or PT1H2M3S
            try { return System.Xml.XmlConvert.ToTimeSpan(iso); }
            catch { return TimeSpan.Zero; }
        }

        // ─────────────────────────────────────────────────────────────
        // DOWNLOAD
        // ─────────────────────────────────────────────────────────────
        public async Task<Song?> DownloadAudioAsync(
            YouTubeSearchResult result,
            Action<double>? onProgress = null,
            Action<string>? onStatus = null,
            CancellationToken ct = default)
        {
            // 1. Ensure yt-dlp.exe is present (~9 MB, downloaded once)
            await EnsureYtDlpAsync(onStatus, ct);

            var outputDir = LibraryService.Instance.MusicFolder;
            var uid = Guid.NewGuid().ToString("N")[..12];
            var outTemplate = Path.Combine(outputDir, $"{uid}.%(ext)s");

            // bestaudio/best — no ffmpeg needed, yt-dlp picks best audio-only stream
            var args = $"\"{result.Url}\"" +
                       $" --format \"bestaudio/best\"" +
                       $" -o \"{outTemplate}\"" +
                       $" --no-playlist --newline --no-part --no-write-info-json";

            onStatus?.Invoke("⬇ Downloading...");
            Logger.Instance.Debug($"[DL] CMD: yt-dlp {args}");

            var (exit, stdout, stderr) = await RunProcessAsync(YtDlpExe, args, ct, onProgress);

            Logger.Instance.Debug($"[DL] exit={exit}");
            Logger.Instance.Debug($"[DL] stdout:\n{stdout}");
            if (!string.IsNullOrWhiteSpace(stderr))
                Logger.Instance.Error($"[DL] stderr:\n{stderr}");

            if (exit != 0)
            {
                // Find the most informative error line to show the user
                var combined = (stderr + "\n" + stdout).Trim();
                var errLine = combined.Split('\n')
                    .Select(l => l.Trim())
                    .Where(l => l.Length > 0)
                    .LastOrDefault() ?? $"yt-dlp exited with code {exit}";
                throw new Exception($"Download failed (exit {exit}):\n{errLine}");
            }

            // 3. Find output file
            var finalPath = Directory.GetFiles(outputDir)
                .FirstOrDefault(f => Path.GetFileNameWithoutExtension(f) == uid);

            if (finalPath == null)
                throw new FileNotFoundException(
                    $"yt-dlp finished but output file not found.\nOutput:\n{stdout}");

            var fileSize = new FileInfo(finalPath).Length;
            if (fileSize < 4096)
                throw new IOException($"Output file too small ({fileSize} bytes) — likely corrupt.");

            Logger.Instance.Debug($"[DL] ✓ {Path.GetFileName(finalPath)} ({fileSize / 1024} KB)");

            // 4. Save cover art (non-fatal)
            string? coverPath = null;
            var thumbSrc = result.LocalThumbnailPath ?? result.ThumbnailUrl;
            if (!string.IsNullOrEmpty(thumbSrc))
            {
                try
                {
                    var bytes = thumbSrc.StartsWith("http", StringComparison.OrdinalIgnoreCase)
                        ? await Http.GetByteArrayAsync(thumbSrc, ct)
                        : await File.ReadAllBytesAsync(thumbSrc, ct);
                    coverPath = Path.Combine(LibraryService.Instance.CoversFolder, $"{uid}.jpg");
                    await File.WriteAllBytesAsync(coverPath, bytes, ct);
                }
                catch (Exception ex) { Logger.Instance.Debug($"[DL] cover non-fatal: {ex.Message}"); }
            }

            var song = new Song
            {
                Title = result.Title,
                Artist = result.Author,
                FilePath = finalPath,
                CoverPath = coverPath,
                ThumbnailUrl = result.ThumbnailUrl,
                Duration = result.Duration ?? TimeSpan.Zero,
                Source = SongSource.YouTube
            };

            LibraryService.Instance.Songs.Add(song);
            LibraryService.Instance.SaveLibrary();
            onProgress?.Invoke(1.0);
            Logger.Instance.Debug($"[DL] ✓ Added: {song.Title}");
            return song;
        }

        // ─────────────────────────────────────────────────────────────
        // EnsureYtDlpAsync — downloads yt-dlp.exe once (~9 MB)
        // Does NOT download ffmpeg — yt-dlp works without it for webm
        // ─────────────────────────────────────────────────────────────
        private static readonly SemaphoreSlim _setupLock = new(1, 1);

        internal static async Task EnsureYtDlpAsync(Action<string>? onStatus, CancellationToken ct)
        {
            await _setupLock.WaitAsync(ct);
            try
            {
                Directory.CreateDirectory(AppDataDir);

                // If file exists and is large enough, do a quick sanity check by running --version
                if (File.Exists(YtDlpExe) && new FileInfo(YtDlpExe).Length > 1_000_000)
                {
                    try
                    {
                        var psi = new ProcessStartInfo(YtDlpExe, "--version")
                        {
                            RedirectStandardOutput = true,
                            RedirectStandardError = true,
                            UseShellExecute = false,
                            CreateNoWindow = true
                        };
                        using var probe = Process.Start(psi)!;
                        await probe.WaitForExitAsync(ct);
                        if (probe.ExitCode == 0)
                        {
                            Logger.Instance.Info("[setup] yt-dlp already present and working");
                            return; // Good
                        }
                    }
                    catch { }

                    // Failed the sanity check — delete and redownload
                    Logger.Instance.Info("[setup] yt-dlp corrupt, deleting and redownloading...");
                    File.Delete(YtDlpExe);
                }

                onStatus?.Invoke("⬇ Downloading yt-dlp (~9 MB, one time)...");
                const string url = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe";
                Logger.Instance.Debug($"[setup] Downloading yt-dlp from {url}");

                // Download to a temp file first, then move — avoids partial writes
                var tmpPath = YtDlpExe + ".tmp";
                using var resp = await Http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, ct);
                resp.EnsureSuccessStatusCode();

                var total = resp.Content.Headers.ContentLength ?? 0;
                await using (var fs = new FileStream(tmpPath, FileMode.Create, FileAccess.Write, FileShare.None, 65536, true))
                {
                    await using var stream = await resp.Content.ReadAsStreamAsync(ct);
                    var buffer = new byte[65536];
                    long downloaded = 0;
                    int read;
                    while ((read = await stream.ReadAsync(buffer, ct)) > 0)
                    {
                        await fs.WriteAsync(buffer.AsMemory(0, read), ct);
                        downloaded += read;
                        if (total > 0)
                            onStatus?.Invoke($"⬇ yt-dlp: {downloaded * 100 / total}%...");
                    }
                }

                // Verify the downloaded file is large enough before replacing
                var tmpSize = new FileInfo(tmpPath).Length;
                if (tmpSize < 5_000_000)
                    throw new Exception($"yt-dlp download too small ({tmpSize / 1024} KB) — likely incomplete. Check your internet connection.");

                if (File.Exists(YtDlpExe)) File.Delete(YtDlpExe);
                File.Move(tmpPath, YtDlpExe);

                Logger.Instance.Debug($"[setup] yt-dlp downloaded — {new FileInfo(YtDlpExe).Length / 1024 / 1024} MB");
                onStatus?.Invoke("✓ yt-dlp ready");
            }
            finally
            {
                _setupLock.Release();
            }
        }

        // ─────────────────────────────────────────────────────────────
        // Process runner
        // ─────────────────────────────────────────────────────────────
        private static async Task<(int Exit, string Stdout, string Stderr)> RunProcessAsync(
            string exe, string args, CancellationToken ct, Action<double>? onProgress)
        {
            var psi = new ProcessStartInfo(exe, args)
            {
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };

            using var proc = new Process { StartInfo = psi };
            var sbOut = new StringBuilder();
            var sbErr = new StringBuilder();

            proc.OutputDataReceived += (_, e) =>
            {
                if (e.Data == null) return;
                sbOut.AppendLine(e.Data);
                Logger.Instance.Debug($"[yt-dlp] {e.Data}");

                // Parse "[download]  57.3% of ~4.20MiB"
                if (onProgress != null && e.Data.Contains("[download]") && e.Data.Contains('%'))
                {
                    var before = e.Data.Split('%')[0];
                    var parts = before.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    if (parts.Length > 0 && double.TryParse(parts[^1],
                            NumberStyles.Float, CultureInfo.InvariantCulture, out var pct))
                        onProgress(Math.Clamp(pct / 100.0, 0.05, 0.98));
                }
            };
            proc.ErrorDataReceived += (_, e) =>
            {
                if (e.Data == null) return;
                sbErr.AppendLine(e.Data);
                Logger.Instance.Debug($"[yt-dlp ERR] {e.Data}");
            };

            proc.Start();
            proc.BeginOutputReadLine();
            proc.BeginErrorReadLine();
            await proc.WaitForExitAsync(ct);

            return (proc.ExitCode, sbOut.ToString(), sbErr.ToString());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Search result model
    // ─────────────────────────────────────────────────────────────────────────
    public class YouTubeSearchResult : INotifyPropertyChanged
    {
        public string VideoId { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string Author { get; set; } = string.Empty;
        public TimeSpan? Duration { get; set; }
        public string ThumbnailUrl { get; set; } = string.Empty;
        public string Url { get; set; } = string.Empty;

        private string? _localThumbnailPath;
        public string? LocalThumbnailPath
        {
            get => _localThumbnailPath;
            private set { _localThumbnailPath = value; OnPropertyChanged(); OnPropertyChanged(nameof(DisplayThumbnail)); }
        }

        public string? DisplayThumbnail =>
            LocalThumbnailPath ?? (string.IsNullOrEmpty(ThumbnailUrl) ? null : ThumbnailUrl);

        public string DurationText => Duration.HasValue
            ? (Duration.Value.TotalHours >= 1
                ? Duration.Value.ToString(@"h\:mm\:ss")
                : Duration.Value.ToString(@"m\:ss"))
            : "--:--";

        public async Task LoadThumbnailAsync(CancellationToken ct = default)
        {
            if (string.IsNullOrEmpty(ThumbnailUrl) || LocalThumbnailPath != null) return;
            try
            {
                var tmpPath = Path.Combine(Path.GetTempPath(), $"tkfy_{VideoId}.jpg");
                if (!File.Exists(tmpPath))
                {
                    var bytes = await YouTubeService.Http.GetByteArrayAsync(ThumbnailUrl, ct);
                    await File.WriteAllBytesAsync(tmpPath, bytes, ct);
                }
                System.Windows.Application.Current?.Dispatcher.Invoke(() => LocalThumbnailPath = tmpPath);
            }
            catch { }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? n = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
    }
}