using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Threading;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;
using DeadFy.Models;

namespace DeadFy.Services
{
    public class AudioPlayerService : INotifyPropertyChanged, IDisposable
    {
        private static AudioPlayerService? _instance;
        public  static AudioPlayerService Instance => _instance ??= new AudioPlayerService();

        // ── NAudio pipeline ────────────────────────────────────────────────────
        private IWavePlayer?              _waveOut;
        private AudioFileReader?          _afr;
        private MediaFoundationReader?    _mfr;
        private EqualizerSampleProvider?  _eq;

        // ── Crossfade state ────────────────────────────────────────────────────
        private IWavePlayer?           _xfadeOut;      // outgoing player during crossfade
        private DispatcherTimer?       _xfadeTimer;
        private float                  _xfadeInGain  = 1f;
        private float                  _xfadeOutGain = 1f;
        private const int              XfadeStepMs   = 50;

        // ── UI / timing ────────────────────────────────────────────────────────
        private readonly DispatcherTimer _progressTimer;
        private readonly Dispatcher      _dispatcher;

        // ── State ──────────────────────────────────────────────────────────────
        private Song?       _currentSong;
        private bool        _isPlaying;
        private bool        _isStreamLoading;
        private bool        _isShuffle;
        private RepeatMode  _repeatMode;
        private float       _volume = 0.8f;

        // ── Sleep timer ────────────────────────────────────────────────────────
        private DispatcherTimer? _sleepTimer;
        private DateTime?        _sleepAt;

        // ── Volume normalisation ───────────────────────────────────────────────
        // Simple peak normaliser: read the target song's peak on a background
        // thread, then apply a gain so loudness is consistent.
        private float _normalisationGain = 1f;

        // ── Events ─────────────────────────────────────────────────────────────
        public event EventHandler<Song?>? SongChanged;
        public event EventHandler?        PlaybackEnded;

        // ── Equalizer ──────────────────────────────────────────────────────────
        public float[] EqBands { get; } = new float[10];

        // ── Properties ────────────────────────────────────────────────────────

        public Song? CurrentSong
        {
            get => _currentSong;
            private set
            {
                _currentSong = value;
                OnPropertyChanged();
                SongChanged?.Invoke(this, value);
            }
        }

        public bool IsPlaying
        {
            get => _isPlaying;
            private set { _isPlaying = value; OnPropertyChanged(); }
        }

        public bool IsStreamLoading
        {
            get => _isStreamLoading;
            private set { _isStreamLoading = value; OnPropertyChanged(); }
        }

        public bool IsShuffle
        {
            get => _isShuffle;
            set { _isShuffle = value; OnPropertyChanged(); }
        }

        public RepeatMode RepeatMode
        {
            get => _repeatMode;
            set { _repeatMode = value; OnPropertyChanged(); }
        }

        public float Volume
        {
            get => _volume;
            set
            {
                _volume = Math.Clamp(value, 0f, 1f);
                ApplyVolumeToOutputs();
                OnPropertyChanged();
            }
        }

        // ── Position / duration ────────────────────────────────────────────────

        public TimeSpan Position => _afr?.CurrentTime ?? _mfr?.CurrentTime ?? TimeSpan.Zero;
        public TimeSpan Duration => _afr?.TotalTime   ?? _mfr?.TotalTime   ?? TimeSpan.Zero;

        public double PositionSeconds
        {
            get => Position.TotalSeconds;
            set
            {
                var t = TimeSpan.FromSeconds(Math.Clamp(value, 0, Duration.TotalSeconds));
                if      (_afr != null) _afr.CurrentTime = t;
                else if (_mfr != null) _mfr.CurrentTime = t;
                OnPropertyChanged();
                OnPropertyChanged(nameof(Position));
            }
        }

        // ── Remaining time (useful for UI countdown) ───────────────────────────
        public TimeSpan Remaining => Duration - Position;

        // ── Sleep timer ────────────────────────────────────────────────────────

        public DateTime?  SleepAt        => _sleepAt;
        public TimeSpan?  SleepRemaining => _sleepAt.HasValue
            ? (_sleepAt.Value > DateTime.Now ? _sleepAt.Value - DateTime.Now : TimeSpan.Zero)
            : (TimeSpan?)null;

        /// <summary>Arm the sleep timer. Pass null to cancel.</summary>
        public void SetSleepTimer(TimeSpan? delay)
        {
            _sleepTimer?.Stop();
            _sleepTimer = null;
            _sleepAt    = null;

            if (delay == null)
            {
                OnPropertyChanged(nameof(SleepAt));
                OnPropertyChanged(nameof(SleepRemaining));
                return;
            }

            _sleepAt    = DateTime.Now.Add(delay.Value);
            _sleepTimer = new DispatcherTimer(DispatcherPriority.Background, _dispatcher)
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            _sleepTimer.Tick += (_, _) =>
            {
                OnPropertyChanged(nameof(SleepRemaining));
                if (DateTime.Now >= _sleepAt!.Value)
                {
                    _sleepTimer?.Stop();
                    _sleepTimer = null;
                    _sleepAt    = null;
                    OnPropertyChanged(nameof(SleepAt));
                    OnPropertyChanged(nameof(SleepRemaining));
                    Pause();
                    Logger.Instance.Info("Sleep timer fired — playback paused");
                }
            };
            _sleepTimer.Start();
            OnPropertyChanged(nameof(SleepAt));
            OnPropertyChanged(nameof(SleepRemaining));
        }

        // ── Constructor ────────────────────────────────────────────────────────

        private AudioPlayerService()
        {
            _dispatcher = Dispatcher.CurrentDispatcher;
            _progressTimer = new DispatcherTimer(DispatcherPriority.Background, _dispatcher)
            {
                Interval = TimeSpan.FromMilliseconds(200)    // improved from 250 ms → smoother scrubbing
            };
            _progressTimer.Tick += (_, _) =>
            {
                OnPropertyChanged(nameof(Position));
                OnPropertyChanged(nameof(PositionSeconds));
                OnPropertyChanged(nameof(Duration));
                OnPropertyChanged(nameof(Remaining));
                CheckCrossfadeTrigger();
            };
        }

        // ── Playback ───────────────────────────────────────────────────────────

        public void Play(Song song)
        {
            var crossfadeSeconds = SettingsService.Instance.Settings.CrossfadeSeconds;
            if (crossfadeSeconds > 0 && IsPlaying)
            {
                _ = PlayWithCrossfadeAsync(song, crossfadeSeconds);
                return;
            }

            Stop();
            StartSong(song);
        }

        private void StartSong(Song song)
        {
            CurrentSong = song;

            if (song.IsStreaming && !string.IsNullOrEmpty(song.StreamUrl))
            {
                _ = PlayStreamAsync(song);
                return;
            }

            // Pre-calculate normalisation gain on a background thread so playback
            // starts immediately and volume is corrected within ~100 ms.
            if (SettingsService.Instance.Settings.VolumeNormalize && !song.IsStreaming)
                _ = Task.Run(() => _normalisationGain = ComputeNormalisationGain(song.FilePath));
            else
                _normalisationGain = 1f;

            PlayFileDirect(song);
        }

        // ── Crossfade ──────────────────────────────────────────────────────────

        private async Task PlayWithCrossfadeAsync(Song next, int durationSeconds)
        {
            // Keep the current outgoing player running; start the new one at volume 0.
            var outgoingPlayer = _waveOut;
            var outgoingAfr    = _afr;
            var outgoingMfr    = _mfr;

            // Detach from the normal tracking so Stop() won't kill it yet.
            _waveOut = null;
            _afr     = null;
            _mfr     = null;

            // Assign outgoing references for the fade timer.
            _xfadeOut     = outgoingPlayer;
            _xfadeInGain  = 0f;
            _xfadeOutGain = 1f;

            CurrentSong = next;

            if (next.IsStreaming && !string.IsNullOrEmpty(next.StreamUrl))
            {
                IsStreamLoading = true;
                try
                {
                    var url = await StreamCacheService.Instance.ResolveStreamUrlAsync(
                        next.Id, next.StreamUrl!,
                        onStatus: _ => { },
                        ct: CancellationToken.None).ConfigureAwait(false);

                    _dispatcher.Invoke(() =>
                    {
                        IsStreamLoading = false;
                        if (url != null) InitUrlPlayer(next, url);
                    });
                }
                catch { _dispatcher.Invoke(() => IsStreamLoading = false); }
            }
            else
            {
                _dispatcher.Invoke(() => InitFilePlayer(next));
            }

            // Ramp both players over durationSeconds.
            int steps    = (durationSeconds * 1000) / XfadeStepMs;
            float stepSz = 1f / Math.Max(steps, 1);

            _xfadeTimer?.Stop();
            _xfadeTimer = new DispatcherTimer(DispatcherPriority.Render, _dispatcher)
            {
                Interval = TimeSpan.FromMilliseconds(XfadeStepMs)
            };
            _xfadeTimer.Tick += (_, _) =>
            {
                _xfadeInGain  = Math.Min(_xfadeInGain  + stepSz, 1f);
                _xfadeOutGain = Math.Max(_xfadeOutGain - stepSz, 0f);

                if (_waveOut != null)   _waveOut.Volume  = _volume * _xfadeInGain;
                if (_xfadeOut != null)  _xfadeOut.Volume = _volume * _xfadeOutGain;

                if (_xfadeOutGain <= 0f)
                {
                    _xfadeTimer!.Stop();
                    _xfadeOut?.Stop();
                    _xfadeOut?.Dispose();
                    _xfadeOut = null;

                    outgoingAfr?.Dispose();
                    outgoingMfr?.Dispose();

                    if (_waveOut != null) _waveOut.Volume = _volume;
                }
            };
            _xfadeTimer.Start();
        }

        /// <summary>Check if we're within crossfade range of the end and fire early.</summary>
        private void CheckCrossfadeTrigger()
        {
            int xfadeSec = SettingsService.Instance.Settings.CrossfadeSeconds;
            if (xfadeSec <= 0 || !IsPlaying || Duration == TimeSpan.Zero) return;

            if (Remaining.TotalSeconds <= xfadeSec && Remaining.TotalSeconds > 0)
            {
                // Only fire once — raise PlaybackEnded early so the VM queues the next track.
                // Guard: don't fire if we're very near the start (e.g. seeking back).
                if (Position.TotalSeconds > xfadeSec)
                {
                    // Temporarily suppress so we don't double-fire.
                    _progressTimer.Stop();
                    _dispatcher.InvokeAsync(() =>
                    {
                        PlaybackEnded?.Invoke(this, EventArgs.Empty);
                        _progressTimer.Start();
                    });
                }
            }
        }

        // ── Stream playback ────────────────────────────────────────────────────

        private async Task PlayStreamAsync(Song song)
        {
            IsStreamLoading = true;
            try
            {
                var directUrl = await StreamCacheService.Instance.ResolveStreamUrlAsync(
                    song.Id, song.StreamUrl!,
                    onStatus: _ => { },
                    ct: CancellationToken.None)
                    .ConfigureAwait(false);

                if (directUrl != null)
                {
                    _dispatcher.Invoke(() =>
                    {
                        IsStreamLoading = false;
                        InitUrlPlayer(song, directUrl);
                    });
                    return;
                }

                Logger.Instance.Warning("StreamCache: live URL failed — falling back to download");
                var localPath = await StreamCacheService.Instance.GetStreamAsync(
                    song.Id, song.StreamUrl!,
                    onProgress: _ => { },
                    ct: CancellationToken.None)
                    .ConfigureAwait(false);

                if (localPath == null)
                    throw new System.IO.FileNotFoundException("Stream download failed");

                _dispatcher.Invoke(() =>
                {
                    song.FilePath   = localPath;
                    IsStreamLoading = false;
                    PlayFileDirect(song);
                });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Stream playback error", ex);
                _dispatcher.Invoke(() => { IsStreamLoading = false; IsPlaying = false; });
            }
        }

        // ── Internal init helpers ──────────────────────────────────────────────

        private void InitUrlPlayer(Song song, string url)
        {
            try
            {
                _mfr    = new MediaFoundationReader(url);
                _waveOut = CreateWaveOut();
                _waveOut.Init(_mfr);
                _waveOut.Volume = _volume * _normalisationGain;
                _waveOut.PlaybackStopped += OnPlaybackStopped;
                _waveOut.Play();
                IsPlaying = true;
                _progressTimer.Start();
                NotifyPositionChanged();
                DiscordRpcService.Instance.UpdatePresence(song);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("InitUrlPlayer failed", ex);
                IsPlaying = false;
                StreamCacheService.Instance.InvalidateUrlCache(song.Id);
            }
        }

        // Keep legacy name for callers that pass (song, url).
        private void PlayUrlDirect(Song song, string url) => InitUrlPlayer(song, url);

        private void InitFilePlayer(Song song)
        {
            try
            {
                var ext = System.IO.Path.GetExtension(song.FilePath).ToLowerInvariant();

                if (ext is ".mp3" or ".wav" or ".flac" or ".aiff" or ".aif")
                {
                    _afr     = new AudioFileReader(song.FilePath);
                    _afr.Volume = _volume * _normalisationGain;
                    _eq      = BuildEqualizer(_afr);
                    _waveOut = CreateWaveOut();
                    _waveOut.Init(_eq);
                }
                else
                {
                    _mfr    = new MediaFoundationReader(song.FilePath);
                    _waveOut = CreateWaveOut();
                    _waveOut.Init(_mfr);
                }

                _waveOut.Volume = _volume * _normalisationGain;
                _waveOut.PlaybackStopped += OnPlaybackStopped;
                _waveOut.Play();
                IsPlaying = true;
                _progressTimer.Start();
                NotifyPositionChanged();
                DiscordRpcService.Instance.UpdatePresence(song);

                // Restore bookmark if set
                if (song.BookmarkPosition.HasValue && song.BookmarkPosition.Value < Duration)
                    PositionSeconds = song.BookmarkPosition.Value.TotalSeconds;
            }
            catch (Exception ex)
            {
                Logger.Instance.Error($"InitFilePlayer failed: {song.FilePath}", ex);
                IsPlaying = false;
            }
        }

        private void PlayFileDirect(Song song)
        {
            CurrentSong = song;
            InitFilePlayer(song);
        }

        // ── Controls ───────────────────────────────────────────────────────────

        public void Pause()
        {
            // Save bookmark position for long-form content (> 20 min).
            if (_currentSong != null && Duration.TotalMinutes > 20)
                _currentSong.BookmarkPosition = Position;

            _waveOut?.Pause();
            IsPlaying = false;
            _progressTimer.Stop();
            DiscordRpcService.Instance.SetPaused(CurrentSong);
        }

        public void Resume()
        {
            _waveOut?.Play();
            IsPlaying = true;
            _progressTimer.Start();
            DiscordRpcService.Instance.UpdatePresence(CurrentSong);
        }

        public void TogglePlayPause()
        {
            if (IsPlaying) Pause();
            else           Resume();
        }

        public void Stop()
        {
            _progressTimer.Stop();
            _xfadeTimer?.Stop();
            _xfadeTimer = null;

            // Clean up any leftover crossfade outgoing player.
            if (_xfadeOut != null)
            {
                _xfadeOut.Stop();
                _xfadeOut.Dispose();
                _xfadeOut = null;
            }

            if (_waveOut != null)
            {
                _waveOut.PlaybackStopped -= OnPlaybackStopped;
                _waveOut.Stop();
                _waveOut.Dispose();
                _waveOut = null;
            }

            _afr?.Dispose(); _afr = null;
            _mfr?.Dispose(); _mfr = null;
            _eq = null;

            IsPlaying = false;
            _normalisationGain = 1f;
            NotifyPositionChanged();
        }

        // ── Equalizer ──────────────────────────────────────────────────────────

        public void ApplyEqualizer()
        {
            if (_eq == null) return;
            ApplyEqBands(_eq);
        }

        private EqualizerSampleProvider BuildEqualizer(ISampleProvider source)
        {
            var eq = new EqualizerSampleProvider(source);
            ApplyEqBands(eq);
            return eq;
        }

        private void ApplyEqBands(EqualizerSampleProvider eq)
        {
            for (int i = 0; i < Math.Min(EqBands.Length, eq.SampleFilters.Length); i++)
                eq.SampleFilters[i].AverageGainDB = EqBands[i];
        }

        // ── Volume normalisation ───────────────────────────────────────────────

        /// <summary>
        /// Scans the file for peak sample amplitude and returns a gain factor
        /// that will bring the loudest sample to 90% of full scale.
        /// Runs on a background thread — never call from the UI thread.
        /// </summary>
        private static float ComputeNormalisationGain(string filePath)
        {
            const float targetPeak = 0.9f;
            try
            {
                using var reader = new AudioFileReader(filePath);
                float peak = 0f;
                var buf = new float[4096];
                int  read;
                while ((read = reader.Read(buf, 0, buf.Length)) > 0)
                {
                    for (int i = 0; i < read; i++)
                    {
                        float abs = Math.Abs(buf[i]);
                        if (abs > peak) peak = abs;
                    }
                }
                if (peak < 0.0001f) return 1f;
                float gain = Math.Clamp(targetPeak / peak, 0.1f, 4f);
                Logger.Instance.Debug($"[Normalise] {System.IO.Path.GetFileName(filePath)}: peak={peak:F3} gain={gain:F3}");
                return gain;
            }
            catch
            {
                return 1f;
            }
        }

        // ── Callbacks ──────────────────────────────────────────────────────────

        private void OnPlaybackStopped(object? sender, StoppedEventArgs e)
        {
            if (e.Exception != null)
                Logger.Instance.Error("NAudio playback stopped with error", e.Exception);

            _dispatcher.Invoke(() =>
            {
                IsPlaying = false;
                _progressTimer.Stop();
                PlaybackEnded?.Invoke(this, EventArgs.Empty);
            });
        }

        // ── Helpers ────────────────────────────────────────────────────────────

        private WaveOutEvent CreateWaveOut() => new()
        {
            DeviceNumber = Math.Max(-1, SettingsService.Instance.Settings.AudioDeviceIndex - 1)
        };

        private void ApplyVolumeToOutputs()
        {
            if (_afr     != null) _afr.Volume     = _volume * _normalisationGain;
            if (_waveOut != null) _waveOut.Volume  = _volume * _normalisationGain;
        }

        private void NotifyPositionChanged()
        {
            OnPropertyChanged(nameof(Duration));
            OnPropertyChanged(nameof(Position));
            OnPropertyChanged(nameof(PositionSeconds));
            OnPropertyChanged(nameof(Remaining));
        }

        // ── IDisposable ────────────────────────────────────────────────────────

        public void Dispose()
        {
            SetSleepTimer(null);
            Stop();
        }

        // ── INotifyPropertyChanged ─────────────────────────────────────────────
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    // ── Repeat mode ────────────────────────────────────────────────────────────

    public enum RepeatMode { None, All, One }

    // ── Equalizer pipeline ─────────────────────────────────────────────────────

    public class EqualizerSampleProvider : ISampleProvider
    {
        private readonly ISampleProvider _source;
        public  readonly EqualizerBand[] SampleFilters;
        public WaveFormat WaveFormat => _source.WaveFormat;

        public EqualizerSampleProvider(ISampleProvider source)
        {
            _source = source;
            // Standard 10-band frequencies (ISO 31 octave bands)
            float[] freqs = { 32, 64, 125, 250, 500, 1_000, 2_000, 4_000, 8_000, 16_000 };
            SampleFilters = new EqualizerBand[freqs.Length];
            for (int i = 0; i < freqs.Length; i++)
                SampleFilters[i] = new EqualizerBand(freqs[i], source.WaveFormat.SampleRate, source.WaveFormat.Channels);
        }

        public int Read(float[] buffer, int offset, int count)
        {
            int read = _source.Read(buffer, offset, count);
            foreach (var band in SampleFilters)
                band.Process(buffer, offset, read);
            return read;
        }
    }

    public class EqualizerBand
    {
        private readonly NAudio.Dsp.BiQuadFilter[] _filters;
        private float  _gainDb;
        private readonly float _freq;
        private readonly int   _sampleRate;
        private readonly int   _channels;

        public float AverageGainDB
        {
            get => _gainDb;
            set { _gainDb = value; Rebuild(); }
        }

        public EqualizerBand(float frequency, int sampleRate, int channels)
        {
            _freq       = frequency;
            _sampleRate = sampleRate;
            _channels   = channels;
            _filters    = new NAudio.Dsp.BiQuadFilter[channels];
            Rebuild();
        }

        private void Rebuild()
        {
            for (int c = 0; c < _channels; c++)
                _filters[c] = NAudio.Dsp.BiQuadFilter.PeakingEQ(_sampleRate, _freq, 0.8f, _gainDb);
        }

        public void Process(float[] buffer, int offset, int count)
        {
            for (int i = offset; i < offset + count; i++)
                buffer[i] = _filters[(i - offset) % _channels].Transform(buffer[i]);
        }
    }
}
