using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Threading;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;
using DeadFy.Models;

namespace DeadFy.Services
{
    public class AudioPlayerService : INotifyPropertyChanged, IDisposable
    {
        private static AudioPlayerService? _instance;
        public  static AudioPlayerService Instance => _instance ??= new AudioPlayerService();

        // ── NAudio pipeline ───────────────────────────────────────────────────
        private IWavePlayer?              _waveOut;
        private AudioFileReader?          _afr;
        private MediaFoundationReader?    _mfr;
        private EqualizerSampleProvider?  _eq;

        // ── UI / timing ───────────────────────────────────────────────────────
        private readonly DispatcherTimer _progressTimer;
        private readonly Dispatcher      _dispatcher;

        // ── State ─────────────────────────────────────────────────────────────
        private Song?       _currentSong;
        private bool        _isPlaying;
        private bool        _isStreamLoading;
        private bool        _isShuffle;
        private RepeatMode  _repeatMode;
        private float       _volume = 0.8f;

        // ── Sleep timer ───────────────────────────────────────────────────────
        private DispatcherTimer? _sleepTimer;
        private DateTime?        _sleepAt;

        // ── Events ────────────────────────────────────────────────────────────
        public event EventHandler<Song?>? SongChanged;
        public event EventHandler?        PlaybackEnded;

        // ── Equalizer ─────────────────────────────────────────────────────────
        public float[] EqBands { get; } = new float[10];

        // ── Properties ───────────────────────────────────────────────────────

        public Song? CurrentSong
        {
            get => _currentSong;
            private set
            {
                _currentSong = value;
                OnPropertyChanged();
                SongChanged?.Invoke(this, value);
            }
        }

        public bool IsPlaying
        {
            get => _isPlaying;
            private set { _isPlaying = value; OnPropertyChanged(); }
        }

        public bool IsStreamLoading
        {
            get => _isStreamLoading;
            private set { _isStreamLoading = value; OnPropertyChanged(); }
        }

        public bool IsShuffle
        {
            get => _isShuffle;
            set { _isShuffle = value; OnPropertyChanged(); }
        }

        public RepeatMode RepeatMode
        {
            get => _repeatMode;
            set { _repeatMode = value; OnPropertyChanged(); }
        }

        public float Volume
        {
            get => _volume;
            set
            {
                _volume = Math.Clamp(value, 0f, 1f);
                if (_afr     != null) _afr.Volume     = _volume;
                if (_waveOut != null) _waveOut.Volume = _volume;
                OnPropertyChanged();
            }
        }

        // ── Position / duration ───────────────────────────────────────────────

        public TimeSpan Position => _afr?.CurrentTime ?? _mfr?.CurrentTime ?? TimeSpan.Zero;
        public TimeSpan Duration => _afr?.TotalTime   ?? _mfr?.TotalTime   ?? TimeSpan.Zero;

        public double PositionSeconds
        {
            get => Position.TotalSeconds;
            set
            {
                var t = TimeSpan.FromSeconds(Math.Clamp(value, 0, Duration.TotalSeconds));
                if      (_afr != null) _afr.CurrentTime = t;
                else if (_mfr != null) _mfr.CurrentTime = t;
                OnPropertyChanged();
                OnPropertyChanged(nameof(Position));
            }
        }

        // ── Sleep timer ───────────────────────────────────────────────────────

        public DateTime?  SleepAt        => _sleepAt;
        public TimeSpan?  SleepRemaining => _sleepAt.HasValue
            ? (_sleepAt.Value > DateTime.Now ? _sleepAt.Value - DateTime.Now : TimeSpan.Zero)
            : (TimeSpan?)null;

        /// <summary>Arm the sleep timer. Pass null to cancel.</summary>
        public void SetSleepTimer(TimeSpan? delay)
        {
            _sleepTimer?.Stop();
            _sleepTimer = null;
            _sleepAt    = null;

            if (delay == null)
            {
                OnPropertyChanged(nameof(SleepAt));
                OnPropertyChanged(nameof(SleepRemaining));
                return;
            }

            _sleepAt    = DateTime.Now.Add(delay.Value);
            _sleepTimer = new DispatcherTimer(DispatcherPriority.Background, _dispatcher)
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            _sleepTimer.Tick += (_, _) =>
            {
                OnPropertyChanged(nameof(SleepRemaining));
                if (DateTime.Now >= _sleepAt!.Value)
                {
                    _sleepTimer?.Stop();
                    _sleepTimer = null;
                    _sleepAt    = null;
                    OnPropertyChanged(nameof(SleepAt));
                    OnPropertyChanged(nameof(SleepRemaining));
                    Pause();
                    Logger.Instance.Info("Sleep timer fired — playback paused");
                }
            };
            _sleepTimer.Start();
            OnPropertyChanged(nameof(SleepAt));
            OnPropertyChanged(nameof(SleepRemaining));
        }

        // ── Constructor ───────────────────────────────────────────────────────

        private AudioPlayerService()
        {
            _dispatcher = Dispatcher.CurrentDispatcher;
            _progressTimer = new DispatcherTimer(DispatcherPriority.Background, _dispatcher)
            {
                Interval = TimeSpan.FromMilliseconds(250)
            };
            _progressTimer.Tick += (_, _) =>
            {
                OnPropertyChanged(nameof(Position));
                OnPropertyChanged(nameof(PositionSeconds));
                OnPropertyChanged(nameof(Duration));
            };
        }

        // ── Playback ──────────────────────────────────────────────────────────

        public void Play(Song song)
        {
            Stop();
            CurrentSong = song;

            if (song.IsStreaming && !string.IsNullOrEmpty(song.StreamUrl))
            {
                _ = PlayStreamAsync(song);
                return;
            }

            PlayFileDirect(song);
        }

        private async System.Threading.Tasks.Task PlayStreamAsync(Song song)
        {
            IsStreamLoading = true;
            try
            {
                // Fast path: resolve a live CDN URL (~0.5–1 s), no local file needed.
                var directUrl = await StreamCacheService.Instance.ResolveStreamUrlAsync(
                    song.Id, song.StreamUrl!,
                    onStatus: _ => { },
                    ct: System.Threading.CancellationToken.None)
                    .ConfigureAwait(false);

                if (directUrl != null)
                {
                    _dispatcher.Invoke(() =>
                    {
                        IsStreamLoading = false;
                        PlayUrlDirect(song, directUrl);
                    });
                    return;
                }

                // Fallback: download to disk cache.
                Logger.Instance.Warning("StreamCache: live URL failed — falling back to download");
                var localPath = await StreamCacheService.Instance.GetStreamAsync(
                    song.Id, song.StreamUrl!,
                    onProgress: _ => { },
                    ct: System.Threading.CancellationToken.None)
                    .ConfigureAwait(false);

                if (localPath == null)
                    throw new System.IO.FileNotFoundException("Stream download failed");

                _dispatcher.Invoke(() =>
                {
                    song.FilePath   = localPath;
                    IsStreamLoading = false;
                    PlayFileDirect(song);
                });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Stream playback error", ex);
                _dispatcher.Invoke(() => { IsStreamLoading = false; IsPlaying = false; });
            }
        }

        /// <summary>Play directly from a live HTTP URL (no local file).</summary>
        private void PlayUrlDirect(Song song, string url)
        {
            CurrentSong = song;
            try
            {
                _mfr = new MediaFoundationReader(url);
                _waveOut = CreateWaveOut();
                _waveOut.Init(_mfr);
                _waveOut.Volume = _volume;
                _waveOut.PlaybackStopped += OnPlaybackStopped;
                _waveOut.Play();
                IsPlaying = true;
                _progressTimer.Start();
                NotifyPositionChanged();
                DiscordRpcService.Instance.UpdatePresence(song);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("PlayUrlDirect failed", ex);
                IsPlaying = false;
                // Invalidate so next attempt re-resolves the CDN URL.
                StreamCacheService.Instance.InvalidateUrlCache(song.Id);
            }
        }

        private void PlayFileDirect(Song song)
        {
            CurrentSong = song;
            try
            {
                var ext = System.IO.Path.GetExtension(song.FilePath).ToLowerInvariant();

                if (ext is ".mp3" or ".wav" or ".flac" or ".aiff" or ".aif")
                {
                    _afr    = new AudioFileReader(song.FilePath) { Volume = _volume };
                    _eq     = BuildEqualizer(_afr);
                    _waveOut = CreateWaveOut();
                    _waveOut.Init(_eq);
                }
                else
                {
                    _mfr    = new MediaFoundationReader(song.FilePath);
                    _waveOut = CreateWaveOut();
                    _waveOut.Init(_mfr);
                }

                _waveOut.Volume = _volume;
                _waveOut.PlaybackStopped += OnPlaybackStopped;
                _waveOut.Play();
                IsPlaying = true;
                _progressTimer.Start();
                NotifyPositionChanged();
                DiscordRpcService.Instance.UpdatePresence(song);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error($"PlayFileDirect failed: {song.FilePath}", ex);
                IsPlaying = false;
            }
        }

        // ── Controls ──────────────────────────────────────────────────────────

        public void Pause()
        {
            _waveOut?.Pause();
            IsPlaying = false;
            _progressTimer.Stop();
            DiscordRpcService.Instance.SetPaused(CurrentSong);
        }

        public void Resume()
        {
            _waveOut?.Play();
            IsPlaying = true;
            _progressTimer.Start();
            DiscordRpcService.Instance.UpdatePresence(CurrentSong);
        }

        public void TogglePlayPause()
        {
            if (IsPlaying) Pause();
            else           Resume();
        }

        public void Stop()
        {
            _progressTimer.Stop();

            if (_waveOut != null)
            {
                _waveOut.PlaybackStopped -= OnPlaybackStopped;
                _waveOut.Stop();
                _waveOut.Dispose();
                _waveOut = null;
            }

            _afr?.Dispose(); _afr = null;
            _mfr?.Dispose(); _mfr = null;
            _eq = null;

            IsPlaying = false;
            NotifyPositionChanged();
        }

        // ── Equalizer ─────────────────────────────────────────────────────────

        public void ApplyEqualizer()
        {
            if (_eq == null) return;
            ApplyEqBands(_eq);
        }

        private EqualizerSampleProvider BuildEqualizer(ISampleProvider source)
        {
            var eq = new EqualizerSampleProvider(source);
            ApplyEqBands(eq);
            return eq;
        }

        private void ApplyEqBands(EqualizerSampleProvider eq)
        {
            for (int i = 0; i < Math.Min(EqBands.Length, eq.SampleFilters.Length); i++)
                eq.SampleFilters[i].AverageGainDB = EqBands[i];
        }

        // ── Callbacks ─────────────────────────────────────────────────────────

        private void OnPlaybackStopped(object? sender, StoppedEventArgs e)
        {
            if (e.Exception != null)
                Logger.Instance.Error("NAudio playback stopped with error", e.Exception);

            _dispatcher.Invoke(() =>
            {
                IsPlaying = false;
                _progressTimer.Stop();
                PlaybackEnded?.Invoke(this, EventArgs.Empty);
            });
        }

        // ── Helpers ───────────────────────────────────────────────────────────

        private WaveOutEvent CreateWaveOut() => new()
        {
            DeviceNumber = Math.Max(-1, SettingsService.Instance.Settings.AudioDeviceIndex - 1)
        };

        private void NotifyPositionChanged()
        {
            OnPropertyChanged(nameof(Duration));
            OnPropertyChanged(nameof(Position));
            OnPropertyChanged(nameof(PositionSeconds));
        }

        // ── IDisposable ───────────────────────────────────────────────────────

        public void Dispose()
        {
            SetSleepTimer(null);
            Stop();
        }

        // ── INotifyPropertyChanged ────────────────────────────────────────────
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    // ── Repeat mode ───────────────────────────────────────────────────────────

    public enum RepeatMode { None, All, One }

    // ── Equalizer pipeline ────────────────────────────────────────────────────

    public class EqualizerSampleProvider : ISampleProvider
    {
        private readonly ISampleProvider _source;
        public  readonly EqualizerBand[] SampleFilters;
        public WaveFormat WaveFormat => _source.WaveFormat;

        public EqualizerSampleProvider(ISampleProvider source)
        {
            _source = source;
            float[] freqs = { 60, 170, 310, 600, 1_000, 3_000, 6_000, 12_000, 14_000, 16_000 };
            SampleFilters = new EqualizerBand[freqs.Length];
            for (int i = 0; i < freqs.Length; i++)
                SampleFilters[i] = new EqualizerBand(freqs[i], source.WaveFormat.SampleRate, source.WaveFormat.Channels);
        }

        public int Read(float[] buffer, int offset, int count)
        {
            int read = _source.Read(buffer, offset, count);
            foreach (var band in SampleFilters)
                band.Process(buffer, offset, read);
            return read;
        }
    }

    public class EqualizerBand
    {
        private readonly NAudio.Dsp.BiQuadFilter[] _filters;
        private float  _gainDb;
        private readonly float _freq;
        private readonly int   _sampleRate;
        private readonly int   _channels;

        public float AverageGainDB
        {
            get => _gainDb;
            set { _gainDb = value; Rebuild(); }
        }

        public EqualizerBand(float frequency, int sampleRate, int channels)
        {
            _freq       = frequency;
            _sampleRate = sampleRate;
            _channels   = channels;
            _filters    = new NAudio.Dsp.BiQuadFilter[channels];
            Rebuild();
        }

        private void Rebuild()
        {
            for (int c = 0; c < _channels; c++)
                _filters[c] = NAudio.Dsp.BiQuadFilter.PeakingEQ(_sampleRate, _freq, 0.8f, _gainDb);
        }

        public void Process(float[] buffer, int offset, int count)
        {
            for (int i = offset; i < offset + count; i++)
                buffer[i] = _filters[(i - offset) % _channels].Transform(buffer[i]);
        }
    }
}
