using System;
using System.Diagnostics;
using System.Runtime;
using System.Threading;

namespace DeadFy.Services
{
    /// <summary>
    /// Apply low-level runtime optimisations once at startup, before the main
    /// window is shown.  Call <see cref="Apply"/> from App.OnStartup.
    /// </summary>
    public static class AppOptimizer
    {
        public static void Apply()
        {
            SetProcessPriority();
            ConfigureGarbageCollector();
            ConfigureThreadPool();
        }

        // ── Process priority ──────────────────────────────────────────────────
        private static void SetProcessPriority()
        {
            try
            {
                // AboveNormal keeps the UI responsive without starving the OS.
                // Never use Realtime — it can lock out system audio drivers.
                Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.AboveNormal;
            }
            catch
            {
                // Restricted on some locked-down machines — safe to swallow.
            }
        }

        // ── Garbage collector ─────────────────────────────────────────────────
        private static void ConfigureGarbageCollector()
        {
            try
            {
                // Interactive mode: GC still runs Gen2 collections but tries to
                // minimise pause duration — ideal for audio + UI apps.
                GCSettings.LatencyMode = GCLatencyMode.Interactive;
            }
            catch (InvalidOperationException)
            {
                // Server GC builds don't allow changing LatencyMode — ignore.
            }
        }

        // ── Thread pool ───────────────────────────────────────────────────────
        private static void ConfigureThreadPool()
        {
            // Pre-warm the thread pool to avoid the 500 ms injection delay that
            // causes jank on the first burst of async streaming operations.
            ThreadPool.GetMinThreads(out int workerMin, out int ioMin);
            int target = Math.Max(workerMin, Environment.ProcessorCount * 2);
            ThreadPool.SetMinThreads(target, ioMin);
        }
    }
}
