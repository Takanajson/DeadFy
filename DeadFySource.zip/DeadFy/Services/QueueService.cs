using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using DeadFy.Models;

namespace DeadFy.Services
{
    /// <summary>
    /// Manages a play queue separate from the main library.
    /// Supports: enqueue, play-next, clear, reorder, shuffle, history.
    /// </summary>
    public class QueueService : INotifyPropertyChanged
    {
        private static QueueService? _instance;
        public  static QueueService Instance => _instance ??= new QueueService();

        // ── State ─────────────────────────────────────────────────────────────

        /// <summary>The upcoming song list (not including the currently playing song).</summary>
        public ObservableCollection<Song> Queue { get; } = new();

        // Circular history buffer — most-recent at the end.
        private readonly List<Song> _history = new();
        private const int MaxHistory = 200;

        public IReadOnlyList<Song> History => _history;

        private readonly Random _rng = new();

        private QueueService() { }

        // ── Enqueue ───────────────────────────────────────────────────────────

        /// <summary>Append a song to the end of the queue.</summary>
        public void Enqueue(Song song)
        {
            Queue.Add(song);
            NotifyCount();
        }

        /// <summary>Insert a song as the very next track (front of the queue).</summary>
        public void PlayNext(Song song)
        {
            Queue.Insert(0, song);
            NotifyCount();
        }

        /// <summary>Append multiple songs to the end of the queue.</summary>
        public void EnqueueRange(IEnumerable<Song> songs)
        {
            foreach (var s in songs) Queue.Add(s);
            NotifyCount();
        }

        // ── Dequeue ───────────────────────────────────────────────────────────

        /// <summary>
        /// Pull the next song from the explicit queue.
        /// If the queue is empty, uses the library + shuffle/repeat policy.
        /// Returns null when there is nothing to play.
        /// </summary>
        public Song? Dequeue(
            IReadOnlyList<Song> library,
            Song? current,
            bool shuffle,
            RepeatMode repeat)
        {
            // Explicit queue always wins.
            if (Queue.Count > 0)
            {
                var next = Queue[0];
                Queue.RemoveAt(0);
                NotifyCount();
                return next;
            }

            if (library.Count == 0) return null;

            // Repeat One: replay the same track.
            if (repeat == RepeatMode.One && current != null) return current;

            // Shuffle: pick a random track, avoiding immediate repeat when possible.
            if (shuffle)
            {
                if (library.Count == 1) return library[0];
                Song? pick;
                int attempts = 0;
                do { pick = library[_rng.Next(library.Count)]; }
                while (pick == current && ++attempts < 10);
                return pick;
            }

            // Sequential playback.
            if (current == null) return library[0];

            int idx = IndexOf(library, current);
            if (idx < 0) return library[0];

            int nextIdx = idx + 1;
            if (nextIdx >= library.Count)
                return repeat == RepeatMode.All ? library[0] : null;

            return library[nextIdx];
        }

        /// <summary>
        /// Pop from history to go back, or step backward in the library.
        /// </summary>
        public Song? DequeuePrevious(IReadOnlyList<Song> library, Song? current)
        {
            if (_history.Count > 0)
            {
                var prev = _history[^1];
                _history.RemoveAt(_history.Count - 1);
                return prev;
            }

            if (library.Count == 0 || current == null) return null;

            int idx = IndexOf(library, current);
            return idx > 0 ? library[idx - 1] : library[^1];
        }

        // ── History ───────────────────────────────────────────────────────────

        public void PushHistory(Song song)
        {
            if (_history.Count >= MaxHistory)
                _history.RemoveAt(0);
            _history.Add(song);
        }

        public void ClearHistory() => _history.Clear();

        // ── Management ────────────────────────────────────────────────────────

        public void Remove(Song song)
        {
            Queue.Remove(song);
            NotifyCount();
        }

        public void MoveUp(Song song)
        {
            int idx = Queue.IndexOf(song);
            if (idx > 0) Queue.Move(idx, idx - 1);
        }

        public void MoveDown(Song song)
        {
            int idx = Queue.IndexOf(song);
            if (idx >= 0 && idx < Queue.Count - 1) Queue.Move(idx, idx + 1);
        }

        /// <summary>Fisher-Yates shuffle of the current queue.</summary>
        public void Shuffle()
        {
            var list = Queue.ToList();
            for (int i = list.Count - 1; i > 0; i--)
            {
                int j = _rng.Next(i + 1);
                (list[i], list[j]) = (list[j], list[i]);
            }
            Queue.Clear();
            foreach (var s in list) Queue.Add(s);
        }

        public void Clear()
        {
            Queue.Clear();
            NotifyCount();
        }

        // ── Properties ────────────────────────────────────────────────────────

        public int Count => Queue.Count;

        public bool IsEmpty => Queue.Count == 0;

        // ── Helpers ───────────────────────────────────────────────────────────

        private void NotifyCount()
        {
            OnPropertyChanged(nameof(Count));
            OnPropertyChanged(nameof(IsEmpty));
        }

        private static int IndexOf<T>(IReadOnlyList<T> list, T item)
        {
            for (int i = 0; i < list.Count; i++)
                if (EqualityComparer<T>.Default.Equals(list[i], item)) return i;
            return -1;
        }

        // ── INotifyPropertyChanged ────────────────────────────────────────────
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
