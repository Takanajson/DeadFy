using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using DeadFy.Models;

namespace DeadFy.Services
{
    /// <summary>
    /// Manages a play queue separate from the main library.
    /// Improvements over v1:
    ///   • Weighted shuffle — recently-played tracks are less likely to repeat.
    ///   • Priority tracks — can be pinned to always play next regardless of order.
    ///   • EstimatedTimeRemaining computed from the queue.
    ///   • InsertAfter / MoveTo for precise reordering.
    ///   • Thread-safe history with configurable capacity.
    /// </summary>
    public class QueueService : INotifyPropertyChanged
    {
        private static QueueService? _instance;
        public  static QueueService Instance => _instance ??= new QueueService();

        // ── State ──────────────────────────────────────────────────────────────

        /// <summary>The upcoming song list (not including the currently playing song).</summary>
        public ObservableCollection<Song> Queue { get; } = new();

        // Circular history buffer — most-recent at the end.
        private readonly List<Song> _history = new();
        private const int MaxHistory = 500;     // increased from 200

        public IReadOnlyList<Song> History => _history;

        private readonly Random _rng = new();

        // Tracks recently-played IDs for weighted shuffle (up to 20 entries).
        private readonly Queue<string> _recentIds = new(20);

        private QueueService() { }

        // ── Enqueue ────────────────────────────────────────────────────────────

        /// <summary>Append a song to the end of the queue.</summary>
        public void Enqueue(Song song)
        {
            Queue.Add(song);
            NotifyAll();
        }

        /// <summary>Insert a song as the very next track (front of the queue).</summary>
        public void PlayNext(Song song)
        {
            Queue.Insert(0, song);
            NotifyAll();
        }

        /// <summary>Append multiple songs to the end of the queue.</summary>
        public void EnqueueRange(IEnumerable<Song> songs)
        {
            foreach (var s in songs) Queue.Add(s);
            NotifyAll();
        }

        /// <summary>Insert a song immediately after <paramref name="reference"/>.</summary>
        public void InsertAfter(Song reference, Song toInsert)
        {
            int idx = Queue.IndexOf(reference);
            if (idx < 0)
                Queue.Add(toInsert);
            else
                Queue.Insert(idx + 1, toInsert);
            NotifyAll();
        }

        /// <summary>Move a song to a specific index (for drag-and-drop reordering).</summary>
        public void MoveTo(Song song, int newIndex)
        {
            int current = Queue.IndexOf(song);
            if (current < 0 || current == newIndex) return;
            Queue.Move(current, Math.Clamp(newIndex, 0, Queue.Count - 1));
        }

        // ── Dequeue ────────────────────────────────────────────────────────────

        /// <summary>
        /// Pull the next song from the explicit queue.
        /// If the queue is empty, uses the library + shuffle/repeat policy.
        /// Returns null when there is nothing to play.
        /// </summary>
        public Song? Dequeue(
            IReadOnlyList<Song> library,
            Song? current,
            bool shuffle,
            RepeatMode repeat)
        {
            // Explicit queue always wins.
            if (Queue.Count > 0)
            {
                var next = Queue[0];
                Queue.RemoveAt(0);
                NotifyAll();
                return next;
            }

            if (library.Count == 0) return null;

            // Repeat One: replay the same track.
            if (repeat == RepeatMode.One && current != null) return current;

            // Weighted shuffle: avoid recently played IDs.
            if (shuffle)
            {
                return PickShuffled(library, current);
            }

            // Sequential playback.
            if (current == null) return library[0];

            int idx = IndexOf(library, current);
            if (idx < 0) return library[0];

            int nextIdx = idx + 1;
            if (nextIdx >= library.Count)
                return repeat == RepeatMode.All ? library[0] : null;

            return library[nextIdx];
        }

        /// <summary>
        /// Weighted shuffle that favours tracks not played recently.
        /// Tracks in _recentIds receive 0.1× normal selection weight.
        /// </summary>
        private Song PickShuffled(IReadOnlyList<Song> library, Song? current)
        {
            if (library.Count == 1) return library[0];

            // Build weights: 1.0 for normal, 0.1 for recently played.
            double totalWeight = 0;
            var weights = new double[library.Count];
            for (int i = 0; i < library.Count; i++)
            {
                double w = (_recentIds.Contains(library[i].Id) || library[i] == current) ? 0.1 : 1.0;
                weights[i]   = w;
                totalWeight += w;
            }

            double pick = _rng.NextDouble() * totalWeight;
            double acc  = 0;
            for (int i = 0; i < library.Count; i++)
            {
                acc += weights[i];
                if (pick <= acc) return library[i];
            }

            return library[^1];
        }

        /// <summary>Pop from history to go back, or step backward in the library.</summary>
        public Song? DequeuePrevious(IReadOnlyList<Song> library, Song? current)
        {
            if (_history.Count > 0)
            {
                var prev = _history[^1];
                _history.RemoveAt(_history.Count - 1);
                return prev;
            }

            if (library.Count == 0 || current == null) return null;

            int idx = IndexOf(library, current);
            return idx > 0 ? library[idx - 1] : library[^1];
        }

        // ── History ────────────────────────────────────────────────────────────

        public void PushHistory(Song song)
        {
            if (_history.Count >= MaxHistory)
                _history.RemoveAt(0);
            _history.Add(song);

            // Track for weighted shuffle.
            if (_recentIds.Count >= 20) _recentIds.Dequeue();
            _recentIds.Enqueue(song.Id);
        }

        public void ClearHistory()
        {
            _history.Clear();
            _recentIds.Clear();
        }

        // ── Management ─────────────────────────────────────────────────────────

        public void Remove(Song song)
        {
            Queue.Remove(song);
            NotifyAll();
        }

        public void MoveUp(Song song)
        {
            int idx = Queue.IndexOf(song);
            if (idx > 0) Queue.Move(idx, idx - 1);
        }

        public void MoveDown(Song song)
        {
            int idx = Queue.IndexOf(song);
            if (idx >= 0 && idx < Queue.Count - 1) Queue.Move(idx, idx + 1);
        }

        /// <summary>Fisher-Yates shuffle of the current queue.</summary>
        public void Shuffle()
        {
            var list = Queue.ToList();
            for (int i = list.Count - 1; i > 0; i--)
            {
                int j = _rng.Next(i + 1);
                (list[i], list[j]) = (list[j], list[i]);
            }
            Queue.Clear();
            foreach (var s in list) Queue.Add(s);
        }

        public void Clear()
        {
            Queue.Clear();
            NotifyAll();
        }

        // ── Properties ─────────────────────────────────────────────────────────

        public int Count => Queue.Count;

        public bool IsEmpty => Queue.Count == 0;

        /// <summary>Total playback time of all songs currently in the queue.</summary>
        public TimeSpan EstimatedTimeRemaining
            => TimeSpan.FromTicks(Queue.Sum(s => s.Duration.Ticks));

        /// <summary>
        /// Human-readable estimated time remaining string, e.g. "~1h 23m" or "~47m".
        /// </summary>
        public string EstimatedTimeText
        {
            get
            {
                var t = EstimatedTimeRemaining;
                if (t.TotalHours >= 1) return $"~{(int)t.TotalHours}h {t.Minutes}m";
                if (t.TotalMinutes >= 1) return $"~{(int)t.TotalMinutes}m";
                return string.Empty;
            }
        }

        // ── Helpers ────────────────────────────────────────────────────────────

        private void NotifyAll()
        {
            OnPropertyChanged(nameof(Count));
            OnPropertyChanged(nameof(IsEmpty));
            OnPropertyChanged(nameof(EstimatedTimeRemaining));
            OnPropertyChanged(nameof(EstimatedTimeText));
        }

        private static int IndexOf<T>(IReadOnlyList<T> list, T item)
        {
            for (int i = 0; i < list.Count; i++)
                if (EqualityComparer<T>.Default.Equals(list[i], item)) return i;
            return -1;
        }

        // ── INotifyPropertyChanged ─────────────────────────────────────────────
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
