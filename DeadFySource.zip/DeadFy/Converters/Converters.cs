using System;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DeadFy.Converters
{
    // ── Shared frozen brushes (allocated once, thread-safe) ───────────────────
    internal static class ConverterBrushes
    {
        public static readonly SolidColorBrush Active;
        public static readonly SolidColorBrush Inactive;

        static ConverterBrushes()
        {
            Active   = new SolidColorBrush(Colors.White);
            Inactive = new SolidColorBrush(Color.FromRgb(0x9A, 0x98, 0xAA));
            Active.Freeze();
            Inactive.Freeze();
        }
    }

    // ── Playback controls ──────────────────────────────────────────────────────

    /// <summary>bool IsPlaying → ⏸ / ▶</summary>
    public class BoolToPlayPauseConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
            => value is true ? "⏸" : "▶";
        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    /// <summary>RepeatMode → ↺¹ when One, ↻ otherwise</summary>
    public class RepeatModeToIconConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
            => value is Services.RepeatMode.One ? "↺¹" : "↻";
        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    // ── Visibility ─────────────────────────────────────────────────────────────

    /// <summary>bool true / non-null → Visible; bool false / null → Collapsed.</summary>
    public class NullToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
        {
            if (value is bool b) return b ? Visibility.Visible : Visibility.Collapsed;
            return value != null ? Visibility.Visible : Visibility.Collapsed;
        }
        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    /// <summary>Inverse: false / null → Visible; true / non-null → Collapsed.</summary>
    public class InverseBoolVisConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
        {
            if (value is bool b) return b ? Visibility.Collapsed : Visibility.Visible;
            return Visibility.Visible;
        }
        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    /// <summary>int > 0 → Visible; 0 → Collapsed. Useful for play counts, ratings.</summary>
    public class PositiveIntToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
            => value is int i && i > 0 ? Visibility.Visible : Visibility.Collapsed;
        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    // ── Colour ─────────────────────────────────────────────────────────────────

    /// <summary>bool true → White, false → muted grey (shuffle / active state)</summary>
    public class BoolToColorConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
            => value is true ? ConverterBrushes.Active : ConverterBrushes.Inactive;
        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    /// <summary>RepeatMode != None → White, None → muted grey</summary>
    public class RepeatModeToColorConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
            => value is Services.RepeatMode mode && mode != Services.RepeatMode.None
                ? ConverterBrushes.Active
                : ConverterBrushes.Inactive;
        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    // ── Images ─────────────────────────────────────────────────────────────────

    /// <summary>
    /// Converts a local file path or HTTP(S) URL to a BitmapImage.
    /// Local files are loaded synchronously and frozen (thread-safe).
    /// Remote URLs are decoded asynchronously by WPF's built-in infrastructure.
    /// Returns a cached BitmapImage for local paths that were loaded previously.
    /// </summary>
    public class StringToImageConverter : IValueConverter
    {
        // Small LRU-style in-memory cache to avoid reloading the same cover 50×.
        private static readonly System.Collections.Concurrent.ConcurrentDictionary<string, BitmapImage>
            _cache = new(StringComparer.OrdinalIgnoreCase);

        public object? Convert(object value, Type t, object p, CultureInfo c)
        {
            if (value is not string path || string.IsNullOrWhiteSpace(path))
                return null;

            try
            {
                if (!path.StartsWith("http", StringComparison.OrdinalIgnoreCase))
                {
                    if (!File.Exists(path)) return null;

                    return _cache.GetOrAdd(path, key =>
                    {
                        var bmp = new BitmapImage();
                        bmp.BeginInit();
                        bmp.CacheOption   = BitmapCacheOption.OnLoad;
                        bmp.CreateOptions = BitmapCreateOptions.IgnoreColorProfile;
                        bmp.UriSource     = new Uri(key, UriKind.Absolute);
                        // Constrain decode size to 256 px to keep memory low.
                        bmp.DecodePixelWidth = 256;
                        bmp.EndInit();
                        bmp.Freeze();
                        return bmp;
                    });
                }

                var webBmp = new BitmapImage();
                webBmp.BeginInit();
                webBmp.CreateOptions = BitmapCreateOptions.IgnoreColorProfile;
                webBmp.UriSource     = new Uri(path, UriKind.Absolute);
                webBmp.EndInit();
                return webBmp;
            }
            catch { return null; }
        }

        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();

        /// <summary>Call when a cover file is replaced so the old cached bitmap is evicted.</summary>
        public static void InvalidateCache(string path) => _cache.TryRemove(path, out _);
    }

    // ── Time ───────────────────────────────────────────────────────────────────

    /// <summary>TimeSpan ↔ double seconds (for progress Slider two-way binding)</summary>
    public class TimeSpanToDoubleConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
            => value is TimeSpan ts ? ts.TotalSeconds : 0.0;

        public object ConvertBack(object value, Type t, object p, CultureInfo c)
            => value is double d ? TimeSpan.FromSeconds(d) : TimeSpan.Zero;
    }

    /// <summary>double seconds → "m:ss" or "h:mm:ss" display string</summary>
    public class SecondsToTimeStringConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
        {
            if (value is not double s) return "0:00";
            var ts = TimeSpan.FromSeconds(s);
            return ts.TotalHours >= 1
                ? ts.ToString(@"h\:mm\:ss")
                : ts.ToString(@"m\:ss");
        }

        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    /// <summary>
    /// TimeSpan remaining → "-m:ss" countdown string (e.g. "-3:12").
    /// Useful for showing remaining time next to the seek bar.
    /// </summary>
    public class RemainingTimeConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
        {
            if (value is not TimeSpan ts || ts <= TimeSpan.Zero) return "-0:00";
            return ts.TotalHours >= 1
                ? "-" + ts.ToString(@"h\:mm\:ss")
                : "-" + ts.ToString(@"m\:ss");
        }

        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    // ── Rating ─────────────────────────────────────────────────────────────────

    /// <summary>
    /// int 0–5 → star string "★★★☆☆".
    /// ConverterParameter can be "compact" to return just "3★" for narrow columns.
    /// </summary>
    public class RatingToStarsConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
        {
            if (value is not int rating) return string.Empty;
            if (rating == 0) return string.Empty;

            bool compact = p is string s && s == "compact";
            if (compact) return $"{rating}★";

            return new string('★', rating) + new string('☆', 5 - rating);
        }

        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    // ── Numbers ────────────────────────────────────────────────────────────────

    /// <summary>
    /// long view count → human-readable string: 1.4M, 342K, 5.
    /// Used in the YouTube search results list.
    /// </summary>
    public class ViewCountConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
        {
            if (value is not long v || v <= 0) return string.Empty;
            if (v >= 1_000_000) return $"{v / 1_000_000.0:F1}M";
            if (v >= 1_000)     return $"{v / 1_000.0:F0}K";
            return v.ToString();
        }

        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    /// <summary>long bytes → human-readable "42.3 MB" / "1.1 GB".</summary>
    public class BytesToHumanConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
        {
            if (value is not long bytes) return string.Empty;
            double mb = bytes / (1024.0 * 1024.0);
            return mb >= 1024 ? $"{mb / 1024.0:F1} GB" : $"{mb:F1} MB";
        }

        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    // ── Source badge ───────────────────────────────────────────────────────────

    /// <summary>
    /// Maps SongSource enum → accent-brush colour so each badge has a distinct tint.
    /// Returns a frozen SolidColorBrush.
    /// </summary>
    public class SourceBadgeColorConverter : IValueConverter
    {
        private static readonly SolidColorBrush YouTube;
        private static readonly SolidColorBrush Spotify;
        private static readonly SolidColorBrush Local;
        private static readonly SolidColorBrush Stream;

        static SourceBadgeColorConverter()
        {
            YouTube = new SolidColorBrush(Color.FromRgb(0xFF, 0x00, 0x00)); YouTube.Freeze();
            Spotify = new SolidColorBrush(Color.FromRgb(0x1D, 0xB9, 0x54)); Spotify.Freeze();
            Local   = new SolidColorBrush(Color.FromRgb(0x60, 0xA0, 0xFF)); Local.Freeze();
            Stream  = new SolidColorBrush(Color.FromRgb(0xFF, 0xA0, 0x00)); Stream.Freeze();
        }

        public object Convert(object value, Type t, object p, CultureInfo c)
            => value is Models.SongSource source
                ? source switch
                {
                    Models.SongSource.YouTube => YouTube,
                    Models.SongSource.Spotify => Spotify,
                    Models.SongSource.Stream  => Stream,
                    _                         => Local,
                }
                : Local;

        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }
}
