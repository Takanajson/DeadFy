using System;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DeadFy.Converters
{
    // ── Shared frozen brushes (allocated once, thread-safe) ───────────────────
    internal static class ConverterBrushes
    {
        public static readonly SolidColorBrush Active;
        public static readonly SolidColorBrush Inactive;

        static ConverterBrushes()
        {
            Active   = new SolidColorBrush(Colors.White);
            Inactive = new SolidColorBrush(Color.FromRgb(0x9A, 0x98, 0xAA));
            Active.Freeze();
            Inactive.Freeze();
        }
    }

    // ── Playback controls ─────────────────────────────────────────────────────

    /// <summary>bool IsPlaying → ⏸ / ▶</summary>
    public class BoolToPlayPauseConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
            => value is true ? "⏸" : "▶";
        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    /// <summary>RepeatMode → ↺¹ when One, ↻ otherwise</summary>
    public class RepeatModeToIconConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
            => value is Services.RepeatMode.One ? "↺¹" : "↻";
        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    // ── Visibility ────────────────────────────────────────────────────────────

    /// <summary>bool true / non-null → Visible; bool false / null → Collapsed.</summary>
    public class NullToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
        {
            if (value is bool b) return b ? Visibility.Visible : Visibility.Collapsed;
            return value != null ? Visibility.Visible : Visibility.Collapsed;
        }
        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    /// <summary>Inverse: false / null → Visible; true / non-null → Collapsed.</summary>
    public class InverseBoolVisConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
        {
            if (value is bool b) return b ? Visibility.Collapsed : Visibility.Visible;
            return Visibility.Visible;
        }
        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    // ── Colour ────────────────────────────────────────────────────────────────

    /// <summary>bool true → White, false → muted grey (shuffle / active state)</summary>
    public class BoolToColorConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
            => value is true ? ConverterBrushes.Active : ConverterBrushes.Inactive;
        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    /// <summary>RepeatMode != None → White, None → muted grey</summary>
    public class RepeatModeToColorConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
            => value is Services.RepeatMode mode && mode != Services.RepeatMode.None
                ? ConverterBrushes.Active
                : ConverterBrushes.Inactive;
        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    // ── Images ────────────────────────────────────────────────────────────────

    /// <summary>
    /// Converts a local file path or HTTP(S) URL to a BitmapImage.
    /// Local files are loaded synchronously and frozen (thread-safe).
    /// Remote URLs are decoded asynchronously by WPF's built-in infrastructure.
    /// </summary>
    public class StringToImageConverter : IValueConverter
    {
        public object? Convert(object value, Type t, object p, CultureInfo c)
        {
            if (value is not string path || string.IsNullOrWhiteSpace(path))
                return null;

            try
            {
                if (!path.StartsWith("http", StringComparison.OrdinalIgnoreCase))
                {
                    if (!File.Exists(path)) return null;
                    var bmp = new BitmapImage();
                    bmp.BeginInit();
                    bmp.CacheOption   = BitmapCacheOption.OnLoad;
                    bmp.CreateOptions = BitmapCreateOptions.IgnoreColorProfile;
                    bmp.UriSource     = new Uri(path, UriKind.Absolute);
                    bmp.EndInit();
                    bmp.Freeze();
                    return bmp;
                }

                // Remote URL — do not Freeze or use OnLoad (deadlocks on HTTP).
                var webBmp = new BitmapImage();
                webBmp.BeginInit();
                webBmp.CreateOptions = BitmapCreateOptions.IgnoreColorProfile;
                webBmp.UriSource     = new Uri(path, UriKind.Absolute);
                webBmp.EndInit();
                return webBmp;
            }
            catch { return null; }
        }

        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }

    // ── Time ──────────────────────────────────────────────────────────────────

    /// <summary>TimeSpan ↔ double seconds (for progress Slider two-way binding)</summary>
    public class TimeSpanToDoubleConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
            => value is TimeSpan ts ? ts.TotalSeconds : 0.0;

        public object ConvertBack(object value, Type t, object p, CultureInfo c)
            => value is double d ? TimeSpan.FromSeconds(d) : TimeSpan.Zero;
    }

    /// <summary>double seconds → "m:ss" or "h:mm:ss" display string</summary>
    public class SecondsToTimeStringConverter : IValueConverter
    {
        public object Convert(object value, Type t, object p, CultureInfo c)
        {
            if (value is not double s) return "0:00";
            var ts = TimeSpan.FromSeconds(s);
            return ts.TotalHours >= 1
                ? ts.ToString(@"h\:mm\:ss")
                : ts.ToString(@"m\:ss");
        }

        public object ConvertBack(object v, Type t, object p, CultureInfo c)
            => throw new NotSupportedException();
    }
}
