using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using DeadFy.Models;

namespace DeadFy.Views.Dialogs
{
    public class AddSongsDialog : Form
    {
        // ── Palette ────────────────────────────────────────────────────────────
        private static readonly Color C_BG        = Color.FromArgb(13,  13,  18);   // near-black
        private static readonly Color C_SURFACE   = Color.FromArgb(20,  20,  28);   // card surface
        private static readonly Color C_RAISED    = Color.FromArgb(28,  28,  40);   // raised element
        private static readonly Color C_BORDER    = Color.FromArgb(40,  40,  58);   // subtle border
        private static readonly Color C_ACCENT    = Color.FromArgb(155, 92,  246);  // purple
        private static readonly Color C_ACCENT2   = Color.FromArgb(99,  102, 241);  // indigo
        private static readonly Color C_CHECK     = Color.FromArgb(16,  185, 129);  // emerald check
        private static readonly Color C_TEXT1     = Color.FromArgb(240, 240, 255);  // primary text
        private static readonly Color C_TEXT2     = Color.FromArgb(140, 140, 175);  // secondary text
        private static readonly Color C_TEXT3     = Color.FromArgb(80,  80,  110);  // muted text
        private static readonly Color C_HOVER     = Color.FromArgb(30,  30,  45);   // row hover
        private static readonly Color C_SELECTED  = Color.FromArgb(38,  28,  62);   // selected row bg
        private static readonly Color C_SEL_EDGE  = Color.FromArgb(155, 92,  246);  // selected left bar

        // ── Public result ──────────────────────────────────────────────────────
        public List<Song> SelectedSongs { get; private set; } = new();

        // ── State ──────────────────────────────────────────────────────────────
        private readonly List<Song> _allSongs;
        private List<Song>          _filtered;
        private readonly HashSet<Song> _selected = new();
        private int _hoveredIndex = -1;

        // ── Controls ───────────────────────────────────────────────────────────
        private Panel       _titleBar   = null!;
        private TextBox     _searchBox  = null!;
        private Label       _searchIcon = null!;
        private DoubleBufferedListView _list = null!;
        private Panel       _footer     = null!;
        private PillLabel   _countPill  = null!;
        private RoundButton _addBtn     = null!;
        private RoundButton _cancelBtn  = null!;
        private Label       _emptyLabel = null!;

        // ── Cover cache ────────────────────────────────────────────────────────
        private readonly Dictionary<string, Image> _coverCache = new();

        // ── Drag ───────────────────────────────────────────────────────────────
        private Point _dragStart;
        private bool  _dragging;

        // ── Row metrics ───────────────────────────────────────────────────────
        private const int ROW_H    = 68;
        private const int ART_SIZE = 46;
        private const int ART_PAD  = 14;

        public AddSongsDialog(List<Song> availableSongs)
        {
            _allSongs = availableSongs;
            _filtered = new List<Song>(_allSongs);
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
            Build();
            Refresh();
        }

        // ══════════════════════════════════════════════════════════════════════
        //  Form construction
        // ══════════════════════════════════════════════════════════════════════
        private void Build()
        {
            Text            = "Add Songs";
            Size            = new Size(620, 620);
            MinimumSize     = new Size(500, 420);
            FormBorderStyle = FormBorderStyle.None;
            StartPosition   = FormStartPosition.CenterParent;
            BackColor       = C_BG;
            ForeColor       = C_TEXT1;
            Font            = new Font("Segoe UI", 9.5f);

            // Rounded corners via region
            Shown += (_, __) => ApplyRoundedCorners(this, 14);

            // ── Title bar ─────────────────────────────────────────────────────
            _titleBar = new Panel
            {
                Dock      = DockStyle.Top,
                Height    = 58,
                BackColor = C_SURFACE,
            };
            _titleBar.Paint      += TitleBar_Paint;
            _titleBar.MouseDown  += (s, e) => { if (e.Button == MouseButtons.Left) { _dragging = true; _dragStart = e.Location; } };
            _titleBar.MouseMove  += (s, e) => { if (_dragging) Location = new Point(Location.X + e.X - _dragStart.X, Location.Y + e.Y - _dragStart.Y); };
            _titleBar.MouseUp    += (s, e) => _dragging = false;

            var closeBtn = new Label
            {
                Text      = "✕",
                ForeColor = C_TEXT3,
                BackColor = Color.Transparent,
                Font      = new Font("Segoe UI", 11f),
                AutoSize  = false,
                Size      = new Size(42, 42),
                TextAlign = ContentAlignment.MiddleCenter,
                Cursor    = Cursors.Hand,
            };
            closeBtn.MouseEnter += (_, __) => { closeBtn.ForeColor = C_TEXT1; closeBtn.Invalidate(); };
            closeBtn.MouseLeave += (_, __) => { closeBtn.ForeColor = C_TEXT3; closeBtn.Invalidate(); };
            closeBtn.Click      += (_, __) => { DialogResult = DialogResult.Cancel; Close(); };
            _titleBar.Controls.Add(closeBtn);

            _titleBar.Resize += (_, __) => closeBtn.Location = new Point(_titleBar.Width - closeBtn.Width - 8, (_titleBar.Height - closeBtn.Height) / 2);
            closeBtn.Location = new Point(620 - closeBtn.Width - 8, 8);

            // ── Search bar ────────────────────────────────────────────────────
            var searchWrap = new Panel
            {
                Dock      = DockStyle.Top,
                Height    = 54,
                BackColor = C_BG,
                Padding   = new Padding(16, 10, 16, 0),
            };

            var searchBg = new Panel
            {
                Dock      = DockStyle.Fill,
                BackColor = C_RAISED,
                Padding   = new Padding(42, 0, 14, 0),
            };
            searchBg.Paint += (s, e) =>
            {
                var g  = e.Graphics;
                var rc = new Rectangle(0, 0, searchBg.Width - 1, searchBg.Height - 1);
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using var path = RoundRect(rc, 10);
                using var br   = new SolidBrush(C_RAISED);
                g.FillPath(br, path);
                using var pen = new Pen(C_BORDER, 1f);
                g.DrawPath(pen, path);
            };

            _searchIcon = new Label
            {
                Text      = "⌕",
                ForeColor = C_TEXT3,
                BackColor = Color.Transparent,
                Font      = new Font("Segoe UI", 14f),
                AutoSize  = false,
                Size      = new Size(36, searchBg.Height),
                TextAlign = ContentAlignment.MiddleCenter,
                Location  = new Point(4, 0),
            };
            searchBg.Controls.Add(_searchIcon);

            _searchBox = new TextBox
            {
                Dock        = DockStyle.Fill,
                BorderStyle = BorderStyle.None,
                BackColor   = C_RAISED,
                ForeColor   = C_TEXT1,
                Font        = new Font("Segoe UI", 11f),
                PlaceholderText = "Search your library...",
            };
            _searchBox.TextChanged += (_, __) => ApplyFilter();
            searchBg.Controls.Add(_searchBox);

            searchWrap.Controls.Add(searchBg);

            // ── Stats bar (thin row) ──────────────────────────────────────────
            var statsBar = new Panel
            {
                Dock      = DockStyle.Top,
                Height    = 28,
                BackColor = C_BG,
                Padding   = new Padding(18, 0, 18, 0),
            };
            statsBar.Paint += (s, e) =>
            {
                var g = e.Graphics;
                var txt = $"{_filtered.Count} track{(_filtered.Count == 1 ? "" : "s")}";
                using var f = new Font("Segoe UI", 8.5f);
                g.DrawString(txt, f, new SolidBrush(C_TEXT3), 18, 7);
            };

            void RefreshStats() { statsBar.Invalidate(); }

            // ── Song list ─────────────────────────────────────────────────────
            _list = new DoubleBufferedListView
            {
                Dock        = DockStyle.Fill,
                BackColor   = C_BG,
                ForeColor   = C_TEXT1,
                BorderStyle = BorderStyle.None,
                Font        = new Font("Segoe UI", 10f),
            };
            _list.Paint       += List_Paint;
            _list.MouseMove   += List_MouseMove;
            _list.MouseLeave  += (_, __) => { _hoveredIndex = -1; _list.Invalidate(); };
            _list.MouseClick  += List_MouseClick;
            _list.Resize      += (_, __) => _list.Invalidate();

            _emptyLabel = new Label
            {
                Text      = "No tracks found",
                ForeColor = C_TEXT3,
                Font      = new Font("Segoe UI", 12f),
                AutoSize  = false,
                Dock      = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Visible   = false,
                BackColor = C_BG,
            };

            // ── Footer ────────────────────────────────────────────────────────
            _footer = new Panel
            {
                Dock      = DockStyle.Bottom,
                Height    = 66,
                BackColor = C_SURFACE,
            };
            _footer.Paint += Footer_Paint;

            _countPill = new PillLabel
            {
                Visible = false,
                Cursor  = Cursors.Default,
            };

            _cancelBtn = new RoundButton
            {
                Text      = "Cancel",
                FgColor   = C_TEXT2,
                BgColor   = C_RAISED,
                HoverColor= C_BORDER,
                Radius    = 10,
                Font      = new Font("Segoe UI", 9.5f),
                Size      = new Size(96, 38),
                Cursor    = Cursors.Hand,
            };
            _cancelBtn.Click += (_, __) => { DialogResult = DialogResult.Cancel; Close(); };

            _addBtn = new RoundButton
            {
                Text       = "Add to Playlist",
                FgColor    = Color.White,
                BgColor    = C_ACCENT,
                HoverColor = Color.FromArgb(135, 72, 226),
                Radius     = 10,
                Font       = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Size       = new Size(148, 38),
                Cursor     = Cursors.Hand,
            };
            _addBtn.Click += Add_Click;

            _footer.Controls.Add(_addBtn);
            _footer.Controls.Add(_cancelBtn);
            _footer.Controls.Add(_countPill);

            _footer.Resize += (_, __) => LayoutFooter();
            LayoutFooter();

            // ── Separator line above footer ───────────────────────────────────
            var sep = new Panel { Dock = DockStyle.Bottom, Height = 1, BackColor = C_BORDER };

            // ── Assemble ──────────────────────────────────────────────────────
            var listContainer = new Panel { Dock = DockStyle.Fill, BackColor = C_BG };
            listContainer.Controls.Add(_list);
            listContainer.Controls.Add(_emptyLabel);

            Controls.Add(listContainer);
            Controls.Add(statsBar);
            Controls.Add(searchWrap);
            Controls.Add(_titleBar);
            Controls.Add(sep);
            Controls.Add(_footer);

            // populate
            PopulateList();
        }

        // ── Footer layout ─────────────────────────────────────────────────────
        private void LayoutFooter()
        {
            int cy = (_footer.Height - _addBtn.Height) / 2;
            _addBtn.Location    = new Point(_footer.Width - _addBtn.Width - 18, cy);
            _cancelBtn.Location = new Point(_footer.Width - _addBtn.Width - _cancelBtn.Width - 28, cy);
            _countPill.Location = new Point(18, (_footer.Height - _countPill.Height) / 2);
        }

        // ── Title bar paint ───────────────────────────────────────────────────
        private void TitleBar_Paint(object? sender, PaintEventArgs e)
        {
            var g  = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(C_SURFACE);

            // accent gradient line at bottom of title bar
            using var lgb = new LinearGradientBrush(
                new Point(0, _titleBar.Height - 2),
                new Point(_titleBar.Width, _titleBar.Height - 2),
                C_ACCENT, C_ACCENT2);
            g.FillRectangle(lgb, 0, _titleBar.Height - 2, _titleBar.Width, 2);

            // music note icon + title
            using var iconFont  = new Font("Segoe UI", 16f);
            using var titleFont = new Font("Segoe UI Semibold", 12f);

            var icon = "♫";
            var iconSz = g.MeasureString(icon, iconFont);
            float totalW = iconSz.Width + 4 + g.MeasureString("Add Songs to Playlist", titleFont).Width;
            float startX = (_titleBar.Width - totalW) / 2f;
            float cy2    = (_titleBar.Height - iconSz.Height) / 2f;

            g.DrawString(icon, iconFont, new SolidBrush(C_ACCENT), startX, cy2 - 1);
            g.DrawString("Add Songs to Playlist", titleFont, new SolidBrush(C_TEXT1),
                startX + iconSz.Width + 4, cy2 + 1);
        }

        // ── Footer paint ──────────────────────────────────────────────────────
        private void Footer_Paint(object? sender, PaintEventArgs e)
        {
            e.Graphics.Clear(C_SURFACE);
        }

        // ══════════════════════════════════════════════════════════════════════
        //  Custom list rendering
        // ══════════════════════════════════════════════════════════════════════
        private void List_Paint(object? sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode     = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            g.Clear(C_BG);

            if (_filtered.Count == 0) return;

            var clip = e.ClipRectangle;
            int startRow = Math.Max(0, clip.Top / ROW_H);
            int endRow   = Math.Min(_filtered.Count - 1, clip.Bottom / ROW_H);

            for (int i = startRow; i <= endRow; i++)
                DrawRow(g, i);

            // bottom fade gradient
            int fadeH = 32;
            int fadeY = _list.Height - fadeH;
            if (fadeY > 0)
            {
                using var fade = new LinearGradientBrush(
                    new Point(0, fadeY), new Point(0, _list.Height),
                    Color.Transparent, Color.FromArgb(180, C_BG));
                g.FillRectangle(fade, 0, fadeY, _list.Width, fadeH);
            }
        }

        private void DrawRow(Graphics g, int i)
        {
            if (i < 0 || i >= _filtered.Count) return;
            var song     = _filtered[i];
            bool sel     = _selected.Contains(song);
            bool hovered = i == _hoveredIndex;

            int y = i * ROW_H;
            var rowRect = new Rectangle(0, y, _list.Width, ROW_H);

            // ── Background ────────────────────────────────────────────────────
            Color bg = sel ? C_SELECTED : hovered ? C_HOVER : C_BG;
            g.FillRectangle(new SolidBrush(bg), rowRect);

            // ── Left accent bar when selected ─────────────────────────────────
            if (sel)
                g.FillRectangle(new SolidBrush(C_SEL_EDGE), 0, y + 6, 3, ROW_H - 12);

            // ── Separator line ────────────────────────────────────────────────
            if (!sel)
                g.DrawLine(new Pen(Color.FromArgb(22, 255, 255, 255)), 72, y + ROW_H - 1, _list.Width - 12, y + ROW_H - 1);

            // ── Album art ─────────────────────────────────────────────────────
            int artX = ART_PAD + 8;
            int artY = y + (ROW_H - ART_SIZE) / 2;
            var artRect = new Rectangle(artX, artY, ART_SIZE, ART_SIZE);

            var cover = GetCover(song);
            if (cover != null)
            {
                DrawRoundedImage(g, cover, artRect, 8);
            }
            else
            {
                // Placeholder with gradient
                using var lgb = new LinearGradientBrush(artRect,
                    Color.FromArgb(40, 40, 65), Color.FromArgb(28, 28, 48),
                    LinearGradientMode.ForwardDiagonal);
                using var path = RoundRect(artRect, 8);
                g.FillPath(lgb, path);
                using var nf = new Font("Segoe UI", 16f);
                var ns = g.MeasureString("♪", nf);
                g.DrawString("♪", nf, new SolidBrush(Color.FromArgb(80, C_ACCENT)),
                    artRect.X + (ART_SIZE - ns.Width) / 2f,
                    artRect.Y + (ART_SIZE - ns.Height) / 2f);
            }

            // ── Checkmark overlay ─────────────────────────────────────────────
            if (sel)
            {
                using var overlayBr = new SolidBrush(Color.FromArgb(160, 16, 185, 129));
                using var path = RoundRect(artRect, 8);
                g.FillPath(overlayBr, path);

                using var checkFont = new Font("Segoe UI", 18f, FontStyle.Bold);
                var ckSz = g.MeasureString("✓", checkFont);
                g.DrawString("✓", checkFont, new SolidBrush(Color.White),
                    artRect.X + (ART_SIZE - ckSz.Width) / 2f - 1,
                    artRect.Y + (ART_SIZE - ckSz.Height) / 2f);
            }

            // ── Text ──────────────────────────────────────────────────────────
            int textX  = artX + ART_SIZE + 14;
            int durW   = 56;
            int textMaxW = _list.Width - textX - durW - 20;

            using var titleFont  = new Font("Segoe UI Semibold", 10.5f);
            using var artistFont = new Font("Segoe UI", 8.5f);
            using var durFont    = new Font("Segoe UI", 8.5f);

            // Title
            var titleBrush  = new SolidBrush(sel ? Color.White : C_TEXT1);
            var artistBrush = new SolidBrush(sel ? Color.FromArgb(180, C_ACCENT) : C_TEXT2);

            var titleSz = g.MeasureString("Ay", titleFont);
            float titleY  = y + (ROW_H / 2f) - titleSz.Height - 1;
            float artistY = y + (ROW_H / 2f) + 2;

            g.DrawString(
                TruncateText(g, song.DisplayTitle, titleFont, textMaxW),
                titleFont, titleBrush, textX, titleY);

            g.DrawString(
                TruncateText(g, song.DisplayArtist, artistFont, textMaxW),
                artistFont, artistBrush, textX, artistY);

            // Duration (right-aligned)
            var durSz = g.MeasureString(song.DurationText, durFont);
            g.DrawString(song.DurationText, durFont, new SolidBrush(C_TEXT3),
                _list.Width - durW - 8,
                y + (ROW_H - durSz.Height) / 2f);
        }

        private static string TruncateText(Graphics g, string text, Font font, int maxW)
        {
            if (g.MeasureString(text, font).Width <= maxW) return text;
            while (text.Length > 1)
            {
                text = text[..^1];
                if (g.MeasureString(text + "…", font).Width <= maxW) return text + "…";
            }
            return "…";
        }

        // ══════════════════════════════════════════════════════════════════════
        //  List interaction
        // ══════════════════════════════════════════════════════════════════════
        private void List_MouseMove(object? sender, MouseEventArgs e)
        {
            int idx = e.Y / ROW_H;
            if (idx != _hoveredIndex)
            {
                int old = _hoveredIndex;
                _hoveredIndex = (idx >= 0 && idx < _filtered.Count) ? idx : -1;
                InvalidateRow(old);
                InvalidateRow(_hoveredIndex);
            }
        }

        private void List_MouseClick(object? sender, MouseEventArgs e)
        {
            int idx = e.Y / ROW_H;
            if (idx < 0 || idx >= _filtered.Count) return;

            var song = _filtered[idx];
            if (_selected.Contains(song)) _selected.Remove(song);
            else                          _selected.Add(song);

            InvalidateRow(idx);
            UpdateCount();
        }

        private void InvalidateRow(int idx)
        {
            if (idx < 0 || idx >= _filtered.Count) return;
            _list.Invalidate(new Rectangle(0, idx * ROW_H, _list.Width, ROW_H));
        }

        private void UpdateCount()
        {
            int n = _selected.Count;
            _countPill.Count   = n;
            _countPill.Visible = n > 0;
            _countPill.Invalidate();
            LayoutFooter();
        }

        // ══════════════════════════════════════════════════════════════════════
        //  Data
        // ══════════════════════════════════════════════════════════════════════
        private void PopulateList()
        {
            bool empty = _filtered.Count == 0;
            _list.Visible      = !empty;
            _emptyLabel.Visible = empty;
            _list.Height = _filtered.Count * ROW_H;
            _list.Invalidate();
        }

        private void ApplyFilter()
        {
            var q = _searchBox.Text.Trim().ToLowerInvariant();
            _filtered = string.IsNullOrEmpty(q)
                ? new List<Song>(_allSongs)
                : _allSongs.Where(s =>
                    s.DisplayTitle.ToLowerInvariant().Contains(q) ||
                    s.DisplayArtist.ToLowerInvariant().Contains(q)).ToList();

            // Re-check hovered index validity
            _hoveredIndex = -1;
            PopulateList();
            Invalidate(true);
        }

        // ══════════════════════════════════════════════════════════════════════
        //  Cover art
        // ══════════════════════════════════════════════════════════════════════
        private Image? GetCover(Song song)
        {
            var key = song.CoverPath ?? song.ThumbnailUrl ?? "";
            if (string.IsNullOrEmpty(key)) return null;
            if (_coverCache.TryGetValue(key, out var cached)) return cached;

            try
            {
                Image? img = null;
                if (!string.IsNullOrEmpty(song.CoverPath) && File.Exists(song.CoverPath))
                    img = Image.FromFile(song.CoverPath);

                _coverCache[key] = img!;
                return img;
            }
            catch { _coverCache[key] = null!; return null; }
        }

        private static void DrawRoundedImage(Graphics g, Image img, Rectangle rect, int radius)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using var path = RoundRect(rect, radius);
            g.SetClip(path);
            g.DrawImage(img, rect);
            g.ResetClip();
        }

        // ══════════════════════════════════════════════════════════════════════
        //  Button handler
        // ══════════════════════════════════════════════════════════════════════
        private void Add_Click(object? sender, EventArgs e)
        {
            if (_selected.Count == 0)
            {
                // Shake animation hint
                ShakeWindow();
                return;
            }
            SelectedSongs = _selected.ToList();
            DialogResult  = DialogResult.OK;
            Close();
        }

        private async void ShakeWindow()
        {
            var orig = Location;
            int[] offsets = { -8, 8, -6, 6, -4, 4, -2, 2, 0 };
            foreach (var dx in offsets)
            {
                Location = new Point(orig.X + dx, orig.Y);
                await System.Threading.Tasks.Task.Delay(30);
            }
            Location = orig;
        }

        // ══════════════════════════════════════════════════════════════════════
        //  Helpers
        // ══════════════════════════════════════════════════════════════════════
        private static GraphicsPath RoundRect(Rectangle r, int radius)
        {
            var path = new GraphicsPath();
            int d = radius * 2;
            path.AddArc(r.X, r.Y, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        private static void ApplyRoundedCorners(Form form, int radius)
        {
            var r = form.ClientRectangle;
            var path = new GraphicsPath();
            int d = radius * 2;
            path.AddArc(r.X, r.Y, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            form.Region = new Region(path);
        }

        // ══════════════════════════════════════════════════════════════════════
        //  Custom controls
        // ══════════════════════════════════════════════════════════════════════

        /// <summary>Double-buffered Panel used as a custom-drawn list.</summary>
        private class DoubleBufferedListView : Panel
        {
            public DoubleBufferedListView()
            {
                SetStyle(ControlStyles.AllPaintingInWmPaint |
                         ControlStyles.UserPaint |
                         ControlStyles.OptimizedDoubleBuffer, true);
                AutoScroll = true;
            }
        }

        /// <summary>Pill-shaped label showing the selected count.</summary>
        private class PillLabel : Control
        {
            public int Count { get; set; }

            public PillLabel()
            {
                SetStyle(ControlStyles.AllPaintingInWmPaint |
                         ControlStyles.UserPaint |
                         ControlStyles.OptimizedDoubleBuffer, true);
                Size = new Size(130, 32);
                BackColor = Color.Transparent;
            }

            protected override void OnPaint(PaintEventArgs e)
            {
                var g  = e.Graphics;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.FromArgb(0, 0, 0, 0));

                // pill background
                var rc = new Rectangle(0, 0, Width - 1, Height - 1);
                using var path = RoundRect(rc, Height / 2);
                using var br   = new SolidBrush(Color.FromArgb(40, 155, 92, 246));
                g.FillPath(br, path);
                using var pen  = new Pen(Color.FromArgb(100, 155, 92, 246), 1f);
                g.DrawPath(pen, path);

                // text
                var txt  = Count == 1 ? "1 track selected" : $"{Count} tracks selected";
                using var f = new Font("Segoe UI Semibold", 8.5f);
                var sz   = g.MeasureString(txt, f);
                g.DrawString(txt, f,
                    new SolidBrush(Color.FromArgb(200, 155, 92, 246)),
                    (Width - sz.Width) / 2f, (Height - sz.Height) / 2f);
            }

            private static GraphicsPath RoundRect(Rectangle r, int radius)
            {
                var path = new GraphicsPath();
                int d = radius * 2;
                path.AddArc(r.X, r.Y, d, d, 180, 90);
                path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
                path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
                path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
                path.CloseFigure();
                return path;
            }
        }

        /// <summary>Rounded, hover-aware button drawn with GDI+.</summary>
        private class RoundButton : Control
        {
            public Color FgColor    { get; set; } = Color.White;
            public Color BgColor    { get; set; } = Color.Gray;
            public Color HoverColor { get; set; } = Color.DarkGray;
            public int   Radius     { get; set; } = 10;

            private bool _hovered;

            public RoundButton()
            {
                SetStyle(ControlStyles.AllPaintingInWmPaint |
                         ControlStyles.UserPaint |
                         ControlStyles.OptimizedDoubleBuffer, true);
            }

            protected override void OnMouseEnter(EventArgs e) { _hovered = true;  Invalidate(); }
            protected override void OnMouseLeave(EventArgs e) { _hovered = false; Invalidate(); }

            protected override void OnPaint(PaintEventArgs e)
            {
                var g  = e.Graphics;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Parent?.BackColor ?? Color.Transparent);

                var rc = new Rectangle(0, 0, Width - 1, Height - 1);
                using var path = RoundRect(rc, Radius);
                using var br   = new SolidBrush(_hovered ? HoverColor : BgColor);
                g.FillPath(br, path);

                using var f  = Font ?? new Font("Segoe UI", 9.5f);
                var sz  = g.MeasureString(Text, f);
                g.DrawString(Text, f, new SolidBrush(FgColor),
                    (Width - sz.Width) / 2f, (Height - sz.Height) / 2f);
            }

            private static GraphicsPath RoundRect(Rectangle r, int radius)
            {
                var path = new GraphicsPath();
                int d = radius * 2;
                path.AddArc(r.X, r.Y, d, d, 180, 90);
                path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
                path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
                path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
                path.CloseFigure();
                return path;
            }
        }
    }
}
