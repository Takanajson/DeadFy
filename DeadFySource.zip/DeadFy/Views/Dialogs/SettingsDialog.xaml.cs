using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using DeadFy.Services;

namespace DeadFy.Views.Dialogs
{
    public partial class SettingsDialog : Window
    {
        private AppTheme _selectedTheme;
        private AppTheme _originalTheme;

        public SettingsDialog()
        {
            InitializeComponent();
            LoadSettings();
        }

        private void LoadSettings()
        {
            var s = SettingsService.Instance.Settings;
            _selectedTheme = s.Theme;
            _originalTheme = s.Theme;

            var devices = SettingsService.Instance.GetOutputDevices();
            AudioDeviceCombo.ItemsSource = devices;
            AudioDeviceCombo.DisplayMemberPath = "Name";
            AudioDeviceCombo.SelectedIndex = Math.Min(s.AudioDeviceIndex, devices.Count - 1);

            StartupCheck.IsChecked = SettingsService.Instance.IsStartWithWindowsEnabled();
            StartMinimizedCheck.IsChecked = s.StartMinimized;
            TrayCheck.IsChecked = s.MinimizeToTray;
            DiscordCheck.IsChecked = s.DiscordRpc;
            OfflineModeCheck.IsChecked = s.OfflineMode;
            ClearCacheCheck.IsChecked  = s.ClearStreamCacheOnExit;

            BuildThemeButtons();

            // Spotify
            UpdateSpotifyStatus();

            // Last.fm
            LastFmEnabledCheck.IsChecked = s.LastFmEnabled;
            if (!string.IsNullOrWhiteSpace(s.LastFmSessionKey))
            {
                LastFmStatusText.Text       = "✅ Connected";
                LastFmStatusText.Foreground = new System.Windows.Media.SolidColorBrush(
                    System.Windows.Media.Color.FromRgb(0x1D, 0xB9, 0x54));
                LastFmApprovedBtn.IsEnabled = false;
            }
            else
            {
                LastFmStatusText.Text = "Not connected";
            }
        }

        private void BuildThemeButtons()
        {
            ThemePanel.Children.Clear();

            // Group label helper
            void AddLabel(string text)
            {
                ThemePanel.Children.Add(new TextBlock
                {
                    Text = text,
                    Foreground = new SolidColorBrush(Color.FromRgb(138, 136, 170)),
                    FontSize = 11,
                    FontWeight = FontWeights.SemiBold,
                    Margin = new Thickness(0, 8, 0, 6),
                    Width = double.NaN
                });
                // Force wrap to new line
                ThemePanel.Children.Add(new UIElement() { });
            }

            // Green themes
            var greenThemes = new (AppTheme t, string label, string bg)[]
            {
                (AppTheme.GreenDark,   "Dark",   "#0D130D"),
                (AppTheme.GreenAmoled, "AMOLED", "#000000"),
                (AppTheme.GreenLight,  "Light",  "#F1F8F1"),
                (AppTheme.GreenPurple, "Purple", "#0E0E1C"),
            };

            // Purple themes
            var purpleThemes = new (AppTheme t, string label, string bg)[]
            {
                (AppTheme.PurpleDark,   "Dark",   "#0E0A1C"),
                (AppTheme.PurpleAmoled, "AMOLED", "#000000"),
                (AppTheme.PurpleLight,  "Light",  "#F4F0FF"),
                (AppTheme.PurplePurple, "Vibrant","#130E24"),
            };

            AddThemeGroup("🟢  Green", greenThemes, "#1DB954");
            AddThemeGroup("🟣  Purple", purpleThemes, "#B06EF5");
        }

        private void AddThemeGroup(string groupName,
            (AppTheme t, string label, string bg)[] themes, string accentHex)
        {
            // Group header
            ThemePanel.Children.Add(new TextBlock
            {
                Text = groupName,
                Foreground = new SolidColorBrush(Color.FromRgb(179, 179, 179)),
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(0, 10, 0, 8)
            });

            var row = new StackPanel { Orientation = Orientation.Horizontal };

            foreach (var (t, label, bg) in themes)
            {
                var accent = (Color)ColorConverter.ConvertFromString(accentHex);
                var isSelected = t == _selectedTheme;
                bool isLight = label == "Light";

                var btn = new Border
                {
                    Width = 80,
                    Height = 58,
                    CornerRadius = new CornerRadius(10),
                    Margin = new Thickness(0, 0, 8, 0),
                    Cursor = Cursors.Hand,
                    Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString(bg)),
                    BorderThickness = new Thickness(2),
                    BorderBrush = isSelected
                        ? new SolidColorBrush(accent)
                        : new SolidColorBrush(Color.FromArgb(40, 255, 255, 255))
                };

                var sp = new StackPanel
                {
                    VerticalAlignment = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center
                };
                sp.Children.Add(new Ellipse
                {
                    Width = 16,
                    Height = 16,
                    Fill = new SolidColorBrush(accent),
                    HorizontalAlignment = HorizontalAlignment.Center,
                    Margin = new Thickness(0, 0, 0, 4)
                });
                sp.Children.Add(new TextBlock
                {
                    Text = label,
                    FontSize = 11,
                    FontWeight = FontWeights.SemiBold,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    Foreground = isLight
                        ? new SolidColorBrush(Color.FromRgb(10, 26, 10))
                        : new SolidColorBrush(Colors.White)
                });
                btn.Child = sp;

                var theme = t;
                btn.MouseDown += (_, _) =>
                {
                    _selectedTheme = theme;
                    ThemeService.Apply(theme);
                    BuildThemeButtons();
                };

                row.Children.Add(btn);
            }

            ThemePanel.Children.Add(row);
        }

        private void AudioDevice_Changed(object sender, SelectionChangedEventArgs e) { }
        private void Startup_Changed(object sender, RoutedEventArgs e) { }
        private void StartMinimized_Changed(object sender, RoutedEventArgs e) { }
        private void Tray_Changed(object sender, RoutedEventArgs e) { }
        private void Discord_Changed(object sender, RoutedEventArgs e) { }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            var s = SettingsService.Instance.Settings;
            bool themeChanged = _selectedTheme != _originalTheme;

            s.Theme = _selectedTheme;
            s.AudioDeviceIndex = AudioDeviceCombo.SelectedIndex;
            s.StartMinimized = StartMinimizedCheck.IsChecked == true;
            s.MinimizeToTray = TrayCheck.IsChecked == true;
            s.DiscordRpc = DiscordCheck.IsChecked == true;

            SettingsService.Instance.SetStartWithWindows(StartupCheck.IsChecked == true);
            SettingsService.Instance.Save();

            DialogResult = true;
            Close();

            if (themeChanged)
            {
                var result = MessageBox.Show(
                    "Theme changed! Restart DeadFy now to apply it fully?",
                    "Restart Required", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    var exePath = Process.GetCurrentProcess().MainModule?.FileName;
                    if (exePath != null)
                    {
                        Process.Start(exePath);
                        Application.Current.Shutdown();
                    }
                }
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            ThemeService.Apply(_originalTheme);
            DialogResult = false;
            Close();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            ThemeService.Apply(_originalTheme);
            Close();
        }

        private void TitleBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left) DragMove();
        }
        private void OfflineMode_Changed(object sender, System.Windows.RoutedEventArgs e)
        {
            bool val = OfflineModeCheck.IsChecked == true;
            SettingsService.Instance.Settings.OfflineMode = val;
            SettingsService.Instance.Save();
            // Keep sidebar toggle in sync
            var vm = (Application.Current.MainWindow?.DataContext as ViewModels.MainViewModel);
            if (vm != null) vm.IsOfflineMode = val;
            SettingsService.Instance.Save();
        }

        private void ClearCache_Changed(object sender, System.Windows.RoutedEventArgs e)
        {
            SettingsService.Instance.Settings.ClearStreamCacheOnExit = ClearCacheCheck.IsChecked == true;
            SettingsService.Instance.Save();
            SettingsService.Instance.Save();
        }

        private void ClearCache_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            Services.StreamCacheService.Instance.ClearAllCache();
            UpdateCacheSize();
            ClearCacheBtn.Content = "✓ Cleared";
        }

        private void LastFmEnabled_Changed(object sender, System.Windows.RoutedEventArgs e)
        {
            SettingsService.Instance.Settings.LastFmEnabled = LastFmEnabledCheck.IsChecked == true;
            SettingsService.Instance.Save();
        }

        // Step 1: open browser for auth
        private string? _lastFmPendingToken;
        private string? _lastFmPendingKey;
        private string? _lastFmPendingSecret;

        private async void LastFmAuth_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var apiKey    = !string.IsNullOrWhiteSpace(ApiConfig.LastFmApiKey)    ? ApiConfig.LastFmApiKey    : SettingsService.Instance.Settings.LastFmApiKey;
            var apiSecret = !string.IsNullOrWhiteSpace(ApiConfig.LastFmApiSecret) ? ApiConfig.LastFmApiSecret : SettingsService.Instance.Settings.LastFmApiSecret;

            if (string.IsNullOrWhiteSpace(apiKey) || string.IsNullOrWhiteSpace(apiSecret))
            {
                System.Windows.MessageBox.Show(
                    "Set your Last.fm API Key and Secret in ApiConfig.cs first, then rebuild.",
                    "Last.fm — Keys Missing",
                    System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
                return;
            }

            LastFmAuthBtn.IsEnabled     = false;
            LastFmAuthBtn.Content       = "⏳ Opening...";
            LastFmStatusText.Text       = "Opening Last.fm...";

            var token = await Services.LastFmService.Instance.GetTokenAsync(apiKey);
            if (token == null)
            {
                LastFmStatusText.Text   = "❌ Failed — check API Key";
                LastFmAuthBtn.IsEnabled = true;
                LastFmAuthBtn.Content   = "🔗 Connect";
                return;
            }

            // Save for step 2
            _lastFmPendingToken  = token;
            _lastFmPendingKey    = apiKey;
            _lastFmPendingSecret = apiSecret;

            // Open browser
            var authUrl = $"https://www.last.fm/api/auth/?api_key={apiKey}&token={token}";
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(authUrl) { UseShellExecute = true });

            LastFmStatusText.Text       = "⏳ Waiting for approval...";
            LastFmAuthBtn.Content       = "🔗 Connect";
            LastFmAuthBtn.IsEnabled     = true;
            LastFmApprovedBtn.IsEnabled = true;  // unlock step 2
        }

        // Step 2: user clicked "I Approved" after authorizing on Last.fm
        private async void LastFmApproved_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_lastFmPendingToken == null || _lastFmPendingKey == null || _lastFmPendingSecret == null)
            {
                System.Windows.MessageBox.Show("Click 🔗 Connect first to open the Last.fm page.",
                    "Last.fm", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
                return;
            }

            LastFmApprovedBtn.IsEnabled = false;
            LastFmApprovedBtn.Content   = "⏳ Verifying...";
            LastFmStatusText.Text       = "Verifying...";

            var sessionKey = await Services.LastFmService.Instance.GetSessionAsync(
                _lastFmPendingToken, _lastFmPendingKey, _lastFmPendingSecret);

            if (!string.IsNullOrWhiteSpace(sessionKey))
            {
                LastFmSessionBox.Text = sessionKey;
                SettingsService.Instance.Settings.LastFmSessionKey = sessionKey;
                SettingsService.Instance.Save();
                Services.LastFmService.Instance.Configure(sessionKey);

                LastFmStatusText.Text       = "✅ Connected!";
                LastFmStatusText.Foreground = new System.Windows.Media.SolidColorBrush(
                    System.Windows.Media.Color.FromRgb(0x1D, 0xB9, 0x54));
                LastFmApprovedBtn.Content   = "✅ I Approved";
                LastFmApprovedBtn.IsEnabled = false;
                _lastFmPendingToken = null;
            }
            else
            {
                LastFmStatusText.Text       = "❌ Not approved yet — try again";
                LastFmApprovedBtn.Content   = "✅ I Approved";
                LastFmApprovedBtn.IsEnabled = true;
            }
        }

        private void UpdateCacheSize()
        {
            var bytes = Services.StreamCacheService.Instance.GetCacheSizeBytes();
            if (bytes < 1024)
                CacheSizeLabel.Text = $"{bytes} B of temp stream files";
            else if (bytes < 1024 * 1024)
                CacheSizeLabel.Text = $"{bytes / 1024} KB of temp stream files";
            else
                CacheSizeLabel.Text = $"{bytes / 1024 / 1024:0.0} MB of temp stream files";
        }
    
        // ── Spotify OAuth ──────────────────────────────────────────────
        private void UpdateSpotifyStatus()
        {
            if (Services.SpotifyService.Instance.IsLoggedIn)
            {
                SpotifyStatusText.Text       = "✅ Connected";
                SpotifyStatusText.Foreground = new System.Windows.Media.SolidColorBrush(
                    System.Windows.Media.Color.FromRgb(0x1D, 0xB9, 0x54));
                SpotifyLoginBtn.Visibility  = Visibility.Collapsed;
                SpotifyLogoutBtn.Visibility = Visibility.Visible;
            }
            else
            {
                SpotifyStatusText.Text       = "Not logged in";
                SpotifyStatusText.Foreground = new System.Windows.Media.SolidColorBrush(
                    System.Windows.Media.Color.FromArgb(0xAA, 0xAA, 0xAA, 0xAA));
                SpotifyLoginBtn.Visibility  = Visibility.Visible;
                SpotifyLogoutBtn.Visibility = Visibility.Collapsed;
            }
        }

        private System.Threading.CancellationTokenSource? _spotifyCts;

        private async void SpotifyLogin_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            SpotifyLoginBtn.IsEnabled = false;
            SpotifyLoginBtn.Content   = "⏳ Waiting...";
            SpotifyStatusText.Text    = "Opening browser...";

            _spotifyCts?.Cancel();
            _spotifyCts = new System.Threading.CancellationTokenSource(
                TimeSpan.FromMinutes(3)); // 3 min timeout

            var (url, verifier) = Services.SpotifyService.Instance.BuildAuthUrl();

            // Open browser
            System.Diagnostics.Process.Start(
                new System.Diagnostics.ProcessStartInfo(url) { UseShellExecute = true });

            // Listen for the callback in the background
            var success = await Services.SpotifyService.Instance.ListenForCallbackAsync(
                verifier,
                onStatus: msg => Dispatcher.Invoke(() => SpotifyStatusText.Text = msg),
                ct: _spotifyCts.Token);

            if (success)
            {
                UpdateSpotifyStatus();
                SpotifyStatusText.Text = "✅ Connected!";
            }
            else
            {
                SpotifyStatusText.Text    = "❌ Login failed or timed out";
                SpotifyLoginBtn.IsEnabled = true;
                SpotifyLoginBtn.Content   = "🔗 Login with Spotify";
            }
        }

        private void SpotifyLogout_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            _spotifyCts?.Cancel();
            Services.SpotifyService.Instance.Logout();
            UpdateSpotifyStatus();
        }

    }
}
