using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using DeadFy.Services;

namespace DeadFy.Views.Dialogs
{
    public partial class EqualizerDialog : Window
    {
        private static readonly string[] BandLabels = { "60Hz", "170Hz", "310Hz", "600Hz", "1kHz", "3kHz", "6kHz", "12kHz", "14kHz", "16kHz" };
        private readonly Slider[] _sliders = new Slider[10];

        // Presets: name -> 10 gain values in dB
        private static readonly Dictionary<string, float[]> Presets = new()
        {
            ["Flat"]       = new float[] { 0,  0,  0,  0,  0,  0,  0,  0,  0,  0 },
            ["Bass Boost"] = new float[] { 6,  5,  4,  2,  0,  0,  0,  0,  0,  0 },
            ["Treble"]     = new float[] { 0,  0,  0,  0,  2,  3,  4,  5,  6,  6 },
            ["Pop"]        = new float[] {-1,  2,  4,  4,  2,  0, -1, -1, -1, -1 },
            ["Rock"]       = new float[] { 4,  3,  2,  0, -1, -1,  2,  3,  4,  4 },
            ["Jazz"]       = new float[] { 3,  2,  1,  2,  0,  0,  1,  2,  2,  3 },
            ["Classical"]  = new float[] { 4,  3,  2,  1,  0,  0, -1, -1, -2, -3 },
        };

        public EqualizerDialog()
        {
            InitializeComponent();
            BuildPresetButtons();
            BuildSliders();
            LoadCurrentBands();
        }

        private void BuildPresetButtons()
        {
            foreach (var (name, _) in Presets)
            {
                var btn = new Button
                {
                    Content = name,
                    Margin  = new Thickness(0, 0, 8, 8),
                    Padding = new Thickness(12, 6, 12, 6),
                    FontSize = 11,
                    Cursor  = Cursors.Hand,
                    Background = (Brush)Application.Current.Resources["BG4Brush"],
                    Foreground = (Brush)Application.Current.Resources["TextSecondaryBrush"],
                    BorderThickness = new Thickness(0)
                };
                btn.Template = MakeRoundedButtonTemplate();
                var preset = name;
                btn.Click += (_, _) => ApplyPreset(preset);
                PresetPanel.Children.Add(btn);
            }
        }

        private void BuildSliders()
        {
            double colWidth = 46;
            for (int i = 0; i < 10; i++)
            {
                var col = new StackPanel
                {
                    Width = colWidth,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    Margin = new Thickness(2, 0, 2, 0)
                };

                // dB value label (top)
                var dbLabel = new TextBlock
                {
                    HorizontalAlignment = HorizontalAlignment.Center,
                    FontSize = 10,
                    Foreground = (Brush)Application.Current.Resources["AccentBrush"],
                    Margin = new Thickness(0, 0, 0, 4),
                    Text = "0"
                };

                // Vertical slider
                var slider = new Slider
                {
                    Orientation     = Orientation.Vertical,
                    Minimum         = -12,
                    Maximum         = 12,
                    Value           = 0,
                    Height          = 160,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    TickFrequency   = 3,
                    IsSnapToTickEnabled = false,
                    SmallChange     = 0.5,
                    LargeChange     = 3,
                };
                slider.ValueChanged += (_, args) =>
                {
                    dbLabel.Text = $"{args.NewValue:+0.0;-0.0;0}";
                };

                // Band label (bottom)
                var bandLabel = new TextBlock
                {
                    Text = BandLabels[i],
                    FontSize = 9.5,
                    Foreground = (Brush)Application.Current.Resources["TextMutedBrush"],
                    HorizontalAlignment = HorizontalAlignment.Center,
                    Margin = new Thickness(0, 6, 0, 0)
                };

                col.Children.Add(dbLabel);
                col.Children.Add(slider);
                col.Children.Add(bandLabel);
                SliderPanel.Children.Add(col);
                _sliders[i] = slider;
            }
        }

        private void LoadCurrentBands()
        {
            var bands = AudioPlayerService.Instance.EqBands;
            for (int i = 0; i < _sliders.Length && i < bands.Length; i++)
                _sliders[i].Value = bands[i];
        }

        private void ApplyPreset(string name)
        {
            if (!Presets.TryGetValue(name, out var values)) return;
            for (int i = 0; i < _sliders.Length && i < values.Length; i++)
                _sliders[i].Value = values[i];
        }

        private void Apply_Click(object sender, RoutedEventArgs e)
        {
            var bands = AudioPlayerService.Instance.EqBands;
            var savedBands = SettingsService.Instance.Settings.EqBands;
            for (int i = 0; i < _sliders.Length && i < bands.Length; i++)
            {
                bands[i]       = (float)_sliders[i].Value;
                savedBands[i]  = (float)_sliders[i].Value;
            }
            AudioPlayerService.Instance.ApplyEqualizer();
            SettingsService.Instance.Save();
            Close();
        }

        private void Reset_Click(object sender, RoutedEventArgs e)
            => ApplyPreset("Flat");

        private void Close_Click(object sender, RoutedEventArgs e) => Close();

        private void TitleBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left) DragMove();
        }

        private static ControlTemplate MakeRoundedButtonTemplate()
        {
            var template = new ControlTemplate(typeof(Button));
            var factory  = new FrameworkElementFactory(typeof(Border));
            factory.SetBinding(Border.BackgroundProperty,
                new System.Windows.Data.Binding("Background")
                { RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent) });
            factory.SetValue(Border.CornerRadiusProperty, new CornerRadius(6));
            factory.SetBinding(Border.PaddingProperty,
                new System.Windows.Data.Binding("Padding")
                { RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent) });
            var cp = new FrameworkElementFactory(typeof(ContentPresenter));
            cp.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            cp.SetValue(ContentPresenter.VerticalAlignmentProperty,   VerticalAlignment.Center);
            factory.AppendChild(cp);
            template.VisualTree = factory;
            return template;
        }
    }
}
