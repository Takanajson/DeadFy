using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using DeadFy.Models;

namespace DeadFy.Views.Dialogs
{
    public partial class PlaylistPickerDialog : Window
    {
        public Playlist? SelectedPlaylist { get; private set; }

        public PlaylistPickerDialog(List<Playlist> playlists)
        {
            InitializeComponent();
            PlaylistList.ItemsSource = playlists;
        }

        private void Confirm_Click(object sender, RoutedEventArgs e)
        {
            if (PlaylistList.SelectedItem is Playlist pl)
            {
                SelectedPlaylist = pl;
                DialogResult = true;
            }
            else
            {
                MessageBox.Show("Please select a playlist.", "No Selection",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
            => DialogResult = false;

        private void TitleBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left) DragMove();
        }

        private void PlaylistList_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (PlaylistList.SelectedItem is Playlist pl)
            {
                SelectedPlaylist = pl;
                DialogResult = true;
            }
        }
    }
}
