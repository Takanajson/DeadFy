using System.Windows;
using System.Windows.Input;
using DeadFy.Services;

namespace DeadFy.Views.Dialogs
{
    public partial class PluginManagerDialog : Window
    {
        private readonly PluginLoaderService _loader = PluginLoaderService.Instance;

        public PluginManagerDialog()
        {
            InitializeComponent();

            // Bind plugin list
            PluginList.ItemsSource = _loader.Plugins;
            LogList.ItemsSource    = _loader.Logs;

            // Update count badge
            _loader.Plugins.CollectionChanged += (_, _) => UpdateBadge();
            UpdateBadge();

            // Update empty state
            _loader.Plugins.CollectionChanged += (_, _) => UpdateEmptyState();
            UpdateEmptyState();

            // Auto-scroll logs
            _loader.Logs.CollectionChanged += (_, _) =>
                Dispatcher.Invoke(() => LogScroll.ScrollToEnd());
        }

        private void UpdateBadge()
            => PluginCountBadge.Text = $"{_loader.Plugins.Count} plugin{(_loader.Plugins.Count == 1 ? "" : "s")}";

        private void UpdateEmptyState()
            => EmptyState.Visibility = _loader.Plugins.Count == 0
                ? Visibility.Visible : Visibility.Collapsed;

        private void TogglePlugin_Click(object sender, MouseButtonEventArgs e)
        {
            if ((sender as FrameworkElement)?.Tag is PluginInfo info)
            {
                if (info.IsEnabled) _loader.DisablePlugin(info);
                else                _loader.EnablePlugin(info);
            }
        }

        private void ReloadPlugin_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as FrameworkElement)?.Tag is PluginInfo info)
                _loader.ReloadPlugin(info);
        }

        private void OpenFolder_Click(object sender, RoutedEventArgs e)
            => _loader.OpenPluginsFolder();

        private void ClearLogs_Click(object sender, RoutedEventArgs e)
            => _loader.Logs.Clear();

        private void Close_Click(object sender, RoutedEventArgs e)
            => Close();

        private void TitleBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left) DragMove();
        }
    }
}
