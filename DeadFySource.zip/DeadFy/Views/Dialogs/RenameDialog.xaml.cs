using System.Windows;
using System.Windows.Input;

namespace DeadFy.Views.Dialogs
{
    public partial class RenameDialog : Window
    {
        public string NewName { get; private set; } = string.Empty;

        public RenameDialog(string title, string currentName)
        {
            InitializeComponent();
            TitleLabel.Text = title;
            InputBox.Text = currentName;
            Loaded += (_, _) =>
            {
                InputBox.Focus();
                InputBox.SelectAll();
            };
        }

        private void Rename_Click(object sender, RoutedEventArgs e) => Commit();
        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void Input_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) Commit();
            else if (e.Key == Key.Escape) { DialogResult = false; Close(); }
        }

        private void Commit()
        {
            var name = InputBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(name)) return;
            NewName = name;
            DialogResult = true;
            Close();
        }

        private void TitleBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left) DragMove();
        }
    }
}
