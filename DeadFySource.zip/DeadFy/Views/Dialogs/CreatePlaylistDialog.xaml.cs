using System.Windows;
using System.Windows.Input;

namespace DeadFy.Views.Dialogs
{
    public partial class CreatePlaylistDialog : Window
    {
        public string PlaylistName { get; private set; } = string.Empty;

        public CreatePlaylistDialog()
        {
            InitializeComponent();
            Loaded += (_, _) => { NameBox.SelectAll(); NameBox.Focus(); };
        }

        private void Create_Click(object sender, RoutedEventArgs e)
        {
            PlaylistName = NameBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(PlaylistName))
            {
                NameBox.Focus();
                return;
            }
            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
            => DialogResult = false;

        private void TitleBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left) DragMove();
        }
    }
}
