using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using DeadFy.Models;

namespace DeadFy.Views.Dialogs
{
    public partial class AddSongsDialog : Window
    {
        private readonly List<Song> _allSongs;
        public List<Song> SelectedSongs { get; private set; } = new();

        public AddSongsDialog(List<Song> availableSongs)
        {
            InitializeComponent();
            _allSongs = availableSongs;
            SongsList.ItemsSource = _allSongs;
            SongsList.SelectionChanged += (_, _) =>
            {
                SelectionCount.Text = $"{SongsList.SelectedItems.Count} selected";
            };
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            PlaceholderText.Visibility = string.IsNullOrEmpty(SearchBox.Text)
                ? Visibility.Visible : Visibility.Collapsed;

            var q = SearchBox.Text.ToLower();
            SongsList.ItemsSource = string.IsNullOrWhiteSpace(q)
                ? _allSongs
                : _allSongs.Where(s =>
                    s.DisplayTitle.ToLower().Contains(q) ||
                    s.DisplayArtist.ToLower().Contains(q)).ToList();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            SelectedSongs = SongsList.SelectedItems.Cast<Song>().ToList();
            if (SelectedSongs.Count == 0)
            {
                MessageBox.Show("Please select at least one song.", "No Selection",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
            => DialogResult = false;

        private void TitleBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left) DragMove();
        }
    }
}
