using System.Windows;
using System.Windows.Input;
using Microsoft.Win32;

namespace DeadFy.Views.Dialogs
{
    public partial class UploadMusicDialog : Window
    {
        public string  Mp3Path   { get; private set; } = string.Empty;
        public string? CoverPath { get; private set; }
        public new string  Title     { get; private set; } = string.Empty;
        public string  Artist    { get; private set; } = string.Empty;

        public UploadMusicDialog()
        {
            InitializeComponent();
        }

        private void BrowseMp3_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog
            {
                Title  = "Select Audio File",
                Filter = "Audio Files|*.mp3;*.wav;*.flac;*.m4a;*.ogg;*.aiff|All Files|*.*"
            };
            if (dlg.ShowDialog() == true)
            {
                Mp3Path       = dlg.FileName;
                Mp3PathBox.Text = System.IO.Path.GetFileName(dlg.FileName);
                if (string.IsNullOrWhiteSpace(TitleBox.Text))
                    TitleBox.Text = System.IO.Path.GetFileNameWithoutExtension(dlg.FileName);
            }
        }

        private void BrowseCover_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog
            {
                Title  = "Select Cover Image",
                Filter = "Image Files|*.png;*.jpg;*.jpeg;*.bmp;*.webp|All Files|*.*"
            };
            if (dlg.ShowDialog() == true)
            {
                CoverPath        = dlg.FileName;
                CoverPathBox.Text = System.IO.Path.GetFileName(dlg.FileName);
            }
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Mp3Path))
            {
                MessageBox.Show("Please select an audio file.", "Missing File",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            Title        = TitleBox.Text.Trim();
            Artist       = ArtistBox.Text.Trim();
            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
            => DialogResult = false;

        private void TitleBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left) DragMove();
        }
    }
}
