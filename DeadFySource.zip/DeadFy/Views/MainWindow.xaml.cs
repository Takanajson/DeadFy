using System;
using System.Linq;
using System.IO;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Collections.ObjectModel;
using Microsoft.Win32;
using DeadFy.Models;
using DeadFy.Services;
using DeadFy.ViewModels;
using DeadFy.Views.Dialogs;

using WinForms = System.Windows.Forms;
using Drawing = System.Drawing;

namespace DeadFy.Views
{
    public partial class MainWindow : Window
    {
        private MainViewModel _vm;
        private WinForms.NotifyIcon _trayIcon = null!;
        private bool _forceClose = false;

        public MainWindow()
        {
            InitializeComponent();
            _vm = new MainViewModel();
            DataContext = _vm;
            SetActiveView("Library");
            Loaded += (_, _) => InitSidebarPlugins();
            InitTray();
            AudioPlayerService.Instance.SongChanged += OnSongChangedForKaraoke;
            AudioPlayerService.Instance.SongChanged   += (_, _) => UpdateTaskbarButtons();
            AudioPlayerService.Instance.PropertyChanged += (_, e) =>
            {
                if (e.PropertyName == nameof(AudioPlayerService.IsPlaying))
                    Dispatcher.Invoke(UpdateTaskbarButtons);
            };
            Loaded += (_, _) => UpdateTaskbarButtons();

            Loaded += (_, _) =>
            {
                _vm.SearchSuggestions.CollectionChanged += (_, _) =>
                {
                    if (SuggestionsPopup != null && SearchBox != null)
                    {
                        SuggestionsPopup.PlacementTarget = SearchBox;
                        SuggestionsPopup.IsOpen = _vm.SearchSuggestions.Count > 0;
                    }
                };
            };
            Loaded += (_, _) =>
            {
                UpdateNavHighlight("Library");
                FitToScreen();
            };

            // Global keyboard shortcuts
            KeyDown += Window_KeyDown;

            if (SettingsService.Instance.Settings.StartMinimized)
            {
                WindowState = WindowState.Minimized;
            }
        }

        // ══════════════════════════════════════════════
        // SYSTEM TRAY
        // ══════════════════════════════════════════════
        private void InitTray()
        {
            _trayIcon = new WinForms.NotifyIcon { Text = "DeadFy", Visible = false };

            try
            {
                var iconPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "icon.ico");
                _trayIcon.Icon = File.Exists(iconPath)
                    ? new Drawing.Icon(iconPath)
                    : Drawing.SystemIcons.Application;
            }
            catch { _trayIcon.Icon = Drawing.SystemIcons.Application; }

            var menu = new WinForms.ContextMenuStrip();
            menu.Items.Add("Show DeadFy", null, (_, _) => ShowFromTray());
            menu.Items.Add(new WinForms.ToolStripSeparator());
            menu.Items.Add("⏯  Play / Pause", null, (_, _) => AudioPlayerService.Instance.TogglePlayPause());
            menu.Items.Add("⏭  Next", null, (_, _) => _vm.PlayNext());
            menu.Items.Add("⏮  Previous", null, (_, _) => _vm.PlayPrevious());
            menu.Items.Add(new WinForms.ToolStripSeparator());
            menu.Items.Add("✕  Exit", null, (_, _) => ForceClose());
            _trayIcon.ContextMenuStrip = menu;
            _trayIcon.DoubleClick += (_, _) => ShowFromTray();
        }

        private void HideToTray() { _trayIcon.Visible = true; Hide(); }

        private void ShowFromTray()
        {
            Show();
            WindowState = WindowState.Normal;
            Activate();
            _trayIcon.Visible = false;
        }

        private void ForceClose()
        {
            _forceClose = true;
            _trayIcon.Visible = false;
            _trayIcon.Dispose();
            Close();
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            if (!_forceClose && SettingsService.Instance.Settings.MinimizeToTray)
            {
                e.Cancel = true;
                HideToTray();
                return;
            }
            // Save recently played & clean stream cache
            _vm.SaveRecentlyPlayed();
            if (SettingsService.Instance.Settings.ClearStreamCacheOnExit)
                Services.StreamCacheService.Instance.ClearSessionCache();
            _trayIcon.Dispose();
            base.OnClosing(e);
        }

        // ══════════════════════════════════════════════
        // TITLE BAR & WINDOW
        // ══════════════════════════════════════════════
        private void TitleBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                if (e.ClickCount == 2)
                    WindowState = WindowState == WindowState.Maximized
                        ? WindowState.Normal : WindowState.Maximized;
                else if (WindowState == WindowState.Normal)
                    DragMove();
            }
        }

        private void Window_StateChanged(object sender, EventArgs e)
        {
            if (OuterBorder == null) return;

            if (WindowState == WindowState.Maximized)
            {
                var screen = WinForms.Screen.FromHandle(
                    new System.Windows.Interop.WindowInteropHelper(this).Handle);
                var wa = screen.WorkingArea;

                MaxWidth = wa.Width;
                MaxHeight = wa.Height;

                OuterBorder.Margin = new Thickness(
                    SystemParameters.WindowResizeBorderThickness.Left + SystemParameters.FixedFrameVerticalBorderWidth,
                    SystemParameters.WindowResizeBorderThickness.Top + SystemParameters.FixedFrameHorizontalBorderHeight,
                    SystemParameters.WindowResizeBorderThickness.Right + SystemParameters.FixedFrameVerticalBorderWidth,
                    SystemParameters.WindowResizeBorderThickness.Bottom + SystemParameters.FixedFrameHorizontalBorderHeight
                );
                OuterBorder.CornerRadius = new CornerRadius(0);
            }
            else
            {
                MaxWidth = double.PositiveInfinity;
                MaxHeight = double.PositiveInfinity;
                OuterBorder.Margin = new Thickness(0);
                OuterBorder.CornerRadius = new CornerRadius(14);
            }
        }

        private void FitToScreen()
        {
            var screen = WinForms.Screen.FromHandle(
                new System.Windows.Interop.WindowInteropHelper(this).Handle);
            var wa = screen.WorkingArea;

            double sw = wa.Width, sh = wa.Height;
            double tw = Math.Max(960, Math.Min(sw * 0.85, 1600));
            double th = Math.Max(640, Math.Min(sh * 0.85, 1000));

            if (sw <= 1366) { tw = Math.Min(sw - 40, 1280); th = Math.Min(sh - 60, 800); }

            Width = tw; Height = th;
            Left = wa.Left + (sw - tw) / 2;
            Top = wa.Top + (sh - th) / 2;
        }

        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void MaximizeButton_Click(object sender, RoutedEventArgs e)
            => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            if (SettingsService.Instance.Settings.MinimizeToTray) HideToTray();
            else ForceClose();
        }

        private void MinimizeMouseDown(object sender, MouseButtonEventArgs e)
        { MinimizeButton_Click(sender, e); e.Handled = true; }

        private void MaximizeMouseDown(object sender, MouseButtonEventArgs e)
        { MaximizeButton_Click(sender, e); e.Handled = true; }

        // ══════════════════════════════════════════════
        // SETTINGS
        // ══════════════════════════════════════════════
        private void PluginsButton_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new Views.Dialogs.PluginManagerDialog { Owner = this };
            dlg.ShowDialog();
        }

        private void SidebarPluginToggle_Click(object sender, MouseButtonEventArgs e)
        {
            if ((sender as FrameworkElement)?.Tag is Services.PluginInfo info)
            {
                var loader = Services.PluginLoaderService.Instance;
                if (info.IsEnabled) loader.DisablePlugin(info);
                else                loader.EnablePlugin(info);
                e.Handled = true;
            }
        }

        private void InitSidebarPlugins()
        {
            var loader = Services.PluginLoaderService.Instance;
            SidebarPluginList.ItemsSource = loader.Plugins;

            // Show/hide the section based on whether any plugins exist
            void UpdateVisibility()
            {
                SidebarPluginsSection.Visibility = loader.Plugins.Count > 0
                    ? Visibility.Visible : Visibility.Collapsed;
            }

            loader.Plugins.CollectionChanged += (_, _) => Dispatcher.Invoke(UpdateVisibility);
            UpdateVisibility();
        }

        private void SettingsButton_Click(object sender, RoutedEventArgs e) => OpenSettingsDialog();
        private void NavSettings_Click(object sender, RoutedEventArgs e) => OpenSettingsDialog();
        private void OpenSettings_Click(object sender, RoutedEventArgs e) => OpenSettingsDialog();

        private void OpenSettingsDialog()
        {
            new SettingsDialog { Owner = this }.ShowDialog();
            UpdateSpotifyHint();
        }

        private void UpdateSpotifyHint()
        {
            if (SpotifyNoCredsHint == null) return;
            // Check ApiConfig first, then settings
            var hasSpotify = !string.IsNullOrWhiteSpace(ApiConfig.SpotifyClientId)
                          || !string.IsNullOrWhiteSpace(SettingsService.Instance.Settings.SpotifyClientId);
            SpotifyNoCredsHint.Visibility = hasSpotify ? Visibility.Collapsed : Visibility.Visible;
        }

        private void EqualizerButton_Click(object sender, RoutedEventArgs e)
            => new EqualizerDialog { Owner = this }.ShowDialog();

        // ══════════════════════════════════════════════
        // NAVIGATION
        // ══════════════════════════════════════════════
        private void SetActiveView(string view)
        {
            ViewLibrary.Visibility = Visibility.Collapsed;
            ViewSearch.Visibility = Visibility.Collapsed;
            ViewDownloads.Visibility = Visibility.Collapsed;
            ViewPlaylists.Visibility = Visibility.Collapsed;
            ViewPlaylistDetail.Visibility = Visibility.Collapsed;
            ViewRecent.Visibility = Visibility.Collapsed;

            switch (view)
            {
                case "Library": ViewLibrary.Visibility = Visibility.Visible; break;
                case "Search": ViewSearch.Visibility = Visibility.Visible; UpdateSpotifyHint(); break;
                case "Downloads": ViewDownloads.Visibility = Visibility.Visible; _vm.RefreshDownloads(); break;
                case "Playlists": ViewPlaylists.Visibility = Visibility.Visible; break;
                case "PlaylistDetail": ViewPlaylistDetail.Visibility = Visibility.Visible; break;
                case "Recent": ViewRecent.Visibility = Visibility.Visible; break;
            }
            _vm.CurrentView = view;
            UpdateNavHighlight(view);
        }

        private void UpdateNavHighlight(string view)
        {
            BtnNavLibrary.Style = null;
            BtnNavSearch.Style = null;
            BtnNavDownloads.Style = null;
            BtnNavPlaylists.Style = null;
            BtnNavSettings.Style = null;
            BtnNavRecent.Style = null;

            var normal = TryFindResource("SidebarNavButtonStyle") as Style;
            var active = TryFindResource("SidebarNavButtonActiveStyle") as Style;
            if (normal == null || active == null) return;

            BtnNavLibrary.Style = normal;
            BtnNavSearch.Style = normal;
            BtnNavDownloads.Style = normal;
            BtnNavPlaylists.Style = normal;
            BtnNavSettings.Style = normal;
            BtnNavRecent.Style = normal;

            switch (view)
            {
                case "Library": BtnNavLibrary.Style = active; break;
                case "Search": BtnNavSearch.Style = active; break;
                case "Downloads": BtnNavDownloads.Style = active; break;
                case "Playlists":
                case "PlaylistDetail": BtnNavPlaylists.Style = active; break;
                case "Recent": BtnNavRecent.Style = active; break;
            }
        }

        private void SidebarPlaylist_Click(object sender, MouseButtonEventArgs e)
        {
            if (_vm.SelectedPlaylist != null)
            {
                _vm.SelectedPlaylist = _vm.SelectedPlaylist; // trigger navigation
                SetActiveView("PlaylistDetail");
            }
        }

        private void SidebarPlaylistItem_Click(object sender, MouseButtonEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is Models.Playlist pl)
            {
                _vm.SelectedPlaylist = pl;
                SetActiveView("PlaylistDetail");
                e.Handled = true;
            }
        }

        private void NavLibrary_Click(object sender, RoutedEventArgs e) => SetActiveView("Library");
        private void NavSearch_Click(object sender, RoutedEventArgs e) => SetActiveView("Search");
        private void NavDownloads_Click(object sender, RoutedEventArgs e) => SetActiveView("Downloads");
        private void NavPlaylists_Click(object sender, RoutedEventArgs e) => SetActiveView("Playlists");
        private void NavRecent_Click(object sender, RoutedEventArgs e) => SetActiveView("Recent");

        // ══════════════════════════════════════════════
        // LYRICS + QUEUE PANELS
        // ══════════════════════════════════════════════
        private void LyricsButton_Click(object sender, RoutedEventArgs e)
        {
            _vm.ShowLyrics = !_vm.ShowLyrics;
            if (_vm.ShowLyrics)
            {
                var song = AudioPlayerService.Instance.CurrentSong;
                if (song != null) _ = LoadAndDisplayLyrics(song);
                else KaraokePanel.Clear();
            }
        }

        private async System.Threading.Tasks.Task LoadAndDisplayLyrics(Models.Song song)
        {
            // Update karaoke accent to match current theme
            UpdateKaraokeAccent();
            KaraokePanel.ShowLoading();

            await _vm.LoadLyricsAsync(song);
            var result = _vm.CurrentLyricsResult;
            KaraokePanel.SetLyrics(result);

            // Subscribe to position ticks for sync
            _vm.LyricsPositionTick -= OnLyricsPositionTick;
            _vm.LyricsPositionTick += OnLyricsPositionTick;
        }

        private void OnLyricsPositionTick(object? sender, TimeSpan pos)
            => KaraokePanel.UpdatePosition(pos);

        private void KaraokePanel_LineClicked(object? sender, TimeSpan ts)
        {
            AudioPlayerService.Instance.PositionSeconds = ts.TotalSeconds;
        }

        private void UpdateKaraokeAccent()
        {
            try
            {
                var brush = TryFindResource("AccentBrush") as System.Windows.Media.SolidColorBrush;
                if (brush != null) KaraokePanel.AccentColor = brush.Color;
            }
            catch { }
        }

        private void QueueButton_Click(object sender, RoutedEventArgs e)
            => _vm.ShowQueue = !_vm.ShowQueue;

        private void CloseLyrics_Click(object sender, RoutedEventArgs e)
            => _vm.ShowLyrics = false;

        private void CloseQueue_Click(object sender, RoutedEventArgs e)
            => _vm.ShowQueue = false;

        // Called when a new song starts — reload karaoke if panel is open
        private void OnSongChangedForKaraoke(object? sender, Models.Song? song)
        {
            if (!_vm.ShowLyrics) return;
            if (song == null) { KaraokePanel.Clear(); return; }
            _ = LoadAndDisplayLyrics(song);
        }

        private void RecentSong_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is Song song)
                _vm.PlaySong(song);
        }

        private void RemoveFromQueue_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button btn && btn.Tag is Song song)
                _vm.RemoveFromQueue(song);
        }

        private void QueueSong_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is Song song)
                _vm.PlayFromQueue(song);
        }

        // ══════════════════════════════════════════════
        // SEARCH PANEL TABS
        // ══════════════════════════════════════════════
        private void TabYouTube_Click(object sender, RoutedEventArgs e)
        {
            YouTubePanel.Visibility = Visibility.Visible;
            SpotifyPanel.Visibility = Visibility.Collapsed;
            TabYouTube.Style = (Style)FindResource("AccentButtonStyle");
            TabSpotify.Style = (Style)FindResource("GhostButtonStyle");
        }

        private void TabSpotify_Click(object sender, RoutedEventArgs e)
        {
            YouTubePanel.Visibility = Visibility.Collapsed;
            SpotifyPanel.Visibility = Visibility.Visible;
            TabYouTube.Style = (Style)FindResource("GhostButtonStyle");
            TabSpotify.Style = (Style)FindResource("AccentButtonStyle");
            UpdateSpotifyHint();
        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (SuggestionsPopup != null) SuggestionsPopup.IsOpen = false;
                _vm.TriggerSearch();
            }
            else if (SuggestionsPopup != null)
            {
                SuggestionsPopup.PlacementTarget = SearchBox;
                SuggestionsPopup.IsOpen = _vm.SearchSuggestions.Count > 0;
            }
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e) => _vm.TriggerSearch();

        // ══════════════════════════════════════════════
        // LIBRARY
        // ══════════════════════════════════════════════
        private void SongRow_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left && e.ClickCount == 2)
                if ((sender as FrameworkElement)?.DataContext is Song song)
                    _vm.PlaySong(song, _vm.FilteredLibrary);
        }

        private void RemoveSong_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button btn && btn.Tag is Song song)
                ConfirmDeleteSong(song);
        }

        private void DeleteSong_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button btn && btn.Tag is Song song)
                ConfirmDeleteSong(song);
        }

        private void ConfirmDeleteSong(Song song)
        {
            var r = MessageBox.Show(
                $"Remove \"{song.DisplayTitle}\" from your library?\nThis will also delete the file from disk.",
                "Remove Song", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (r != MessageBoxResult.Yes) return;

            if (AudioPlayerService.Instance.CurrentSong?.Id == song.Id)
                AudioPlayerService.Instance.Stop();

            LibraryService.Instance.RemoveSong(song);
            _vm.RefreshFilteredLibrary();
            _vm.RefreshDownloads();
        }

        private void FavoriteSong_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button btn && btn.Tag is Song song)
            {
                song.IsFavorite = !song.IsFavorite;
                LibraryService.Instance.SaveLibrary();
            }
        }

        // ══════════════════════════════════════════════
        // UPLOAD / ADD MUSIC
        // ══════════════════════════════════════════════
        private void UploadMusic_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new UploadMusicDialog { Owner = this };
            if (dialog.ShowDialog() != true) return;

            var song = LibraryService.Instance.AddLocalSong(
                dialog.Mp3Path, dialog.CoverPath, dialog.Artist, dialog.Title);

            if (song != null)
            {
                _vm.RefreshFilteredLibrary();
                _vm.RefreshDownloads();
                SetActiveView("Library");
            }
            else
            {
                MessageBox.Show("Failed to add song. Please check the file.",
                    "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // ══════════════════════════════════════════════
        // DOWNLOADS
        // ══════════════════════════════════════════════
        private void DownloadCard_Play(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2 && sender is FrameworkElement fe && fe.DataContext is Song song)
                _vm.PlaySong(song, _vm.DownloadedSongs);
        }

        private void DownloadList_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if ((e.OriginalSource as FrameworkElement)?.DataContext is Song song)
                _vm.PlaySong(song, _vm.DownloadedSongs);
        }

        private void PlayDownloadedSong_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button btn && btn.Tag is Song song)
                _vm.PlaySong(song, _vm.DownloadedSongs);
        }

        // ══════════════════════════════════════════════
        // YOUTUBE DOWNLOAD
        // ══════════════════════════════════════════════
        private async void DownloadYouTube_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not System.Windows.Controls.Button btn ||
                btn.Tag is not Services.YouTubeSearchResult result) return;

            btn.IsEnabled = false;

            void SetLabel(string text) => btn.Dispatcher.Invoke(() =>
                btn.Content = new System.Windows.Controls.TextBlock
                {
                    Text = text,
                    FontSize = 10.5,
                    FontWeight = FontWeights.SemiBold,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    TextTrimming = TextTrimming.CharacterEllipsis
                });

            SetLabel("⏳ Starting...");

            try
            {
                var song = await _vm.DownloadYouTubeTrack(
                    result,
                    onProgress: pct => { if (pct > 0.05 && pct < 1) SetLabel($"⬇ {pct * 100:0}%"); },
                    onStatus: msg => SetLabel(msg));

                SetLabel("✓ Done!");
                _vm.RefreshFilteredLibrary();
                _vm.RefreshDownloads();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[UI DL] {ex}");
                SetLabel("✗ Failed");
                btn.IsEnabled = true;
                MessageBox.Show(ex.Message, "Download Failed", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // ══════════════════════════════════════════════
        // PLAYLISTS
        // ══════════════════════════════════════════════
        private void CreatePlaylist_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new CreatePlaylistDialog { Owner = this };
            if (dialog.ShowDialog() == true && !string.IsNullOrWhiteSpace(dialog.PlaylistName))
                LibraryService.Instance.CreatePlaylist(dialog.PlaylistName);
        }

        private void PlaylistCard_Click(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton != MouseButton.Left) return;
            if (sender is FrameworkElement fe && fe.DataContext is Playlist pl)
            {
                _vm.SelectedPlaylist = pl;
                SetActiveView("PlaylistDetail");
            }
        }

        private void PlaylistMenu_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button btn && btn.ContextMenu != null)
            {
                foreach (var item in btn.ContextMenu.Items.OfType<System.Windows.Controls.MenuItem>())
                    item.Tag = btn.Tag;
                btn.ContextMenu.PlacementTarget = btn;
                btn.ContextMenu.IsOpen = true;
            }
        }

        private void PlaylistRename_Click(object sender, RoutedEventArgs e)
        {
            if (sender is FrameworkElement fe && fe.Tag is Playlist pl)
                RenamePlaylist(pl);
        }

        private void PlaylistDetailRename_Click(object sender, RoutedEventArgs e)
        {
            if (_vm.SelectedPlaylist != null) RenamePlaylist(_vm.SelectedPlaylist);
        }

        private void RenamePlaylist(Playlist pl)
        {
            var dlg = new RenameDialog("Rename Playlist", pl.Name) { Owner = this };
            if (dlg.ShowDialog() == true && !string.IsNullOrWhiteSpace(dlg.NewName))
            {
                pl.Name = dlg.NewName.Trim();
                LibraryService.Instance.SaveLibrary();
            }
        }

        private void PlaylistChangeCover_Click(object sender, RoutedEventArgs e)
        {
            if (sender is FrameworkElement fe && fe.Tag is Playlist pl)
                ChangePlaylistCover(pl);
        }

        private void PlaylistDetailCover_Click(object sender, MouseButtonEventArgs e)
        {
            if (_vm.SelectedPlaylist != null) ChangePlaylistCover(_vm.SelectedPlaylist);
        }

        private void ChangePlaylistCover(Playlist pl)
        {
            var ofd = new OpenFileDialog
            {
                Title = "Choose Cover Image",
                Filter = "Images|*.jpg;*.jpeg;*.png;*.bmp;*.webp",
                Multiselect = false
            };
            if (ofd.ShowDialog() == true)
            {
                pl.CoverPath = ofd.FileName;
                LibraryService.Instance.SaveLibrary();
            }
        }

        private void PlaylistDelete_Click(object sender, RoutedEventArgs e)
        {
            if (sender is FrameworkElement fe && fe.Tag is Playlist pl)
                DeletePlaylist(pl);
        }

        private void PlaylistDetailDelete_Click(object sender, RoutedEventArgs e)
        {
            if (_vm.SelectedPlaylist != null)
            {
                DeletePlaylist(_vm.SelectedPlaylist);
                SetActiveView("Playlists");
            }
        }

        private void DeletePlaylist(Playlist pl)
        {
            var r = MessageBox.Show(
                $"Delete playlist \"{pl.Name}\"? This cannot be undone.",
                "Delete Playlist", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (r != MessageBoxResult.Yes) return;

            if (_vm.SelectedPlaylist == pl) _vm.SelectedPlaylist = null;
            LibraryService.Instance.DeletePlaylist(pl);
        }

        private void BackToPlaylists_Click(object sender, RoutedEventArgs e)
            => SetActiveView("Playlists");

        private void PlayPlaylist_Click(object sender, RoutedEventArgs e)
        {
            var pl = _vm.SelectedPlaylist;
            if (pl == null || pl.Songs.Count == 0) return;
            _vm.PlaySong(pl.Songs[0], new ObservableCollection<Song>(pl.Songs));
        }

        private void PlaylistSong_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if ((e.OriginalSource as FrameworkElement)?.DataContext is Song song && _vm.SelectedPlaylist != null)
                _vm.PlaySong(song, new ObservableCollection<Song>(_vm.SelectedPlaylist.Songs));
        }

        private void AddSongsToPlaylist_Click(object sender, RoutedEventArgs e)
        {
            var pl = _vm.SelectedPlaylist;
            if (pl == null) return;

            var available = LibraryService.Instance.Songs
                .Where(s => !pl.Songs.Contains(s)).ToList();

            if (available.Count == 0)
            {
                MessageBox.Show("All songs are already in this playlist.", "Add Songs",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var picker = new AddSongsDialog(available) { Owner = this };
            if (picker.ShowDialog() == true && picker.SelectedSongs.Count > 0)
                foreach (var s in picker.SelectedSongs)
                    LibraryService.Instance.AddSongToPlaylist(pl, s);
        }

        private void RemoveFromPlaylist_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button btn &&
                btn.Tag is Song song && _vm.SelectedPlaylist != null)
                LibraryService.Instance.RemoveSongFromPlaylist(_vm.SelectedPlaylist, song);
        }

        // ══════════════════════════════════════════════
        // SONG CONTEXT MENU (right-click)
        // ══════════════════════════════════════════════
        private void SongContextMenu_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not System.Windows.Controls.MenuItem menuItem) return;

            // Walk up to find the ListBoxItem DataContext
            var contextMenu = menuItem.Parent as System.Windows.Controls.ContextMenu;
            if (contextMenu?.PlacementTarget is not FrameworkElement target) return;

            // The placement target is the ListBoxItem — get its DataContext
            var song = (target.DataContext
                     ?? (target as System.Windows.Controls.ListBoxItem)?.Content)
                     as Song;

            // Fallback: walk up visual tree
            if (song == null)
            {
                var el = target as DependencyObject;
                while (el != null && song == null)
                {
                    if (el is FrameworkElement fe && fe.DataContext is Song s) song = s;
                    el = System.Windows.Media.VisualTreeHelper.GetParent(el);
                }
            }

            if (song == null) return;

            switch (menuItem.Tag as string)
            {
                case "Play":
                    _vm.PlaySong(song);
                    break;
                case "PlayNext":
                    _vm.PlayNextSong(song);
                    // Show queue panel so user sees the result
                    _vm.ShowQueue = true;
                    break;
                case "AddToQueue":
                    _vm.AddSongToQueue(song);
                    _vm.ShowQueue = true;
                    break;
                case "Favorite":
                    song.IsFavorite = !song.IsFavorite;
                    LibraryService.Instance.SaveLibrary();
                    break;
                case "Remove":
                    ConfirmDeleteSong(song);
                    break;
            }
        }

        // ══════════════════════════════════════════════
        // LIBRARY — SORT, IMPORT, EXPORT, SMART PLAYLISTS
        // ══════════════════════════════════════════════
        private void SortByTitle_Click(object sender, RoutedEventArgs e)    => _vm.SortBy = "Title";
        private void SortByArtist_Click(object sender, RoutedEventArgs e)   => _vm.SortBy = "Artist";
        private void SortByDuration_Click(object sender, RoutedEventArgs e) => _vm.SortBy = "Duration";
        private void SortByPlays_Click(object sender, RoutedEventArgs e)    => _vm.SortBy = "PlayCount";

        private void ImportFolder_Click(object sender, RoutedEventArgs e)
        {
            using var dlg = new System.Windows.Forms.FolderBrowserDialog
            {
                Description = "Select a folder to import music from",
                UseDescriptionForTitle = true
            };
            if (dlg.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            var added = LibraryService.Instance.ImportFolder(dlg.SelectedPath);
            _vm.RefreshFilteredLibrary();
            _vm.RefreshDownloads();

            MessageBox.Show($"Imported {added.Count} song(s) from folder.",
                "Import Complete", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ExportLibrary_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new Microsoft.Win32.SaveFileDialog
            {
                Title = "Export Library",
                Filter = "DeadFy Library|*.dflib|JSON|*.json",
                FileName = $"DeadFy_Library_{DateTime.Now:yyyyMMdd}"
            };
            if (dlg.ShowDialog() != true) return;
            try
            {
                LibraryService.Instance.ExportLibrary(dlg.FileName);
                MessageBox.Show("Library exported successfully!", "Export", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Export failed: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ImportLibrary_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new Microsoft.Win32.OpenFileDialog
            {
                Title = "Import Library",
                Filter = "DeadFy Library|*.dflib|JSON|*.json"
            };
            if (dlg.ShowDialog() != true) return;
            try
            {
                int count = LibraryService.Instance.ImportLibrary(dlg.FileName);
                _vm.RefreshFilteredLibrary();
                _vm.RefreshDownloads();
                MessageBox.Show($"Imported {count} new song(s).", "Import", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Import failed: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void SmartPlaylists_Click(object sender, RoutedEventArgs e)
        {
            var lib = LibraryService.Instance;
            int created = 0;

            void TryCreate(string name, System.Collections.Generic.List<Models.Song> songs)
            {
                if (songs.Count == 0) return;
                // Remove old smart playlist with same name
                var existing = lib.Playlists.FirstOrDefault(p => p.Name == name);
                if (existing != null) lib.DeletePlaylist(existing);
                var pl = lib.CreatePlaylist(name);
                foreach (var s in songs) lib.AddSongToPlaylist(pl, s);
                created++;
            }

            TryCreate("✨ Most Played",     lib.GetMostPlayed(25));
            TryCreate("🆕 Recently Added",  lib.GetRecentlyAdded(25));
            TryCreate("❤️ Favorites",        lib.GetFavorites());
            TryCreate("🎲 Never Played",    lib.GetNeverPlayed());

            MessageBox.Show($"Created {created} smart playlist(s)! Check your Playlists.",
                "Smart Playlists", MessageBoxButton.OK, MessageBoxImage.Information);
            SetActiveView("Playlists");
        }

        // ══════════════════════════════════════════════
        // SEARCH SUGGESTIONS
        // ══════════════════════════════════════════════
        private void SearchBox_LostFocus(object sender, RoutedEventArgs e)
        {
            // Small delay so click on suggestion registers first
            _ = System.Threading.Tasks.Task.Delay(200).ContinueWith(_ =>
                Dispatcher.Invoke(() => { if (SuggestionsPopup != null) SuggestionsPopup.IsOpen = false; }));
        }

        private void Suggestion_Click(object sender, MouseButtonEventArgs e)
        {
            if (sender is FrameworkElement fe && fe.DataContext is string suggestion)
            {
                // Extract just the title part (before " – ")
                var title = suggestion.Split(" – ")[0].Trim();
                _vm.SearchQuery = title;
                if (SuggestionsPopup != null) SuggestionsPopup.IsOpen = false;
                _vm.TriggerSearch();
            }
        }

        // ══════════════════════════════════════════════
        // BULK SELECT
        // ══════════════════════════════════════════════
        private void BulkSelectToggle_Click(object sender, RoutedEventArgs e)
        {
            _vm.IsBulkMode = !_vm.IsBulkMode;
            BulkSelectToggleBtn.Content = _vm.IsBulkMode ? "✓  Done" : "☐  Select";
        }

        private void BulkCheckbox_Click(object sender, RoutedEventArgs e)
        {
            // IsBulkSelected is bound TwoWay; just refresh the count
            _vm.OnPropertyChanged("BulkSelectedCount");
            e.Handled = true;  // don't also fire row double-click
        }

        private void SelectAllCheckbox_Click(object sender, RoutedEventArgs e)
        {
            bool check = (sender as System.Windows.Controls.CheckBox)?.IsChecked == true;
            if (check) _vm.SelectAllSongs();
            else        _vm.DeselectAllSongs();
        }

        private void BulkSelectAll_Click(object sender, RoutedEventArgs e)
            => _vm.SelectAllSongs();

        private void BulkDeselectAll_Click(object sender, RoutedEventArgs e)
            => _vm.DeselectAllSongs();

        private void BulkDelete_Click(object sender, RoutedEventArgs e)
        {
            var selected = _vm.GetBulkSelected();
            if (selected.Count == 0) return;

            var r = MessageBox.Show(
                $"Delete {selected.Count} song(s) from your library? This will also delete the files from disk.",
                "Delete Songs", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (r != MessageBoxResult.Yes) return;

            foreach (var song in selected)
            {
                if (AudioPlayerService.Instance.CurrentSong?.Id == song.Id)
                    AudioPlayerService.Instance.Stop();
                LibraryService.Instance.RemoveSong(song);
            }
            _vm.IsBulkMode = false;
            BulkSelectToggleBtn.Content = "☐  Select";
            _vm.RefreshFilteredLibrary();
            _vm.RefreshDownloads();
        }

        private void BulkAddToPlaylist_Click(object sender, RoutedEventArgs e)
        {
            var selected = _vm.GetBulkSelected();
            if (selected.Count == 0)
            {
                MessageBox.Show("No songs selected.", "Bulk Add", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            // Pick playlist
            var playlists = LibraryService.Instance.Playlists.ToList();
            if (playlists.Count == 0)
            {
                MessageBox.Show("You have no playlists yet. Create one first.", "Bulk Add",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            // Simple picker dialog using built-in InputBox pattern
            var picker = new Views.Dialogs.PlaylistPickerDialog(playlists) { Owner = this };
            if (picker.ShowDialog() != true || picker.SelectedPlaylist == null) return;

            int added = 0;
            foreach (var song in selected)
            {
                LibraryService.Instance.AddSongToPlaylist(picker.SelectedPlaylist, song);
                added++;
            }

            _vm.IsBulkMode = false;
            BulkSelectToggleBtn.Content = "☐  Select";
            MessageBox.Show($"Added {added} song(s) to \"{picker.SelectedPlaylist.Name}\".",
                "Done", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        // ══════════════════════════════════════════════
        // OFFLINE MODE
        // ══════════════════════════════════════════════
        private void ToggleOfflineMode_Click(object sender, RoutedEventArgs e)
            => _vm.IsOfflineMode = !_vm.IsOfflineMode;

        // ══════════════════════════════════════════════
        // STREAM PLAY (online without download)
        // ══════════════════════════════════════════════
        private async void StreamYouTube_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not System.Windows.Controls.Button btn ||
                btn.Tag is not Services.YouTubeSearchResult result) return;

            if (_vm.IsOfflineMode)
            {
                MessageBox.Show("Cannot stream in Offline Mode.", "Offline", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            btn.IsEnabled = false;
            var origContent = btn.Content;
            btn.Content = new System.Windows.Controls.TextBlock
            {
                Text = "⏳ Loading...", FontSize = 11, FontWeight = FontWeights.SemiBold
            };

            try
            {
                await _vm.StreamYouTubeTrack(result);
                btn.Content = new System.Windows.Controls.TextBlock
                {
                    Text = "▶ Playing", FontSize = 11, FontWeight = FontWeights.SemiBold
                };
            }
            catch (Exception ex)
            {
                btn.Content = origContent;
                btn.IsEnabled = true;
                MessageBox.Show($"Stream failed: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // ══════════════════════════════════════════════
        // RECENTLY PLAYED — remove button
        // ══════════════════════════════════════════════
        private void RemoveFromRecent_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button btn && btn.Tag is Song song)
                _vm.RemoveFromRecentlyPlayed(song);
        }


        // ══════════════════════════════════════════════
        // IMPORT SPOTIFY PLAYLIST
        // ══════════════════════════════════════════════
        private async void ImportSpotifyPlaylist_Click(object sender, RoutedEventArgs e)
        {
            if (!Services.SpotifyService.Instance.IsLoggedIn)
            {
                MessageBox.Show("Connect your Spotify account in Settings first.",
                    "Not Connected", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            // Simple inline input dialog
            var inputDlg = new Views.Dialogs.RenameDialog("Import Spotify Playlist", "") { Owner = this };
            if (inputDlg.ShowDialog() != true) return;
            var input = inputDlg.NewName;
            if (string.IsNullOrWhiteSpace(input)) return;

            // Show a progress window via a simple status MessageBox approach —
            // use a non-blocking status update on the button itself
            if (sender is System.Windows.Controls.Button btn)
            {
                btn.IsEnabled = false;
                var origContent = btn.Content;

                void Status(string msg) => Dispatcher.Invoke(() => btn.Content = msg);

                try
                {
                    var (added, failed) = await _vm.ImportSpotifyPlaylistAsync(
                        input, onStatus: Status);

                    _vm.RefreshFilteredLibrary();
                    MessageBox.Show(
                        $"Import complete!\n\n✅ {added} songs added\n❌ {failed} not found on YouTube",
                        "Spotify Import", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Import failed: {ex.Message}",
                        "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                finally
                {
                    btn.IsEnabled = true;
                    btn.Content = origContent;
                }
            }
        }

        // ══════════════════════════════════════════════
        // KEYBOARD SHORTCUTS
        // ══════════════════════════════════════════════
        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            // Don't fire shortcuts when user is typing in a TextBox
            if (e.OriginalSource is System.Windows.Controls.TextBox ||
                e.OriginalSource is System.Windows.Controls.PasswordBox) return;

            switch (e.Key)
            {
                case Key.Space:
                    AudioPlayerService.Instance.TogglePlayPause();
                    e.Handled = true;
                    break;
                case Key.Right:
                    if (Keyboard.Modifiers == ModifierKeys.None)
                    { AudioPlayerService.Instance.PositionSeconds += 5; e.Handled = true; }
                    else if (Keyboard.Modifiers == ModifierKeys.Control)
                    { _vm.PlayNext(); e.Handled = true; }
                    break;
                case Key.Left:
                    if (Keyboard.Modifiers == ModifierKeys.None)
                    { AudioPlayerService.Instance.PositionSeconds = Math.Max(0, AudioPlayerService.Instance.PositionSeconds - 5); e.Handled = true; }
                    else if (Keyboard.Modifiers == ModifierKeys.Control)
                    { _vm.PlayPrevious(); e.Handled = true; }
                    break;
                case Key.Up:
                    AudioPlayerService.Instance.Volume = Math.Min(1f, AudioPlayerService.Instance.Volume + 0.05f);
                    e.Handled = true;
                    break;
                case Key.Down:
                    AudioPlayerService.Instance.Volume = Math.Max(0f, AudioPlayerService.Instance.Volume - 0.05f);
                    e.Handled = true;
                    break;
                case Key.M:
                    AudioPlayerService.Instance.Volume = AudioPlayerService.Instance.Volume > 0 ? 0 : 0.8f;
                    e.Handled = true;
                    break;
                case Key.L:
                    LyricsButton_Click(sender, new RoutedEventArgs());
                    e.Handled = true;
                    break;
                case Key.Q:
                    _vm.ShowQueue = !_vm.ShowQueue;
                    e.Handled = true;
                    break;
            }
        }

        // ══════════════════════════════════════════════
        // PLAYER
        // ══════════════════════════════════════════════
        private void PlayPauseButton_Click(object sender, RoutedEventArgs e)
        {
            if (AudioPlayerService.Instance.CurrentSong != null)
                AudioPlayerService.Instance.TogglePlayPause();
        }

        private void PreviousButton_Click(object sender, RoutedEventArgs e) => _vm.PlayPrevious();
        private void NextButton_Click(object sender, RoutedEventArgs e) => _vm.PlayNext();

        // ── Taskbar thumbnail toolbar ────────────────────────────────────
        private void ThumbPrev_Click(object sender, EventArgs e)      => _vm.PlayPrevious();
        private void ThumbNext_Click(object sender, EventArgs e)      => _vm.PlayNext();
        private void ThumbPlayPause_Click(object sender, EventArgs e) => AudioPlayerService.Instance.TogglePlayPause();

        private void UpdateTaskbarButtons()
        {
            var player  = AudioPlayerService.Instance;
            bool playing = player.IsPlaying;

            // Swap the play/pause icon depending on state
            ThumbPlayPause.ImageSource = playing
                ? MakeSymbolIcon("⏸", 48)   // pause
                : MakeSymbolIcon("▶", 48);   // play

            ThumbPrev.ImageSource = MakeSymbolIcon("⏮", 48);
            ThumbNext.ImageSource = MakeSymbolIcon("⏭", 48);
        }

        /// <summary>
        /// Renders a text symbol into a 48×48 BitmapSource so we don't need
        /// external PNG files for the taskbar thumbnail buttons.
        /// </summary>
        private static BitmapSource MakeSymbolIcon(string symbol, int size)
        {
            var dv = new DrawingVisual();
            using (var dc = dv.RenderOpen())
            {
                dc.DrawRectangle(Brushes.Transparent, null, new Rect(0, 0, size, size));
                var ft = new FormattedText(
                    symbol,
                    System.Globalization.CultureInfo.InvariantCulture,
                    FlowDirection.LeftToRight,
                    new Typeface("Segoe UI Symbol"),
                    size * 0.55,
                    Brushes.White,
                    VisualTreeHelper.GetDpi(dv).PixelsPerDip);
                dc.DrawText(ft, new Point(
                    (size - ft.Width)  / 2,
                    (size - ft.Height) / 2));
            }
            var rtb = new RenderTargetBitmap(size, size, 96, 96, PixelFormats.Pbgra32);
            rtb.Render(dv);
            rtb.Freeze();
            return rtb;
        }

        private void ShuffleButton_Click(object sender, RoutedEventArgs e)
            => AudioPlayerService.Instance.IsShuffle = !AudioPlayerService.Instance.IsShuffle;

        private void RepeatButton_Click(object sender, RoutedEventArgs e)
            => AudioPlayerService.Instance.RepeatMode =
                (RepeatMode)(((int)AudioPlayerService.Instance.RepeatMode + 1) % 3);
    }
}