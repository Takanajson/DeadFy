using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using DeadFy.Services;

namespace DeadFy.Views
{
    public partial class KaraokeLyricsPanel : UserControl
    {
        // ── Public events ──────────────────────────────────────────────
        public event EventHandler<TimeSpan>? LineClicked;

        // ── State ──────────────────────────────────────────────────────
        private List<LyricLine> _lines      = new();
        private List<TextBlock> _blocks     = new();
        private int             _currentIdx = -1;
        private bool            _hasSynced;

        // ── Theme accent ───────────────────────────────────────────────
        private Color _accent = Color.FromRgb(0x1D, 0xB9, 0x54);

        public Color AccentColor
        {
            get => _accent;
            set
            {
                _accent = value;
                RefreshActiveGlow();
            }
        }

        public KaraokeLyricsPanel()
        {
            InitializeComponent();
        }

        // ── Public API ─────────────────────────────────────────────────
        public void ShowLoading()
        {
            LyricsStack.Children.Clear();
            _blocks.Clear();
            _lines.Clear();
            _currentIdx = -1;
            _hasSynced  = false;

            LoadingText.Visibility   = Visibility.Visible;
            NoLyricsPanel.Visibility = Visibility.Collapsed;
            LyricsScroll.Visibility  = Visibility.Collapsed;
        }

        public void SetLyrics(LyricsResult result)
        {
            LoadingText.Visibility = Visibility.Collapsed;
            LyricsStack.Children.Clear();
            _blocks.Clear();
            _lines.Clear();
            _currentIdx = -1;

            _hasSynced = result.HasSync;

            if (!result.HasSync && string.IsNullOrWhiteSpace(result.PlainLyrics))
            {
                NoLyricsPanel.Visibility = Visibility.Visible;
                LyricsScroll.Visibility  = Visibility.Collapsed;
                return;
            }

            NoLyricsPanel.Visibility = Visibility.Collapsed;
            LyricsScroll.Visibility  = Visibility.Visible;

            if (result.HasSync)
            {
                _lines = result.SyncedLines;
                foreach (var line in _lines)
                {
                    var tb = BuildLineBlock(line.Text, isClickable: true);
                    ApplyIdleStyle(tb);
                    LyricsStack.Children.Add(tb);
                    _blocks.Add(tb);
                }
            }
            else
            {
                // Plain lyrics — display nicely, no sync
                foreach (var l in result.PlainLyrics.Split('\n'))
                {
                    var tb = BuildLineBlock(l.Trim(), isClickable: false);
                    ApplyIdleStyle(tb);
                    LyricsStack.Children.Add(tb);
                    _blocks.Add(tb);
                }
            }
        }

        /// <summary>Called every ~250ms with playback position — updates active line.</summary>
        public void UpdatePosition(TimeSpan position)
        {
            if (!_hasSynced || _lines.Count == 0) return;

            int newIdx = -1;
            for (int i = 0; i < _lines.Count; i++)
            {
                if (_lines[i].Time <= position) newIdx = i;
                else break;
            }

            if (newIdx == _currentIdx) return;

            // Fade out old
            if (_currentIdx >= 0 && _currentIdx < _blocks.Count)
                AnimateToIdle(_blocks[_currentIdx]);

            _currentIdx = newIdx;

            // Glow new
            if (_currentIdx >= 0 && _currentIdx < _blocks.Count)
            {
                AnimateToActive(_blocks[_currentIdx]);
                DimNeighbours(_currentIdx);
                SmoothScrollTo(_blocks[_currentIdx]);
            }
        }

        public void Clear()
        {
            LyricsStack.Children.Clear();
            _blocks.Clear();
            _lines.Clear();
            _currentIdx = -1;
            LoadingText.Visibility   = Visibility.Collapsed;
            NoLyricsPanel.Visibility = Visibility.Visible;
            LyricsScroll.Visibility  = Visibility.Collapsed;
        }

        // ── Block builder ──────────────────────────────────────────────
        private TextBlock BuildLineBlock(string text, bool isClickable)
        {
            bool isEmpty = string.IsNullOrWhiteSpace(text);

            var tb = new TextBlock
            {
                Text                = isEmpty ? "· · ·" : text,
                FontSize            = isEmpty ? 14 : 19,
                FontWeight          = isEmpty ? FontWeights.Normal : FontWeights.Bold,
                TextAlignment       = TextAlignment.Center,
                TextWrapping        = TextWrapping.Wrap,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, isEmpty ? 2 : 8, 0, isEmpty ? 2 : 8),
                Padding             = new Thickness(16, 8, 16, 8),
                Cursor              = isClickable && !isEmpty ? Cursors.Hand : Cursors.Arrow,
            };

            int idx = _blocks.Count;
            if (isClickable && !isEmpty)
            {
                tb.Tag = idx;
                tb.MouseLeftButtonDown += LineBlock_Click;

                // Hover glow hint
                tb.MouseEnter += (_, _) =>
                {
                    if ((int?)tb.Tag != _currentIdx)
                    {
                        tb.Opacity = 0.85;
                        tb.Effect  = new DropShadowEffect
                        {
                            Color       = _accent,
                            BlurRadius  = 10,
                            ShadowDepth = 0,
                            Opacity     = 0.4
                        };
                    }
                };
                tb.MouseLeave += (_, _) =>
                {
                    if ((int?)tb.Tag != _currentIdx)
                    {
                        ApplyIdleStyle(tb);
                        DimNeighbours(_currentIdx);
                    }
                };
            }

            return tb;
        }

        // ── Styling ────────────────────────────────────────────────────
        private static readonly Color IdleColor   = Color.FromArgb(70,  255, 255, 255);
        private static readonly Color FarColor    = Color.FromArgb(35,  255, 255, 255);

        private void ApplyIdleStyle(TextBlock tb)
        {
            tb.Foreground      = new SolidColorBrush(IdleColor);
            tb.FontSize        = string.IsNullOrWhiteSpace(tb.Text) || tb.Text == "· · ·" ? 14 : 19;
            tb.Effect          = null;
            tb.Opacity         = 1.0;
            tb.RenderTransform = Transform.Identity;
        }

        private void AnimateToIdle(TextBlock tb)
        {
            // Colour fade: accent → idle white
            var brush = new SolidColorBrush(_accent);
            tb.Foreground = brush;

            var colorAnim = new ColorAnimation(IdleColor, TimeSpan.FromMilliseconds(500))
            {
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            brush.BeginAnimation(SolidColorBrush.ColorProperty, colorAnim);

            // Fade opacity
            tb.BeginAnimation(OpacityProperty,
                new DoubleAnimation(1.0, 0.38, TimeSpan.FromMilliseconds(450)));

            // Clear glow
            tb.Effect = null;
            tb.RenderTransform = Transform.Identity;
        }

        private void AnimateToActive(TextBlock tb)
        {
            // Stop any in-progress animations
            tb.BeginAnimation(OpacityProperty, null);
            tb.Opacity = 1.0;

            // Smooth colour transition to accent
            var brush = new SolidColorBrush(IdleColor);
            tb.Foreground = brush;

            var colorAnim = new ColorAnimation(_accent, TimeSpan.FromMilliseconds(300))
            {
                EasingFunction = new SineEase { EasingMode = EasingMode.EaseOut }
            };
            brush.BeginAnimation(SolidColorBrush.ColorProperty, colorAnim);

            // Pulsing glow effect — blooms then settles
            var glow = new DropShadowEffect
            {
                Color       = _accent,
                BlurRadius  = 6,
                ShadowDepth = 0,
                Opacity     = 0.0
            };
            tb.Effect = glow;

            // Opacity bloom: 0 → 1.0 → 0.85 (settles)
            var glowAnim = new DoubleAnimation(1.0, TimeSpan.FromMilliseconds(200))
            {
                AutoReverse    = false,
                EasingFunction = new SineEase { EasingMode = EasingMode.EaseOut }
            };
            glow.BeginAnimation(DropShadowEffect.OpacityProperty, glowAnim);

            // Blur bloom: small → big → settles
            var blurAnim = new DoubleAnimation(6, 36, TimeSpan.FromMilliseconds(300))
            {
                AutoReverse    = true,
                EasingFunction = new SineEase { EasingMode = EasingMode.EaseOut }
            };
            blurAnim.Completed += (_, _) =>
            {
                glow.BlurRadius = 22;
            };
            glow.BeginAnimation(DropShadowEffect.BlurRadiusProperty, blurAnim);

            // Scale-up pulse
            var st = new ScaleTransform(0.95, 0.95);
            tb.RenderTransform       = st;
            tb.RenderTransformOrigin = new Point(0.5, 0.5);

            var scaleAnim = new DoubleAnimation(0.95, 1.07, TimeSpan.FromMilliseconds(180))
            {
                AutoReverse    = true,
                EasingFunction = new SineEase { EasingMode = EasingMode.EaseOut }
            };
            scaleAnim.Completed += (_, _) => st.ScaleX = st.ScaleY = 1.0;
            st.BeginAnimation(ScaleTransform.ScaleXProperty, scaleAnim);
            st.BeginAnimation(ScaleTransform.ScaleYProperty,
                new DoubleAnimation(0.95, 1.07, TimeSpan.FromMilliseconds(180))
                {
                    AutoReverse    = true,
                    EasingFunction = new SineEase { EasingMode = EasingMode.EaseOut }
                });
        }

        /// <summary>Dim blocks based on distance from active — nearest = half-bright, far = very dim.</summary>
        private void DimNeighbours(int activeIdx)
        {
            for (int i = 0; i < _blocks.Count; i++)
            {
                if (i == activeIdx) continue;
                int    dist = Math.Abs(i - activeIdx);
                double op   = dist == 1 ? 0.50 : dist == 2 ? 0.32 : 0.18;
                _blocks[i].BeginAnimation(OpacityProperty,
                    new DoubleAnimation(op, TimeSpan.FromMilliseconds(350)));
            }
        }

        private void RefreshActiveGlow()
        {
            if (_currentIdx < 0 || _currentIdx >= _blocks.Count) return;
            var tb = _blocks[_currentIdx];
            if (tb.Foreground is SolidColorBrush b) b.Color = _accent;
            if (tb.Effect is DropShadowEffect dse) dse.Color = _accent;
        }

        // ── Smooth scroll to centred active line ───────────────────────
        private void SmoothScrollTo(TextBlock tb)
        {
            try
            {
                tb.UpdateLayout();
                var transform   = tb.TransformToAncestor(LyricsStack);
                var pos         = transform.Transform(new Point(0, 0));
                double center   = pos.Y + tb.ActualHeight / 2.0;
                double target   = center - LyricsScroll.ActualHeight / 2.0;
                target          = Math.Max(0, target);

                var anim = new DoubleAnimation(LyricsScroll.VerticalOffset, target,
                    TimeSpan.FromMilliseconds(550))
                { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseInOut } };

                var sb = new Storyboard();
                sb.Children.Add(anim);
                Storyboard.SetTarget(anim, LyricsScroll);
                Storyboard.SetTargetProperty(anim, new PropertyPath(ScrollViewerBehavior.VerticalOffsetProperty));
                sb.Begin();
            }
            catch { /* non-fatal */ }
        }

        // ── Line click → seek ──────────────────────────────────────────
        private void LineBlock_Click(object sender, MouseButtonEventArgs e)
        {
            if (sender is not TextBlock tb) return;
            if (tb.Tag is not int idx) return;
            if (idx < 0 || idx >= _lines.Count) return;

            // Visual feedback: brief white flash
            var brush = tb.Foreground as SolidColorBrush ?? new SolidColorBrush(_accent);
            tb.Foreground = brush;
            var flash = new ColorAnimation(Colors.White, _accent, TimeSpan.FromMilliseconds(350));
            brush.BeginAnimation(SolidColorBrush.ColorProperty, flash);

            LineClicked?.Invoke(this, _lines[idx].Time);
            e.Handled = true;
        }
    }

    // ── Animated ScrollViewer helper ──────────────────────────────────────
    public static class ScrollViewerBehavior
    {
        public static readonly DependencyProperty VerticalOffsetProperty =
            DependencyProperty.RegisterAttached(
                "VerticalOffset",
                typeof(double),
                typeof(ScrollViewerBehavior),
                new UIPropertyMetadata(0.0, OnVerticalOffsetChanged));

        public static double GetVerticalOffset(DependencyObject obj)
            => (double)obj.GetValue(VerticalOffsetProperty);
        public static void SetVerticalOffset(DependencyObject obj, double value)
            => obj.SetValue(VerticalOffsetProperty, value);

        private static void OnVerticalOffsetChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is ScrollViewer sv) sv.ScrollToVerticalOffset((double)e.NewValue);
        }
    }
}
