using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using DeadFy.Models;

namespace DeadFy.Plugins
{
    // ══════════════════════════════════════════════════════════════════
    //  PLUGIN CONTRACT  —  DeadFy Plugin SDK
    //
    //  To create a plugin:
    //    1. Create a .NET 8 Class Library project
    //    2. Reference DeadFy.exe (or copy these interfaces into your project)
    //    3. Implement one or more interfaces below
    //    4. Add [TakanaPlugin] attribute to your main class
    //    5. Build → copy the .dll into the app's  Plugins/  folder
    //    6. DeadFy loads it automatically on next launch (or hot-reload)
    // ══════════════════════════════════════════════════════════════════

    /// <summary>
    /// Required attribute. Mark exactly one class per DLL with this.
    /// DeadFy uses it as the plugin entry point.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, Inherited = false)]
    public sealed class TakanaPluginAttribute : Attribute
    {
        public string Name        { get; }
        public string Version     { get; }
        public string Author      { get; }
        public string Description { get; }

        public TakanaPluginAttribute(
            string name,
            string version    = "1.0.0",
            string author     = "Unknown",
            string description = "")
        {
            Name        = name;
            Version     = version;
            Author      = author;
            Description = description;
        }
    }

    // ──────────────────────────────────────────────────────────────────
    //  BASE INTERFACE  (all plugins must implement this)
    // ──────────────────────────────────────────────────────────────────

    public interface ITakanaPlugin : IDisposable
    {
        /// <summary>Called once when the plugin is loaded. Use to subscribe to events.</summary>
        void Initialize(IPluginHost host);

        /// <summary>Called when the plugin is unloaded / app exits. Clean up resources.</summary>
        void Shutdown();
    }

    // ──────────────────────────────────────────────────────────────────
    //  HOST API  (what plugins can access from the app)
    // ──────────────────────────────────────────────────────────────────

    public interface IPluginHost
    {
        // ── Events the plugin can subscribe to ────────────────────────
        event EventHandler<Song?>  SongChanged;
        event EventHandler<bool>   PlaybackStateChanged;   // true = playing
        event EventHandler<double> PositionChanged;        // seconds
        event EventHandler<double> VolumeChanged;          // 0.0–1.0

        // ── Playback control ─────────────────────────────────────────
        Song?   CurrentSong    { get; }
        bool    IsPlaying      { get; }
        double  PositionSeconds { get; set; }
        double  Volume         { get; set; }
        void    Play();
        void    Pause();
        void    Next();
        void    Previous();

        // ── Library access ────────────────────────────────────────────
        IReadOnlyList<Song>     Library     { get; }
        IReadOnlyList<Playlist> Playlists   { get; }
        void AddSongToLibrary(Song song);

        // ── UI helpers ────────────────────────────────────────────────
        /// <summary>Show a toast notification in the player UI.</summary>
        void ShowNotification(string message, NotificationKind kind = NotificationKind.Info);

        /// <summary>Register a settings panel that appears in Settings → Plugins.</summary>
        void RegisterSettingsPanel(string pluginName, UIElement panel);

        /// <summary>Log a message to the plugin debug console.</summary>
        void Log(string message, LogLevel level = LogLevel.Info);
    }

    // ──────────────────────────────────────────────────────────────────
    //  OPTIONAL EXTENSION INTERFACES
    //  Implement whichever match what your plugin does.
    // ──────────────────────────────────────────────────────────────────

    /// <summary>
    /// Audio processing plugin. Receives raw PCM samples and can transform them.
    /// Example: custom EQ, noise reduction, spatial audio, limiter.
    /// </summary>
    public interface IAudioPlugin : ITakanaPlugin
    {
        string ProcessorName { get; }
        int    Priority      { get; }  // lower = runs first in the chain

        /// <summary>Called for each audio buffer. Modify samples in-place.</summary>
        void ProcessAudio(float[] samples, int sampleRate, int channels);

        /// <summary>True when this processor should be active.</summary>
        bool IsEnabled { get; set; }
    }

    /// <summary>
    /// Lyrics provider plugin. Return synced or plain lyrics for a song.
    /// DeadFy will try all registered lyrics plugins in priority order
    /// before falling back to LRCLIB.
    /// </summary>
    public interface ILyricsPlugin : ITakanaPlugin
    {
        string ProviderName { get; }
        int    Priority     { get; }  // lower = tried first

        Task<LyricsData?> GetLyricsAsync(string title, string artist,
            CancellationToken ct = default);
    }

    /// <summary>
    /// Search provider plugin. Add new search sources to the Search tab.
    /// Example: SoundCloud search, Bandcamp search, local NAS search.
    /// </summary>
    public interface ISearchPlugin : ITakanaPlugin
    {
        string SourceName  { get; }  // shown as a tab in Search
        string SourceIcon  { get; }  // emoji or short string

        Task<IReadOnlyList<SearchResult>> SearchAsync(string query,
            CancellationToken ct = default);

        /// <summary>Download or stream the result.</summary>
        Task<Song?> ResolveAsync(SearchResult result,
            IProgress<double>? progress = null,
            CancellationToken ct = default);
    }

    /// <summary>
    /// Metadata enricher plugin. Called when a song is added to the library.
    /// Example: fetch BPM, key, mood tags, or album art from external API.
    /// </summary>
    public interface IMetadataPlugin : ITakanaPlugin
    {
        string EnricherName { get; }

        /// <summary>
        /// Enrich the song with additional metadata.
        /// Modify the song object directly.
        /// </summary>
        Task EnrichAsync(Song song, CancellationToken ct = default);
    }

    // ──────────────────────────────────────────────────────────────────
    //  DATA TRANSFER OBJECTS
    // ──────────────────────────────────────────────────────────────────

    public class LyricsData
    {
        public string              PlainLyrics  { get; set; } = string.Empty;
        public List<LyricLineData> SyncedLines  { get; set; } = new();
        public bool                HasSync      => SyncedLines.Count > 0;
    }

    public class LyricLineData
    {
        public TimeSpan Time { get; set; }
        public string   Text { get; set; } = string.Empty;
    }

    public class SearchResult
    {
        public string   Id           { get; set; } = string.Empty;
        public string   Title        { get; set; } = string.Empty;
        public string   Author       { get; set; } = string.Empty;
        public TimeSpan Duration     { get; set; }
        public string   ThumbnailUrl { get; set; } = string.Empty;
        public string   Url          { get; set; } = string.Empty;
        public string   Source       { get; set; } = string.Empty;
        public object?  Extra        { get; set; }  // plugin-specific data
    }

    public enum NotificationKind { Info, Success, Warning, Error }
    public enum LogLevel         { Debug, Info, Warning, Error }
}
