using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace DeadFy.Models
{
    public class Song : INotifyPropertyChanged
    {
        // ── Backing fields ────────────────────────────────────────────────────
        private string    _title      = string.Empty;
        private string    _artist     = string.Empty;
        private string    _album      = string.Empty;
        private string    _filePath   = string.Empty;
        private string?   _coverPath;
        private string?   _thumbnailUrl;
        private TimeSpan  _duration;
        private bool      _isFavorite;
        private SongSource _source;
        private int       _playCount;
        private bool      _isBulkSelected;

        // ── Identity ──────────────────────────────────────────────────────────
        public string Id { get; set; } = Guid.NewGuid().ToString();

        // ── Core metadata ─────────────────────────────────────────────────────
        public string Title
        {
            get => _title;
            set { _title = value; OnPropertyChanged(); OnPropertyChanged(nameof(DisplayTitle)); }
        }

        public string Artist
        {
            get => _artist;
            set { _artist = value; OnPropertyChanged(); OnPropertyChanged(nameof(DisplayArtist)); }
        }

        public string Album
        {
            get => _album;
            set { _album = value; OnPropertyChanged(); }
        }

        public string FilePath
        {
            get => _filePath;
            set { _filePath = value; OnPropertyChanged(); }
        }

        public string? CoverPath
        {
            get => _coverPath;
            set { _coverPath = value; OnPropertyChanged(); }
        }

        public string? ThumbnailUrl
        {
            get => _thumbnailUrl;
            set { _thumbnailUrl = value; OnPropertyChanged(); }
        }

        // ── Playback state ────────────────────────────────────────────────────
        public TimeSpan Duration
        {
            get => _duration;
            set { _duration = value; OnPropertyChanged(); OnPropertyChanged(nameof(DurationText)); }
        }

        public bool IsFavorite
        {
            get => _isFavorite;
            set { _isFavorite = value; OnPropertyChanged(); }
        }

        public SongSource Source
        {
            get => _source;
            set { _source = value; OnPropertyChanged(); }
        }

        public int PlayCount
        {
            get => _playCount;
            set { _playCount = value; OnPropertyChanged(); OnPropertyChanged(nameof(PlayCountText)); }
        }

        // ── Streaming ─────────────────────────────────────────────────────────

        /// <summary>True when the file is streamed from a URL rather than a local path.</summary>
        public bool IsStreaming { get; set; } = false;

        /// <summary>Direct stream URL (YouTube CDN, Spotify, etc.).</summary>
        public string? StreamUrl { get; set; }

        // ── Dates ─────────────────────────────────────────────────────────────
        public DateTime  DateAdded  { get; set; } = DateTime.Now;
        public DateTime? LastPlayed { get; set; }

        // ── Transient UI state (never serialised) ─────────────────────────────
        [Newtonsoft.Json.JsonIgnore]
        public bool IsBulkSelected
        {
            get => _isBulkSelected;
            set { _isBulkSelected = value; OnPropertyChanged(); }
        }

        // ── Computed display helpers ───────────────────────────────────────────
        public string DisplayArtist => string.IsNullOrWhiteSpace(Artist) ? "Unknown Artist" : Artist;
        public string DisplayTitle  => string.IsNullOrWhiteSpace(Title)  ? "Unknown Title"  : Title;

        public string DurationText => Duration.TotalHours >= 1
            ? Duration.ToString(@"h\:mm\:ss")
            : Duration.ToString(@"m\:ss");

        public string PlayCountText => _playCount == 0 ? string.Empty : $"▶ {_playCount}";

        /// <summary>
        /// Source badge shown in the UI: LOCAL / YT / SPOT / STREAM.
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public string SourceBadge => Source switch
        {
            SongSource.YouTube  => "YT",
            SongSource.Spotify  => "SPOT",
            SongSource.Stream   => "STREAM",
            _                   => "LOCAL"
        };

        // ── INotifyPropertyChanged ─────────────────────────────────────────────
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    public enum SongSource { Local, YouTube, Spotify, Stream }
}
