using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace DeadFy.Models
{
    public class Song : INotifyPropertyChanged
    {
        // ── Backing fields ─────────────────────────────────────────────────────
        private string     _title          = string.Empty;
        private string     _artist         = string.Empty;
        private string     _album          = string.Empty;
        private string     _genre          = string.Empty;
        private string     _filePath       = string.Empty;
        private string?    _coverPath;
        private string?    _thumbnailUrl;
        private TimeSpan   _duration;
        private bool       _isFavorite;
        private SongSource _source;
        private int        _playCount;
        private bool       _isBulkSelected;
        private int        _rating;              // 0–5 stars
        private int        _bpm;                 // beats per minute, 0 = unknown
        private int        _bitrate;             // kbps, 0 = unknown
        private string?    _comment;
        private string?    _lyrics;              // cached plain-text lyrics
        private TimeSpan?  _bookmarkPosition;    // resume-from bookmark
        private string?    _mood;               // user-assigned mood tag

        // ── Identity ───────────────────────────────────────────────────────────
        public string Id { get; set; } = Guid.NewGuid().ToString();

        // ── Core metadata ──────────────────────────────────────────────────────
        public string Title
        {
            get => _title;
            set { _title = value; OnPropertyChanged(); OnPropertyChanged(nameof(DisplayTitle)); }
        }

        public string Artist
        {
            get => _artist;
            set { _artist = value; OnPropertyChanged(); OnPropertyChanged(nameof(DisplayArtist)); }
        }

        public string Album
        {
            get => _album;
            set { _album = value; OnPropertyChanged(); }
        }

        /// <summary>Genre tag read from ID3 metadata or set by the user.</summary>
        public string Genre
        {
            get => _genre;
            set { _genre = value; OnPropertyChanged(); }
        }

        public string FilePath
        {
            get => _filePath;
            set { _filePath = value; OnPropertyChanged(); }
        }

        public string? CoverPath
        {
            get => _coverPath;
            set { _coverPath = value; OnPropertyChanged(); }
        }

        public string? ThumbnailUrl
        {
            get => _thumbnailUrl;
            set { _thumbnailUrl = value; OnPropertyChanged(); }
        }

        /// <summary>Optional freeform comment from ID3 tag or user.</summary>
        public string? Comment
        {
            get => _comment;
            set { _comment = value; OnPropertyChanged(); }
        }

        /// <summary>User-assigned mood tag, e.g. "Chill", "Energetic", "Sad".</summary>
        public string? Mood
        {
            get => _mood;
            set { _mood = value; OnPropertyChanged(); }
        }

        // ── Audio technical properties ─────────────────────────────────────────

        /// <summary>BPM detected or read from ID3 tag. 0 = unknown.</summary>
        public int Bpm
        {
            get => _bpm;
            set { _bpm = value; OnPropertyChanged(); OnPropertyChanged(nameof(BpmText)); }
        }

        /// <summary>Bitrate in kbps. 0 = unknown.</summary>
        public int Bitrate
        {
            get => _bitrate;
            set { _bitrate = value; OnPropertyChanged(); OnPropertyChanged(nameof(BitrateText)); }
        }

        // ── User rating ────────────────────────────────────────────────────────

        /// <summary>User rating from 0 (unrated) to 5 stars.</summary>
        public int Rating
        {
            get => _rating;
            set
            {
                _rating = Math.Clamp(value, 0, 5);
                OnPropertyChanged();
                OnPropertyChanged(nameof(RatingStars));
            }
        }

        // ── Cached lyrics ──────────────────────────────────────────────────────

        /// <summary>
        /// Locally cached plain-text lyrics so we don't hit the API on every play.
        /// Serialised to disk; set by LyricsService after a successful fetch.
        /// </summary>
        public string? Lyrics
        {
            get => _lyrics;
            set { _lyrics = value; OnPropertyChanged(); }
        }

        // ── Bookmark ───────────────────────────────────────────────────────────

        /// <summary>
        /// Position to resume from for long-form content (podcasts, audiobooks).
        /// Null = start from beginning.
        /// </summary>
        public TimeSpan? BookmarkPosition
        {
            get => _bookmarkPosition;
            set { _bookmarkPosition = value; OnPropertyChanged(); }
        }

        // ── Playback state ─────────────────────────────────────────────────────
        public TimeSpan Duration
        {
            get => _duration;
            set { _duration = value; OnPropertyChanged(); OnPropertyChanged(nameof(DurationText)); }
        }

        public bool IsFavorite
        {
            get => _isFavorite;
            set { _isFavorite = value; OnPropertyChanged(); }
        }

        public SongSource Source
        {
            get => _source;
            set { _source = value; OnPropertyChanged(); }
        }

        public int PlayCount
        {
            get => _playCount;
            set { _playCount = value; OnPropertyChanged(); OnPropertyChanged(nameof(PlayCountText)); }
        }

        // ── Streaming ──────────────────────────────────────────────────────────

        /// <summary>True when the file is streamed from a URL rather than a local path.</summary>
        public bool IsStreaming { get; set; } = false;

        /// <summary>Direct stream URL (YouTube CDN, Spotify preview, etc.).</summary>
        public string? StreamUrl { get; set; }

        // ── Track numbering ────────────────────────────────────────────────────

        /// <summary>Track number within its album (0 = unknown).</summary>
        public int TrackNumber { get; set; }

        /// <summary>Disc number for multi-disc albums (0 = unknown).</summary>
        public int DiscNumber { get; set; }

        /// <summary>Year of release (0 = unknown).</summary>
        public int Year { get; set; }

        // ── Dates ──────────────────────────────────────────────────────────────
        public DateTime  DateAdded  { get; set; } = DateTime.Now;
        public DateTime? LastPlayed { get; set; }

        // ── Transient UI state (never serialised) ──────────────────────────────
        [Newtonsoft.Json.JsonIgnore]
        public bool IsBulkSelected
        {
            get => _isBulkSelected;
            set { _isBulkSelected = value; OnPropertyChanged(); }
        }

        // ── Computed display helpers ───────────────────────────────────────────

        public string DisplayArtist => string.IsNullOrWhiteSpace(Artist) ? "Unknown Artist" : Artist;
        public string DisplayTitle  => string.IsNullOrWhiteSpace(Title)  ? "Unknown Title"  : Title;

        public string DurationText => Duration.TotalHours >= 1
            ? Duration.ToString(@"h\:mm\:ss")
            : Duration.ToString(@"m\:ss");

        public string PlayCountText => _playCount == 0 ? string.Empty : $"▶ {_playCount}";

        /// <summary>Star string for the rating, e.g. "★★★☆☆".</summary>
        [Newtonsoft.Json.JsonIgnore]
        public string RatingStars => new string('★', _rating) + new string('☆', 5 - _rating);

        /// <summary>BPM display label.</summary>
        [Newtonsoft.Json.JsonIgnore]
        public string BpmText => _bpm > 0 ? $"{_bpm} BPM" : string.Empty;

        /// <summary>Bitrate display label.</summary>
        [Newtonsoft.Json.JsonIgnore]
        public string BitrateText => _bitrate > 0 ? $"{_bitrate} kbps" : string.Empty;

        /// <summary>
        /// Source badge shown in the UI: LOCAL / YT / SPOT / STREAM.
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public string SourceBadge => Source switch
        {
            SongSource.YouTube  => "YT",
            SongSource.Spotify  => "SPOT",
            SongSource.Stream   => "STREAM",
            _                   => "LOCAL"
        };

        /// <summary>
        /// True if all three main metadata fields are non-empty.
        /// Used by the UI to show a warning icon for incomplete tags.
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public bool HasCompleteMetadata
            => !string.IsNullOrWhiteSpace(Title)
            && !string.IsNullOrWhiteSpace(Artist)
            && !string.IsNullOrWhiteSpace(Album);

        // ── Equality ───────────────────────────────────────────────────────────

        public override bool Equals(object? obj) => obj is Song s && s.Id == Id;
        public override int GetHashCode() => Id.GetHashCode();

        // ── INotifyPropertyChanged ─────────────────────────────────────────────
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    public enum SongSource { Local, YouTube, Spotify, Stream }
}
