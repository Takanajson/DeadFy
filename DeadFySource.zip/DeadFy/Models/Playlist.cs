using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace DeadFy.Models
{
    public class Playlist : INotifyPropertyChanged
    {
        private string  _name      = string.Empty;
        private string? _coverPath;

        // ── Identity ──────────────────────────────────────────────────────────
        public string Id { get; set; } = Guid.NewGuid().ToString();

        // ── Metadata ──────────────────────────────────────────────────────────
        public string Name
        {
            get => _name;
            set { _name = value; OnPropertyChanged(); }
        }

        public string? CoverPath
        {
            get => _coverPath;
            set { _coverPath = value; OnPropertyChanged(); }
        }

        public ObservableCollection<Song> Songs { get; set; } = new();
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        // ── Computed display helpers ───────────────────────────────────────────

        public string SongCountText
            => Songs.Count == 1 ? "1 song" : $"{Songs.Count} songs";

        /// <summary>Total duration of all songs in the playlist.</summary>
        [Newtonsoft.Json.JsonIgnore]
        public TimeSpan TotalDuration
            => TimeSpan.FromTicks(Songs.Sum(s => s.Duration.Ticks));

        [Newtonsoft.Json.JsonIgnore]
        public string TotalDurationText
        {
            get
            {
                var t = TotalDuration;
                return t.TotalHours >= 1
                    ? $"{(int)t.TotalHours}h {t.Minutes}m"
                    : $"{t.Minutes}m {t.Seconds}s";
            }
        }

        // ── INotifyPropertyChanged ─────────────────────────────────────────────
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
