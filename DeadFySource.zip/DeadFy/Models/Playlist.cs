using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using DeadFy.Models;

namespace DeadFy.Models
{
    public class Playlist : INotifyPropertyChanged
    {
        private string  _name        = string.Empty;
        private string? _coverPath;
        private string? _description;
        private string? _colorHex;     // accent colour tag, e.g. "#1DB954"

        // ── Identity ───────────────────────────────────────────────────────────
        public string Id { get; set; } = Guid.NewGuid().ToString();

        // ── Metadata ───────────────────────────────────────────────────────────
        public string Name
        {
            get => _name;
            set { _name = value; OnPropertyChanged(); }
        }

        public string? CoverPath
        {
            get => _coverPath;
            set { _coverPath = value; OnPropertyChanged(); }
        }

        /// <summary>Optional user-written description shown below the playlist name.</summary>
        public string? Description
        {
            get => _description;
            set { _description = value; OnPropertyChanged(); }
        }

        /// <summary>
        /// Optional hex accent colour assigned by the user, e.g. "#E91E63".
        /// Null means use the app accent colour.
        /// </summary>
        public string? ColorHex
        {
            get => _colorHex;
            set { _colorHex = value; OnPropertyChanged(); }
        }

        public ObservableCollection<Song> Songs { get; set; } = new();

        public DateTime CreatedAt  { get; set; } = DateTime.Now;
        public DateTime ModifiedAt { get; set; } = DateTime.Now;

        // ── Constructor — wire up Songs CollectionChanged ──────────────────────
        public Playlist()
        {
            Songs.CollectionChanged += OnSongsChanged;
        }

        private void OnSongsChanged(object? sender, NotifyCollectionChangedEventArgs e)
        {
            ModifiedAt = DateTime.Now;
            OnPropertyChanged(nameof(SongCountText));
            OnPropertyChanged(nameof(TotalDuration));
            OnPropertyChanged(nameof(TotalDurationText));
            OnPropertyChanged(nameof(IsEmpty));
        }

        // ── Computed display helpers ───────────────────────────────────────────

        public string SongCountText
            => Songs.Count == 1 ? "1 song" : $"{Songs.Count} songs";

        public bool IsEmpty => Songs.Count == 0;

        /// <summary>Total duration of all songs in the playlist.</summary>
        [Newtonsoft.Json.JsonIgnore]
        public TimeSpan TotalDuration
            => TimeSpan.FromTicks(Songs.Sum(s => s.Duration.Ticks));

        [Newtonsoft.Json.JsonIgnore]
        public string TotalDurationText
        {
            get
            {
                var t = TotalDuration;
                return t.TotalHours >= 1
                    ? $"{(int)t.TotalHours}h {t.Minutes}m"
                    : $"{t.Minutes}m {t.Seconds}s";
            }
        }

        /// <summary>Unique artist count in this playlist.</summary>
        [Newtonsoft.Json.JsonIgnore]
        public int UniqueArtistCount
            => Songs.Select(s => s.DisplayArtist)
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .Count();

        // ── Convenience methods ────────────────────────────────────────────────

        /// <summary>Returns true if the playlist contains at least one song by the given artist.</summary>
        public bool ContainsArtist(string artist)
            => Songs.Any(s => string.Equals(s.DisplayArtist, artist, StringComparison.OrdinalIgnoreCase));

        /// <summary>Returns songs sorted by their natural album/track order.</summary>
        [Newtonsoft.Json.JsonIgnore]
        public IOrderedEnumerable<Song> SortedByAlbum
            => Songs.OrderBy(s => s.Album)
                    .ThenBy(s => s.DiscNumber)
                    .ThenBy(s => s.TrackNumber);

        // ── INotifyPropertyChanged ─────────────────────────────────────────────
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
