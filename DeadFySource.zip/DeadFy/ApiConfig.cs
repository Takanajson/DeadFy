// ============================================================
//  ApiConfig.cs  —  DeadFy
//
//  Put your API keys here directly.
//  These override anything saved in settings.json.
//  Leave a field as "" to fall back to the settings file.
// ============================================================

namespace DeadFy
{
    internal static class ApiConfig
    {
        // ── Discord RPC ───────────────────────────────────────────────
        // Your Discord Application Client ID (from discord.com/developers)
        public const string DiscordClientId = "1488106449237184665";

        // ── YouTube Data API v3 ───────────────────────────────────────
        // Get a free key at console.cloud.google.com → YouTube Data API v3
        public const string YouTubeApiKey = "AIzaSyDKlc4PkIr73qtbA5NYktId1Fr1TPtu01c";

        // ── Spotify ───────────────────────────────────────────────────
        // Create an app at developer.spotify.com → Dashboard
        public const string SpotifyClientId = "d475b023f47240299b1209d6e31837ff";
        public const string SpotifyClientSecret = "03aeb0d92b0f492abf65cd836b45dfe9";

        // ── Last.fm ───────────────────────────────────────────────────
        // Register at last.fm/api/account/create
        public const string LastFmApiKey = "9080fee6c5be2326de55b99ec4e8b691";
        public const string LastFmApiSecret = "8619748421a49bf6ab18b072c27ce9a3";
    }
}
